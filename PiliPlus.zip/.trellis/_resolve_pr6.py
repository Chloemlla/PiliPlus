from pathlib import Path
import re

# content_panel: remove unused style/emote_span imports
p = Path("lib/pages/dynamics/widgets/content_panel.dart")
t = p.read_text(encoding="utf-8")
for imp in [
    "import 'package:pili_plus/common/style.dart';\n",
    "import 'package:pili_plus/common/widgets/emote_span.dart';\n",
]:
    if imp in t:
        t = t.replace(imp, "")
        print("removed", imp.strip())
p.write_text(t, encoding="utf-8", newline="\n")

# reply_item: convert emote WidgetSpan to EmoteSpan with rawText
p = Path("lib/pages/video/reply/widgets/reply_item_grpc.dart")
t = p.read_text(encoding="utf-8")
old = """          if (content.emotes.containsKey(matchStr)) {
            // 处理表情
            final emote = content.emotes[matchStr]!;
            final size = emote.size.toInt() * 20.0;
            spanChildren.add(
              WidgetSpan(
                child: NetworkImgLayer(
"""
new = """          if (content.emotes.containsKey(matchStr)) {
            // 处理表情
            final emote = content.emotes[matchStr]!;
            final size = emote.size.toInt() * 20.0;
            spanChildren.add(
              EmoteSpan(
                rawText: matchStr,
                child: NetworkImgLayer(
"""
if old not in t:
    # try alternate indentation
    print("OLD BLOCK NOT FOUND; showing nearby")
    idx = t.find("content.emotes.containsKey(matchStr)")
    print(repr(t[idx:idx+350]))
    raise SystemExit(1)
t = t.replace(old, new, 1)
# ensure emote_span import present
if "emote_span.dart" not in t:
    t = t.replace(
        "import 'package:pili_plus/common/widgets/dialog/report.dart';\n",
        "import 'package:pili_plus/common/widgets/dialog/report.dart';\nimport 'package:pili_plus/common/widgets/emote_span.dart';\n",
    )
p.write_text(t, encoding="utf-8", newline="\n")
print("converted reply emote to EmoteSpan")

# whats_new: rewrite pages for this build focus
wn = Path("lib/pages/onboarding/whats_new_data.dart")
text = wn.read_text(encoding="utf-8")
# Replace pages content after get pages => [
start = text.index("static List<ImprovementsGuidePageData> get pages => [")
end = text.rindex("];")
new_pages = '''static List<ImprovementsGuidePageData> get pages => [
    ImprovementsGuidePageData(
      icon: Icons.new_releases_outlined,
      title: '本次构建更新说明',
      subtitle:
          '你第一次打开这个构建。本版本合并上游文本选择与表情选择改进，并附上构建标识便于核对。',
      bullets: [
        '版本：$versionLabel',
        'Build Time：$buildTimeLabel',
        'Commit Hash：$commitLabel',
        '与「本分支改进说明」不同：这里讲的是这次新构建相对上一构建的变化。',
      ],
      tip: '可左右滑动浏览；完成后同一构建不会再次自动弹出。',
    ),
    const ImprovementsGuidePageData(
      icon: Icons.content_copy_outlined,
      title: '文本选择更顺手',
      subtitle: '多段选中文本按换行拼接，复制阅读更清晰；双击/三击与跨平台选区表现更稳定。',
      bullets: [
        '选中后展示菜单前会统一收起工具栏并清理选区。',
        '评论「加入过滤」在选区为空时会安全跳过，避免崩溃。',
        '直播超聊选中文本可直接走「视频」「搜索」入口。',
      ],
    ),
    const ImprovementsGuidePageData(
      icon: Icons.emoji_emotions_outlined,
      title: '表情选择与还原',
      subtitle: '复制/回复流程对「表情与文本」处理更顺畅，表情占位会还原为原始文本。',
      bullets: [
        '动态、私信等富文本表情改用 EmoteSpan 携带原文。',
        '编辑器表情插入使用统一占位符，序列化更一致。',
        '继续支持把选中内容加入评论过滤。',
      ],
    ),
    const ImprovementsGuidePageData(
      icon: Icons.bug_report_outlined,
      title: '本构建保留与修复',
      subtitle: '合并上游时保留本分支已有能力，并收敛滚动与主题相关稳定性。',
      bullets: [
        '评论日期显示：继续保留主评完整时间、子评相对/短日期。',
        '滚动偏移补丁改为始终写入像素，边界判断使用 minScrollExtent。',
        '动态取色等内容展开状态与上游修复对齐。',
      ],
      tip: '若仍看到无日期，请确认已安装包含该修复的构建。',
    ),
    const ImprovementsGuidePageData(
      icon: Icons.rocket_launch_outlined,
      title: '可以继续使用了',
      subtitle: '以上是本构建值得知道的有意变更。之后同一 Commit / Build Time 不会再自动弹出。',
      bullets: [
        '可在「设置 → 关于 → 本次更新说明」再次打开。',
        '分支级长期能力仍见「本分支改进说明」。',
        '开源协议与第三方鸣谢见「开源声明与第三方鸣谢」。',
      ],
      tip: '点「知道了」进入应用。',
    ),
  ]'''
text = text[:start] + new_pages + text[end:]
wn.write_text(text, encoding="utf-8", newline="\n")
print("updated whats_new_data.dart")
print("done")
