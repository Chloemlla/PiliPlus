# Flutter Clipboard Video Links

## Scenario: Clipboard video link confirmation

### 1. Scope / Trigger

- Trigger: clipboard text is scanned for Bilibili video links on app startup or
  resume.
- Scope: `ClipboardVideoLinkHandler` and the confirmation dialog shown before
  opening a clipboard video while the current route is `/videoV`.

### 2. Signatures

```dart
static Future<void> checkAndOpen()
static String? extractVideoLink(String text)
static Future<_ResolvedVideoLink> _resolveVideoLink(String link)
```

### 3. Contracts

- Session duplicate state is process-local memory only; do not persist it to
  preferences.
- Normalize supported links with an HTTP scheme before routing or redirect
  parsing.
- Resolve `b23.tv` and `share.b23.tv` links before deciding whether to show the
  confirmation dialog.
- Derive the duplicate key from the parsed video identity, preferring `aid`.
  `av` and `BV` links for the same video must map to the same key.
- If a confirmation dialog is shown and the user cancels, mark the parsed video
  as handled for the current session.

### 4. Validation & Error Matrix

- Clipboard text is empty -> return without side effects.
- No supported link is found -> return without side effects.
- Link/video key was already handled in this session -> return without showing a
  dialog or routing again.
- Short-link redirect parsing fails -> fall back to the normalized original
  link; route handling may still decide whether it can open it.
- Route handling returns `false` -> do not mark the link/video as handled.

### 5. Good/Base/Bad Cases

- Good: `b23.tv/xxx` redirects to `https://www.bilibili.com/video/BV...`; the
  resolved `aid` was already handled, so no second confirmation dialog appears.
- Base: a first-time direct `https://www.bilibili.com/video/av123` link opens
  and marks `aid:123` as handled.
- Bad: using only the raw clipboard text as the duplicate key, because different
  short links or AV/BV forms of the same video would prompt again.

### 6. Tests Required

- Assert `av` and `BV` forms of the same video produce one session duplicate
  key.
- Assert a resolved short link is checked against the parsed video key before
  showing the confirmation dialog.
- Assert canceling the confirmation dialog suppresses later prompts for the same
  parsed video in the same process session.

### 7. Wrong vs Correct

#### Wrong

```dart
if (_lastHandledLink == link) return;
await _confirmOpen(link);
```

#### Correct

```dart
final resolvedLink = await _resolveVideoLink(link);
if (_isHandledInSession(resolvedLink)) return;
await _confirmOpen(resolvedLink.link);
```
