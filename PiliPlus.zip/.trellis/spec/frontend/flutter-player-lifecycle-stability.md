# Flutter Player Layout and Lifecycle Stability

## Scenario: Android player controls and teardown must remain non-blocking

### 1. Scope / Trigger

- Trigger: changing player bottom controls, Dio interceptors, network adapter
  reset, crash filtering, Android media notification refresh, or media_kit
  dependency patches.
- Scope: Flutter layout, Dart async ownership, HTTP/2 pool lifecycle, crash
  boundaries, Android service refresh, and pinned media_kit source patches.

### 2. Signatures

```dart
PlayerBar({required Widget leading, required Widget trailing})

void replaceHttp2AdapterPool({
  required Http2Adapter adapter,
  required ConnectionManager connectionManager,
  required HttpClientAdapter fallbackAdapter,
  required void Function(HttpClientAdapter) installHttp11Adapter,
})

bool CrashReportFilter.shouldIgnore(Object error, [StackTrace? stackTrace])
```

```powershell
lib/scripts/patch_media_kit_android_isolate.ps1
```

### 3. Contracts

- `PlayerBar.leading` keeps intrinsic width and is never scaled by trailing
  controls. `trailing` receives only the remaining width through `Expanded`
  and scrolls horizontally with the rightmost actions visible initially.
- An interceptor source Future selects exactly one handler completion. Never
  place a broad `catchError`/`whenComplete` after a callback that calls
  `next`, `resolve`, or `reject`.
- Network reset installs replacement adapters before closing old adapters.
  Old HTTP/2 and HTTP/1.1 resources close with `force: false`.
- Ignore the HTTP/2 closed-writer race only for `StateError`, the exact closed
  event message, and `FrameWriter.writeGoawayFrame` plus connection-queue
  stack frames without `package:pili_plus/` frames.
- Android media_kit must use the isolate event-loop backend at the exact pinned
  revision. Other platforms retain native-first fallback.
- An existing `NativeMediaService` refreshes directly; only a missing service
  receives a start request.

### 4. Validation & Error Matrix

| Condition | Expected |
|---|---|
| Narrow bar, trailing controls exceed remainder | no overflow; trailing scrolls |
| Handler success callback throws/completes | no error branch calls the handler again |
| Network route changes with active requests | new pool installed; old pool drains non-force |
| Generic `Cannot add event after closing` | reportable |
| Exact third-party HTTP/2 GOAWAY closed-writer stack | handled diagnostic |
| media_kit checkout/ref differs from lock | patch script fails before mutation |
| Android player disposal | no native event-loop `thread::join` on UI isolate |

### 5. Good/Base/Bad Cases

- Good: fixed leading group plus `Expanded(SingleChildScrollView(reverse:
  true))` for trailing controls.
- Good: `future.then(success, onError: failure)` with one handler call per
  callback.
- Base: wide controls fit, remain right-aligned, and have zero scroll extent.
- Bad: `Row(left, Spacer(), SingleChildScrollView(right))` because the scroll
  view is measured at intrinsic width.
- Bad: force-close the active HTTP/2 manager during a network swap.
- Bad: ignore every closed-stream `StateError` or patch unverified pub-cache
  sources.

### 6. Tests Required

- Widget tests for narrow overflow/scroll and wide right alignment.
- Cookie-load/save, retry success/exhaustion, and redirect failure tests with no
  uncaught duplicate-handler error.
- Adapter tests assert installation occurs before non-force close callbacks.
- Crash-filter positive and negative tests using the exact third-party stack.
- Patch script validates package config, lock ref, checkout HEAD, patch state,
  changed paths, and Android isolate markers.
- Flutter, Android, analyzer, and test execution occurs only in GitHub Actions.

### 7. Wrong vs Correct

#### Wrong

```dart
future.then((value) => handler.next(value)).catchError((error) {
  handler.reject(error); // may run after next already completed the handler
});
```

#### Correct

```dart
future.then<void>(
  handler.next,
  onError: (Object error, StackTrace stack) {
    handler.reject(toDioException(error, stack));
  },
);
```

## Design Decisions

- Prefer an Android isolate event loop over a source-only C++ edit because the
  shipped Android native library is prebuilt and the ANR proves synchronous
  join on the UI isolate.
- Prefer graceful application-level pool replacement plus exact filtering over
  a broad dependency-stack upgrade without a specific upstream fix.

