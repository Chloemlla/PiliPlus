# Flutter Crash Report History

## Scenario: Filtered, bounded local crash history

### 1. Scope / Trigger

* Trigger: Flutter, platform, explicit `Utils.reportError`, Catcher callbacks, Android uncaught exceptions, or Android process-exit history reach `CrashReporter`.
* Scope: cross-runtime classification, native staging/import, local persistence, startup presentation, and in-app history browsing.

### 2. Signatures

```dart
static bool CrashReporter.shouldIgnore(Object error, [StackTrace? stackTrace])
static CrashReport CrashReporter.recordErrorSync(
  Object error,
  StackTrace? stackTrace,
  {CrashSource source, CrashSeverity severity, String? module, String operation}
)
static CrashReport? CrashReportStore.load()
static List<CrashReport> CrashReportStore.loadAll()
static Future<void> CrashReportStore.markSeen(String reportId)
static Future<void> CrashReportStore.remove(String reportId)
```

Stored envelope:

```json
{
  "version": 2,
  "pendingReportId": "12-character-report-id-or-null",
  "reports": []
}
```

### 3. Contracts

* Install a guarded root Zone before Flutter binding initialization. Buffer early reports until `CrashReportStore` paths are ready.
* Android installs Project Lumen **capture-only** SDK (`com.chloemlla.lumen:lumen-crash-core`) via `LumenCrash.installSafely` from `Application.attachBaseContext` (idempotent onCreate). That SDK owns the JVM uncaught-exception path and external pending-report persistence.
* Host-local `NativeCrashHandler` is retired. Do not reintroduce a second process-wide uncaught handler.
* On next launch, Flutter must import native pending reports **after**
  `MainActivity.configureFlutterEngine` registers `pili_plus/native_crash`.
  `CrashReporter.ensureInitialized()` only prepares Flutter store / system info.
  `CrashReportStartupGate` calls `CrashReporter.importNativeAndResolvePending()`
  once the engine is up (retry on `MissingPluginException`).
* Native import path: `NativeCrashBridge.getLumenPendingReport` (uses
  `LumenCrash.loadPendingReportSafely()`), persist as fatal `android_uncaught`
  history with `makePending: false`, then clear SDK storage **only after**
  Flutter persistence succeeds.
* Lumen-imported reports must remain available in history/share UI, but must
  **not** open Flutter `CrashReportPage` again on cold start. Startup crash UI
  is reserved for non-Lumen fatal pending evidence (for example exit-history
  ANR/native/init staging). This prevents a double recovery surface after the
  Lumen capture path has already finished preparing for the main page.
* On Android 11+, import `ApplicationExitInfo` for Native crash, ANR, and initialization failure only. Skip `REASON_CRASH` java exits because lumen-crash already captured the JVM uncaught path. Acknowledge exit-history staging files only after Dart persistence succeeds.
* Exit-history collection is started on a background Application thread. Before
  reading `native_crashes/*`, Flutter waits on `awaitExitHistoryReady` (bounded
  ~2.5s) so cold-start imports do not race empty staging.
* Native messages, stacks, and traces must be redacted before disk write; Dart applies `LogRedactor` again during import/display.
* Flutter `CrashBreadcrumbs.record` best-effort forwards events to native `LumenCrash.recordBreadcrumb` so JVM fatal reports include route/app recent events.
* Every report records source, severity, session, module, operation, route, and reason. Legacy reports decode as unknown, non-fatal attribution.
* Ignore non-actionable diagnostics before crash persistence and before explicit errors are forwarded to Catcher.
* Bare string reports without a useful stack trace are diagnostics, not code exceptions, and must never enter crash history.
* Ignored wrapped messages include SSL/seek, DNS/TCP/TLS, MediaCodec, malformed media packet, and the recoverable HTTP/HTTPS player transport signatures owned by `flutter-player-errors.md`.
* Real Dart/Flutter `Error` and `Exception` objects remain reportable unless they match a known player-only signature.
* Reports are stored newest-first and capped at 20 entries. An unread pending fatal report must not be evicted by handled history.
* Replicated archive reads select the freshest valid replica(s); a valid stale first file must not shadow newer copies.
* A legacy single `CrashReport` JSON object decodes as one history entry whose ID is pending for startup display.
* `load()` returns only the pending startup report; `loadAll()` returns retained history.
* Continuing from the startup report calls `markSeen` and must not delete history.
* Opening a report from history reuses `CrashReportPage`; deleting there removes only that report.
* Repeated callbacks for the same occurrence produce one merged entry with the highest severity and richest attribution.
* Handled/unhandled Dart reports remain in history but do not become startup pending. Startup presentation is reserved for confirmed fatal non-Lumen native/process evidence from a previous session (exit-history). Lumen capture imports stay history-only.

### 4. Validation & Error Matrix

* Empty or unknown bare string without a useful stack -> ignore as a diagnostic.
* Unknown Dart `Error` or `Exception` -> keep reportable.
* Known benign SSL/player transport text -> do not persist as a crash.
* Known player text wrapped by a real exception with a `package:pili_plus` stack -> retain as an application exception.
* Android uncaught exception -> atomically stage, terminate through the original handler, import as fatal on next launch.
* Android uncaught exception via lumen-crash -> SDK external pending report, import as fatal history on next launch with `makePending: false`, then clear lumen storage.
* Android uncaught exception via lumen-crash import -> history-only; no second Flutter startup crash page for that report.
* Android Native crash/ANR/initialization failure on API 30+ -> import exit reason and bounded trace as fatal from host exit staging.
* Invalid archive file -> try the next replicated crash-report file.
* Invalid item inside a versioned archive -> skip that item and retain valid entries.
* More than 20 decoded or newly added reports -> retain the newest 20.
* `pendingReportId` missing from history -> no startup report; history remains available.
* Removing the pending report -> clear the pending marker and remove that entry.

### 5. Good/Base/Bad Cases

* Good: add a benign crash signature to `CrashReportFilter` with a regression test.
* Base: add a report through `CrashReportStore.saveSync`, then read the pending report at startup and the complete list in the log UI.
* Bad: clear the entire crash file when the user dismisses the startup report, because that destroys the history they must be able to revisit.

### 6. Tests Required

* Assert bare player/FFmpeg strings are ignored while unrelated Dart runtime failures remain reportable.
* Assert known player signatures remain ignored when wrapped in an exception object.
* Assert the recoverable player transport signatures remain ignored at the crash boundary.
* Assert legacy single-report JSON migrates into history and remains pending.
* Assert `markSeen` clears only the pending marker.
* Assert duplicate direct/Catcher callbacks collapse to one report.
* Assert handled-to-fatal duplicate callbacks upgrade severity and remain pending.
* Assert handled history cannot evict an unread pending fatal report.
* Assert native JSON imports preserve source/module/reason and redact sensitive values.
* Assert lumen-crash bridge payloads preserve author metadata and recent events into Flutter history.
* Assert lumen-style archive imports with `makePending: false` do not become
  startup pending, and do not replace an existing non-Lumen pending marker.
* Assert native channel uses safe pending-report load and does not throw when SDK install is absent.
* Assert Flutter breadcrumb recording attempts native forward on Android.
* Assert native import is not completed solely inside pre-`runApp`
  `ensureInitialized` (channel missing); startup gate performs deferred import.
* Assert stale/legacy handled pending reports do not show at startup.
* GitHub Android build validates the custom `Application`, native crash channel, and API-gated exit collector.
* Assert archive retention keeps the newest 20 entries.

### 7. Wrong vs Correct

#### Wrong

```dart
CrashReporter.recordErrorSync(playerEvent, null);
Catcher2.reportCheckedError(playerEvent, null);
```

#### Correct

```dart
CrashReporter.recordErrorSync(playerEvent, null);
if (!CrashReporter.shouldIgnore(playerEvent, null)) {
  Catcher2.reportCheckedError(playerEvent, null);
}
```

#### Wrong

```dart
CrashReportStore.saveSync(handledError, makePending: true);
```

#### Correct

```dart
CrashReportStore.saveSync(handledError, makePending: false);
```
