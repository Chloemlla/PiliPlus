# Flutter Media Library Tools

Executable contracts for smart playback quality, portable playlists, and
local video bookmarks.

## 1. Scope / Trigger

Use this spec when changing any of these cross-layer flows:

- Bilibili DASH quality discovery -> network/battery recommendation -> player
  stream selection -> automatic recommendation chip.
- Favorite/watch-later/following API models -> portable JSON/M3U8 -> file save
  or system share -> validated JSON import -> Bilibili write APIs.
- Player timestamp metadata -> Hive bookmark storage -> search/filter/sort ->
  JSON export/import -> reopening a video at the stored position.

These flows require code-spec depth because they cross network, storage,
controller, and UI boundaries. External JSON and API models are runtime data
and must be validated before use.

## 2. Signatures

### Smart quality

```dart
Future<double?> NetworkSpeedProbe.measure(
  Uri uri, {
  required Duration maxDuration,
});

Future<QualityRecommendation> QualityRecommendationService.recommendQuality({
  required QualityMode mode,
  required List<int> availableQualities,
  Uri? probeUri,
});

Future<QualityRecommendation?>
QualityRecommendationController.setAvailableQualities(
  Iterable<int> qualities, {
  Uri? probeUri,
  int? currentQualityCode,
  bool applyToPlayer = false,
});
```

### Playlist portability

```dart
Future<LoadingState<FavFolderData>> FavHttp.userfavFolder(...);
Future<LoadingState<FavDetailData>> FavHttp.userFavFolderDetail(...);
Future<LoadingState<FavPgcData>> FavHttp.favPgc(...);
Future<LoadingState<LaterData>> UserHttp.seeYouLater(...);

ValidationResult PlaylistImportService.validateJson(String jsonString);

Future<LoadingState<PlaylistImportResult>>
PlaylistImportService.importPlaylist({
  required String jsonString,
  required ImportDestination destination,
  Set<String>? existingBvids,
  WatchLaterPlaylistWriter? watchLaterWriter,
});
```

### Video bookmarks

```dart
Future<bool> VideoBookmarkService.init();

Future<VideoBookmark?> VideoBookmarkService.addBookmark({
  required String bvid,
  required String videoTitle,
  int? authorMid,
  required int timestampSeconds,
  String? name,
  String? note,
});

Future<int> VideoBookmarkService.importBookmarks(String jsonString);
```

## 3. Contracts

### Quality and player contract

- Only recommend `qn` values present in the current DASH `video` list.
- Canonical mapping is `112=1080P+`, `80=1080P`, `64=720P`, `32=480P`,
  `16=360P`, and `6=240P`. Keep it aligned with `VideoQuality`.
- The probe URI is a real current-video CDN URL from `VideoItem.playUrls`.
  `BiliCdnNetworkSpeedProbe` sends a bounded byte-range request, accepts only
  HTTP 200/206, stops at 3 MiB or 3 seconds, and rejects samples below 32 KiB.
- Cache a successful Mbps result for five minutes and invalidate it when the
  coarse connectivity type changes.
- A recommendation is not considered applied until the player opens the
  selected stream. Show the automatic chip only after `onPlaybackReady` sees
  the same `qn`; keep it visible for three seconds.
- Persist `QualityMode.storageValue`, while decoding legacy enum indexes.

### Playlist JSON version 1

```json
{
  "version": 1,
  "app": "PiliPlus",
  "exportedAt": "ISO-8601",
  "playlistName": "non-empty string",
  "count": 1,
  "videos": [
    {
      "itemType": "video",
      "bvid": "BV...",
      "seasonId": null,
      "title": "non-empty string",
      "cover": "optional string",
      "author": "optional string",
      "authorMid": 123,
      "duration": 60,
      "addedAt": "optional ISO-8601",
      "description": "optional string"
    }
  ]
}
```

- `itemType` is `video` (default for legacy version-1 exports) or `season`.
  Video rows require a valid BVID; season rows require `seasonId`.
- `count` must exactly equal `videos.length`.
- Reject import files over 8 MiB or 10,000 entries before issuing API writes.
- Validate the entire document and every row before any mutation. Duplicate
  detection covers both the target list and repeated BVIDs inside the file.
- Watch-later batch import suppresses the legacy per-row `UserHttp.toViewLater`
  toast and reports one aggregate result after all rows finish.
- Favorite export uses `FavFolderInfo`, `FavDetailItemModel`, and
  `FavPgcItemModel`; watch-later export uses `LaterItemModel`. Do not invent
  fields absent from these repository models.
- M3U8 exports stable Bilibili page references, not expiring media URLs.
- Saving uses the existing `StorageUtils.saveBytes2File` cross-platform path;
  sharing uses an `XFile` with MIME type and a valid share origin.

### Bookmark JSON version 1 and storage

- Hive box: `videoBookmarks`; adapter type ID: `100`; keys are bookmark IDs.
- `init()` returns `false` on storage-open failure so an optional feature
  cannot become a fatal application-start dependency. The service retains the
  initialization error and rejects storage access explicitly until a retry
  succeeds.
- Required bookmark fields are `id`, `bvid`, `videoTitle`,
  `timestampSeconds`, `name`, and ISO-8601 `createdAt`; `authorMid` and `note`
  are optional.
- New bookmarks validate and normalize their BVID/title/creator metadata before
  checking the limit or writing to Hive; invalid caller data never reaches the
  typed box.
- Import envelope requires `version=1`, `app=PiliPlus`, valid `exportedAt`, an
  exact `count`, and a `bookmarks` list. Limit input to 8 MiB / 10,000 rows.
- Parse and validate every row before `box.putAll`; malformed input must not
  cause a partial import.
- Enforce at most 200 stored bookmarks per BVID, including pending rows in one
  import. Existing or repeated IDs are skipped without overwriting data.
- Updates may change only editable details (`name`, `note`); immutable video,
  timestamp, identity, and creation fields come from the stored row.

## 4. Validation & Error Matrix

| Boundary | Invalid condition | Required result |
|---|---|---|
| Quality list | Empty or non-positive `qn` values | Return automatic fallback; never call `VideoQuality.fromCode` with an invented code |
| CDN probe | Non-HTTP URI, status other than 200/206, timeout, too few bytes | Return `null`; use connectivity heuristic |
| Quality apply | Recommended `qn` absent from DASH/player refuses it | Do not show the applied chip |
| Playlist envelope | Wrong version/app, invalid date/name/count/list | Invalid `ValidationResult`; no API writes |
| Playlist row | Wrong type, missing reference/title, invalid BVID/date | Report the one-based row index; no API writes |
| Playlist limits | More than 8 MiB or 10,000 rows | Reject before parsing/writing as early as available |
| Playlist duplicate | BVID already in destination or earlier in file | Skip and increment `duplicateCount` |
| Bookmark startup | Hive adapter/box open fails | `init()` returns `false`; application startup continues |
| Bookmark row | Bad types, empty required strings, negative timestamp, invalid date/BVID | Throw `FormatException` with one-based row context |
| Bookmark limits | More than 8 MiB/10,000 rows or more than 200 rows for one BVID | Reject envelope limit; silently cap valid rows at 200 per BVID |
| Bookmark mutation | Updating an unknown ID | Throw `StateError`; do not insert a new row through update |

## 5. Good / Base / Bad Cases

- Good quality: DASH offers `[120, 80, 64]`, probe measures 12 Mbps, battery is
  healthy -> select `80`, open that stream, then show `自动：720P → 1080P`.
- Base quality: probe fails on Wi-Fi -> use the Wi-Fi heuristic and choose the
  closest available `qn` at or below 1080P.
- Bad quality: mapping `80` to 720P -> wrong stream and misleading chip.
- Good playlist: two favorite folders plus watch later produce one schema-v1
  file; import skips repeated BVIDs and reports imported/duplicate/unsupported/
  failed counts separately.
- Base playlist: a season-only backup previews successfully but imports zero
  videos and reports the unsupported season count.
- Bad playlist: begin `favVideo` writes while later rows are still unvalidated.
- Good bookmarks: an import with 201 unique rows for one BVID stores exactly
  200, then a second identical import stores zero.
- Base bookmarks: Hive fails to open -> app still launches and bookmark
  storage access receives an explicit unavailable error instead of writing to
  an untyped or partially opened store.
- Bad bookmarks: unchecked casts accept malformed JSON and write early rows
  before a later row throws.

## 6. Tests Required

- Quality model: assert the canonical `qn` mapping against `VideoQuality` and
  round-trip labels/storage values.
- Quality service: assert quality-first, smooth-first, battery saver, measured
  throughput, low-battery ceiling, supported fallback, and five-minute cache.
- Quality controller: assert persistence-before-publish, failed persistence,
  actual player apply callback, applied-only chip, and chip timeout.
- Playlist model: assert JSON round trip, exact version/app, count equality,
  row-indexed failures, and M3U8 escaping/stable references.
- Playlist import: assert malformed roots/envelopes/BVIDs, input limits,
  duplicate summary, unique watch-later writes, and season-only no-write
  behavior.
- Bookmark model: assert Hive adapter ID, JSON round trip, bounded required
  fields, negative timestamp rejection, and editable copy behavior.
- Bookmark service: use a temporary typed Hive box; assert unique IDs,
  add-metadata validation, 200-per-video add/import limits,
  search/filter/sort, duplicate import, complete envelope validation,
  immutable update fields, and atomic rejection.
- Flutter/Gradle/analyze/test execution remains CI-only for this repository.

## 7. Wrong vs Correct

### Wrong

```dart
// Trusts an external cast, invents a qn, and writes before full validation.
final bookmark = VideoBookmark.fromJson(decoded['bookmarks'][0]);
await box.put(bookmark.id, bookmark);
currentVideoQa.value = VideoQuality.fromCode(80); // assumed "720P"
```

### Correct

```dart
final validation = PlaylistImportService.validateJson(source);
if (!validation.isValid) return Error(validation.message);

final recommendation = await qualityController.setAvailableQualities(
  dash.video!.map((item) => item.quality.code),
  probeUri: firstCurrentCdnUri,
  currentQualityCode: currentQn,
);
// 80 is canonical 1080P and recommendation is guaranteed to come from DASH.
if (recommendation != null) applyExistingDashQuality(recommendation.qualityCode);
```
