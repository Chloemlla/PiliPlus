# Android Media Notification Progress / Seek

## Scenario: MediaStyle scrubber requires duration write-back and seek gating

### 1. Scope / Trigger

- Trigger: Android system media notification progress / seek bar for playback.
- Scope: `NativeMediaService` + Flutter `VideoPlayerServiceHandler` bridge.
- Platform: Android only. Non-Android continues via `audio_service` path.

### 2. Signatures

```dart
// lib/services/audio_handler.dart
void onDurationChange(Duration duration)
void onBufferedChange(Duration buffered)
void onPositionChange(Duration position)
static bool shouldPushNativePosition({
  required bool playing,
  required Duration deltaFromPrevious,
  required Duration deltaFromLastPushed,
  required Duration? sinceLastPush,
  required Duration pushInterval,
  required Duration jumpThreshold,
})
static bool shouldAcceptPositionAfterSeek({
  required Duration position,
  required Duration seekTarget,
  required Duration settleThreshold,
  required bool graceExpired,
})
```

```kotlin
// NativeMediaService.updateMediaSession
// ACTION_SEEK_TO only when !live && durationMs > 0
// PlaybackState.Builder.setBufferedPosition(bufferedMs)
// MediaMetadata.METADATA_KEY_DURATION: live -> -1L else durationMs
```

MethodChannel payload keys (existing + required for scrubber):

| Key | Type | Notes |
|-----|------|-------|
| `durationMs` | number | Must become > 0 for non-live scrubber |
| `positionMs` | number | Optimistic on seek; throttled while playing |
| `bufferedMs` | number | Applied via `setBufferedPosition` |
| `live` | bool | true → duration -1, no SEEK_TO |
| `playing` / `speed` | bool / number | SystemUI interpolates with updateTime |

### 3. Contracts

- Player-reported duration **must** call `onDurationChange` so native metadata is not stuck at API/MediaItem duration 0.
- Call sites:
  - `PlPlayerController.updateDuration` → `videoPlayerServiceHandler?.onDurationChange`
  - Audio page `stream.duration` → same
- Non-live + `durationMs > 0` → declare `PlaybackState.ACTION_SEEK_TO`.
- Live or unknown duration → **no** scrubber / no misleading seek.
- Seek path: `MediaSession.Callback.onSeekTo` → channel `seek` + `positionMs` → Flutter `seek` with optimistic local position and 2s stale-tick guard.
- While playing, native position pushes are throttled (default 3s interval, 2s jump threshold). Pause / status / seek push immediately.
- Do **not** use `Notification.Builder.setProgress` for media scrubber; MediaSession drives MediaStyle.
- Do **not** add custom RemoteViews scrubber unless a future OEM task explicitly requires it.

### 4. Validation & Error Matrix

| Condition | Behavior |
|-----------|----------|
| `live == true` | duration metadata = -1; omit ACTION_SEEK_TO |
| `durationMs <= 0` non-live | omit ACTION_SEEK_TO until write-back |
| Player duration updates after open | `onDurationChange` updates MediaItem + native metadata |
| Seek then stale old position tick | drop until near target or grace expires |
| Playing small position deltas | throttle native updatePlayback |

### 5. Good/Base/Bad Cases

- **Good**: video/audio opens with duration 0, player reports real duration → scrubber appears; drag seek jumps player.
- **Base**: live room → transport controls only, no scrubber.
- **Bad**: only set MediaItem duration once from API and never write back player duration (scrubber missing forever when API duration is 0).

### 6. Tests Required

- Unit: `shouldPushNativePosition` (paused always; first push; mid-interval throttle; interval due; jump; boundary).
- Unit: `shouldAcceptPositionAfterSeek` (near target accept; far drop; grace expired accept).
- Device/OEM manual: expanded media notification scrubber + drag seek on common OEMs.

### 7. Wrong vs Correct

#### Wrong

```dart
void updateDuration(Duration value) {
  duration.value = value.inSeconds;
  // never notify media notification
}
```

#### Correct

```dart
void updateDuration(Duration value) {
  duration.value = value.inSeconds;
  durationInMilliseconds = value.inMilliseconds;
  if (value > Duration.zero) {
    videoPlayerServiceHandler?.onDurationChange(value);
  }
}
```

#### Wrong (Kotlin)

```kotlin
actions = actions or PlaybackState.ACTION_SEEK_TO // always, even live / duration 0
```

#### Correct (Kotlin)

```kotlin
if (!state.live && state.durationMs > 0L) {
  actions = actions or PlaybackState.ACTION_SEEK_TO
}
```

## Design Decision: Standard MediaSession path only

**Context**: Need visible + draggable progress in Android notification center.  
**Decision**: Fix MediaSession plumbing (duration write-back, seek gating, throttle, buffered position). No custom RemoteViews.  
**Consequences**: Small surface; OEM may still hide scrubber — rewind/FF remain as fallback.
