# Flutter Main Navigation Layout

## Scenario: Keep the home shell responsive after covered-route returns

### 1. Scope / Trigger

- Applies to `MainApp`, `MainController.useBottomNav`, `MainLayout`, and changes that affect orientation, immersive system UI, safe areas, or returning to the root route.
- Re-check this contract when porting upstream edits to `lib/pages/main/view.dart` or replacing the root `Scaffold` / layout renderer.

### 2. Signatures

```dart
// Repository portrait/bottom-navigation rule
bool get _shouldUseBottomNav =>
    !mainController.useSideBar && MediaQuery.sizeOf(context).isPortrait;

// SizeExt rule
bool get Size.isPortrait => width < 600 || height >= width;
```

### 3. Contracts

- `useSideBar == true` always wins and forces sidebar mode.
- Otherwise, `MainApp.build` derives the effective mode from the current `MediaQuery`; a controller value cached before another route was pushed is not authoritative.
- `didPopNext` schedules a rebuild because orientation/system-bar restoration may settle after the root route is revealed.
- Every build reads current `MediaQuery.viewPaddingOf(context)`; do not keep a route-spanning cached `EdgeInsets` as the final layout input.
- Bottom-navigation mode owns an edge-to-edge body: keep the top safe area, but do not apply stale horizontal `viewPadding` to the body.
- Sidebar mode may retain the right safe area; the sidebar itself owns left cutout spacing.
- `MainLayout.sideBar != null` is a real width allocation. Supplying a stale sidebar offsets and shrinks the body.

### 4. Validation Matrix

| Condition | Expected layout |
|---|---|
| Phone/narrow width (`width < 600`) | bottom navigation, no left body offset |
| Portrait tablet (`height >= width`) | bottom navigation unless forced sidebar |
| Wide landscape | sidebar + body offset by actual sidebar width |
| `Pref.useSideBar == true` | sidebar regardless of orientation |
| Return before orientation reset settles | root rebuilds, then follows current/final `MediaQuery` |
| Old landscape `viewPadding.left > 0`, current bottom-nav mode | no horizontal blank strip in body |

### 5. Good / Base / Bad Cases

- Good: compute a local `useBottomNav` in `build`, write it back for existing consumers, and use that local value for TabBarView axis and layout slots.
- Base: a normal route return with unchanged size performs a harmless root refresh and preserves the same mode.
- Bad: use only `MainController.useBottomNav` captured before the route push; a 72/130dp sidebar can remain after returning portrait.
- Bad: apply `_padding.left` / `_padding.right` to the bottom-navigation body; a landscape cutout inset becomes a full-height blank column.
- Bad: add an arbitrary delay or make every source page await orientation merely to hide a root-shell responsiveness bug.

### 6. Tests Required

When a lightweight shell/policy test seam exists, assert:

- portrait/narrow size -> `sideBar == null`, body x offset `0`, bottom nav present;
- landscape/wide size -> sidebar present and body offset equals sidebar width;
- forced sidebar overrides portrait;
- simulated covered-route return followed by orientation restoration recomputes the mode;
- bottom-navigation body ignores horizontal safe-area padding while preserving top padding.

Do not pump full `MainApp` without providing its GetX storage/account/plugin dependencies. CI remains the Flutter build/test authority.

### 7. Wrong vs Correct

#### Wrong

```dart
if (mainController.useBottomNav) {
  padding = EdgeInsets.only(
    top: cachedPadding.top,
    left: cachedPadding.left,
    right: cachedPadding.right,
  );
}
```

#### Correct

```dart
final viewPadding = MediaQuery.viewPaddingOf(context);
final useBottomNav = _shouldUseBottomNav;
mainController.useBottomNav = useBottomNav;

if (useBottomNav) {
  padding = EdgeInsets.only(top: viewPadding.top);
}
```

## Design Decision

The root shell is the final authority for responsive layout. Source routes may request orientation or system UI changes asynchronously, but they do not own the correctness of the home layout after return. This keeps navigation behavior consistent across video, image preview, onboarding, and future routes.
