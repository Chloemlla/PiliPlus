# Flutter Build Whats-New Guide

## Scenario: Every user-facing commit must refresh the build-scoped update tutorial

### 1. Scope / Trigger

- Trigger: any commit that changes user-visible behavior, UI, startup flow,
  permissions, downloads, playback, comments, settings, or onboarding copy.
- Scope: `WhatsNewData.pages` content maintenance + show/ack identity contracts.
- Non-trigger (no content rewrite required): pure docs under `.trellis/`, CI-only
  workflow tweaks with zero app binary behavior change, formatting-only diffs,
  generated lock churn with no runtime path change.
- Identity still changes on every shipped build via `BuildConfig.commitHash` /
  `BuildConfig.buildTime`; skipping content update is allowed only when the
  non-trigger list applies.

### 2. Signatures

```dart
// Content source for the immersive guide
abstract final class WhatsNewData {
  static List<ImprovementsGuidePageData> get pages;
  static String get versionLabel;
  static String get buildTimeLabel;
  static String get commitLabel;
}

// Show / ack service
abstract final class WhatsNewGuideService {
  static bool get isCurrentBuildAcknowledged;
  static Future<void> markCurrentBuildAcknowledged();
  static Future<void> maybeShow();
  static Future<void> openManual({bool markAsSeen = false});
}

// Storage identity
SettingBoxKey.whatsNewAckCommitHash
SettingBoxKey.whatsNewAckBuildTime

// Build identity (compile-time)
BuildConfig.commitHash  // fromEnvironment('pili.hash')
BuildConfig.buildTime   // fromEnvironment('pili.time') // unix seconds
```

### 3. Contracts

#### Content ownership

- Canonical pages live in `lib/pages/onboarding/whats_new_data.dart`.
- UI shell is reusable `ImprovementsGuidePage(pages:, finishLabel: '知道了')`.
- Do **not** fork a second PageView implementation for what's-new.
- Branch-long deltas stay in `ImprovementsGuideData.pages` (first install only).
- Build-scoped deltas stay in `WhatsNewData.pages` (first open of each new
  commit/buildTime).

#### Mandatory content refresh on user-facing commits

When a commit is user-facing (see Scope / Trigger), the same commit **must**:

1. Update `WhatsNewData.pages` so the next shipped build explains the change.
2. Prefer **replace** topic slides for the current release narrative over
   endless historical accumulation. Keep the guide scannable (typically
   welcome + 3–6 topic slides + finish).
3. Keep the welcome slide's identity bullets (`versionLabel` /
   `buildTimeLabel` / `commitLabel`) intact; they are computed from
   `BuildConfig` and must not be hard-coded.
4. Distinguish intentional changes vs regressions:
   - intentional feature/UI: describe as enhancement / refactor
   - accidental regression that was fixed in-branch: label as 修复 / 已修回
5. If the change is first-install-only branch capability (Seal, MMKV, Web QR,
   crash history, etc.) and not specific to this build, update
   `ImprovementsGuideData.pages` instead of or in addition to what's-new.
6. If About entry labels change, keep About →「本次更新说明」 wired to
   `WhatsNewGuideService.openManual`.

#### Show / ack identity

- Auto-show only when:
  - `firstLaunchOssNoticeSeen == true`
  - `firstLaunchImprovementsGuideSeen == true`
  - stored `(whatsNewAckCommitHash, whatsNewAckBuildTime)` differs from
    `(BuildConfig.commitHash, BuildConfig.buildTime)`
- First install: after improvements guide completes, call
  `markCurrentBuildAcknowledged()` so the same install does not immediately
  re-open what's-new.
- Upgrade/returning users: migration silences first-install flags; what's-new
  opens when build identity changes.
- Completion writes both hash and buildTime together.
- Dev builds with empty/`N/A` hash fall back to buildTime-only identity; if both
  hash is N/A and buildTime is `<= 0`, treat as already acknowledged (no loop).

#### Startup order

`crash report > OSS notice > improvements guide > what's-new > Android permissions`

`WhatsNewGuideService.maybeShow()` still chains Android permission request after
it finishes (or skips content because already acknowledged), so first-install
permission flow is not stranded when the current build was pre-acknowledged.

### 4. Validation & Error Matrix

| Condition | Expected |
|---|---|
| User-facing commit without `whats_new_data.dart` update | **Reject / incomplete** — update pages in the same change set |
| Same build identity already acknowledged | do not auto-show |
| New commitHash or buildTime | auto-show once after first-launch flags are true |
| First install just finished improvements guide | mark current build ack; no immediate what's-new |
| OSS or improvements flag false | what's-new returns early |
| hash `N/A` and buildTime `> 0` | compare buildTime only |
| hash `N/A` and buildTime `<= 0` | treat acknowledged (avoid infinite show in local bare builds) |
| Manual About open | show pages; do not write ack unless `markAsSeen: true` |
| Navigator unavailable | retry via `runWhenNavigatorReady`; do not write ack |

### 5. Good/Base/Bad Cases

- Good: restore comment date + rewrite what's-new slide "本构建修复补充" in the
  same PR/commit series before shipping.
- Good: upstream-sync intentional UI refactor commit updates slides for
  TranslucentRow / FAB / live feedback / webview / EDL / danmaku precision.
- Base: CI-only workflow commit that does not ship app behavior leaves
  `WhatsNewData.pages` unchanged.
- Bad: ship a user-visible Seal/cookie/download change but leave what's-new
  describing the previous build only.
- Bad: hard-code commit hash / build time strings in pages instead of
  `WhatsNewData.*Label` getters.
- Bad: put build-scoped release notes only into `ImprovementsGuideData` (first
  install never sees them on upgrade).
- Bad: append unbounded history slides until the guide is unreadable; replace
  the current narrative for the ship target.

### 6. Tests Required

- Assert `isCurrentBuildAcknowledged` is true only when stored hash+time match
  current `BuildConfig` (with N/A hash fallback).
- Assert `maybeShow` does not push when first-launch flags are false.
- Assert `maybeShow` does not push when identity already acknowledged.
- Assert first-install improvements completion writes whats-new ack keys.
- Assert About manual open uses `WhatsNewData.pages` and finish label `知道了`.
- Process assertion for agents: before committing a user-facing change, search
  `lib/pages/onboarding/whats_new_data.dart` and confirm the new behavior is
  mentioned.

### 7. Wrong vs Correct

#### Wrong (user-facing commit skips guide content)

```dart
// only code fix
// lib/pages/video/reply/widgets/reply_item_grpc.dart restored ctime
// WhatsNewData.pages left describing older build only
```

#### Correct

```dart
// same change set also updates lib/pages/onboarding/whats_new_data.dart
ImprovementsGuidePageData(
  icon: Icons.bug_report_outlined,
  title: '本构建修复补充',
  subtitle: '同步上游时的非有意回退已修回。',
  bullets: [
    '评论日期：主评完整时间、子评相对/短日期。',
    'IP 归属仅在 hasLocation() 时拼接。',
  ],
);
```

#### Wrong (hard-coded identity)

```dart
bullets: [
  'Commit Hash: a11b6ad56',
  'Build Time: 2026-07-22 12:00:00',
],
```

#### Correct

```dart
bullets: [
  '版本：$versionLabel',
  'Build Time：$buildTimeLabel',
  'Commit Hash：$commitLabel',
],
```

#### Wrong (upgrade never sees build notes)

```dart
// put this build's notes only into ImprovementsGuideData.pages
// upgrades skip first-install guide permanently
```

#### Correct

```dart
// build-scoped notes -> WhatsNewData.pages
// branch-long deltas -> ImprovementsGuideData.pages
```

## Commit Checklist (agents)

Before `git commit` for app code:

1. Is this user-facing? If yes → edit `WhatsNewData.pages` in the same commit
   (or the same PR's content commit immediately after).
2. Keep welcome identity bullets dynamic.
3. Label fixes vs intentional features accurately.
4. Do not rely on README alone; the in-app guide is the user-facing surface.
5. If only CI/docs/spec and no binary behavior change → content update optional.

## Design Decisions

- **Why build identity, not a boolean flag**: a single `seen` bool cannot detect
  upgrades; hash+time tracks each shipped binary.
- **Why replace narrative slides instead of infinite changelog**: cold-start
  immersive UI must stay short; full history belongs in GitHub commits/releases.
- **Why separate from branch improvements guide**: first install explains the
  fork; upgrades need only "what changed in this build".