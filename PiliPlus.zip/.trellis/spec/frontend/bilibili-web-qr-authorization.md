# Bilibili Web QR Authorization

## Scenario: Authorize a Bilibili web login from an authenticated PiliPlus account

### 1. Scope / Trigger

- Trigger: Android camera/gallery QR recognition or manual submission of a Bilibili `scan-web` URL.
- Scope: Android native HMS Scan Kit QR decoding, Flutter platform-channel boundary, strict QR validation, authenticated Bilibili authorization requests, risk UI, SMS verification, and sensitive-log redaction.
- The existing TV QR login flow is a separate protocol and must not be reused as the web authorization flow.

### 2. Signatures

Android MethodChannel:

```text
channel: pili_plus/android_qr_scanner
scanCamera() -> String? QR payload
scanImage()  -> String? QR payload
```

Accepted QR URL:

```text
https://account.bilibili.com/h5/account-h5/auth/scan-web?qrcode_key=<key>
```

Authorization endpoints:

```text
GET  /x/passport-login/web/qrcode/check
GET  /x/passport-login/web/qrcode/scene
POST /x/passport-login/web/qrcode/confirm
```

Confirmation fields:

```text
qrcode_key, transient, env_key,
verify_type, verify_key, verify_code,
csrf, access_key?, appkey, ts, sign
```

### 3. Contracts

- Camera scanning uses Huawei HMS Scan Kit `RemoteView` (custom UI host in `QrScannerActivity`) with format `HmsScan.QRCODE_SCAN_TYPE` only. Non-QR barcode formats are ignored by restricting the analyzer format.
- Gallery decoding uses `ScanUtil.decodeWithBitmap` with `HmsScanAnalyzerOptions.Creator().setHmsScanTypes(HmsScan.QRCODE_SCAN_TYPE).setPhotoMode(true)` off the main thread after sampling large images.
- Dependency: declarative Gradle `implementation("com.huawei.hms:scanplus:<version>")` resolved from `https://developer.huawei.com/repo/`. Prefer the free/public Scan Kit SDK path that does **not** require `agconnect-services.json` or the AGConnect Gradle plugin for basic decode.
- Scan Kit is intentional and replaces the previous CameraX + ZXing path. Do not reintroduce ML Kit barcode scanning into this flow: repeated ML Kit component-runtime null references occurred even with a complete final APK provider/registrar manifest.
- Do not reintroduce CameraX frame analysis + ZXing Core for the web QR auth scanner unless a documented emergency fallback is explicitly required; current product choice is HMS Scan Kit.
- Guard RemoteView lifecycle (`onCreate`/`onStart`/`onResume`/`onPause`/`onStop`/`onDestroy`) and Scan Kit linkage failures. OEM camera errors must release RemoteView resources and return a platform error on the main thread.
- Log the full Scan Kit / camera stack trace through Android logging for diagnosis, but return only a stable user-facing message over MethodChannel instead of exposing vendor/internal exception text.
- Camera permission remains on-demand from Flutter (`AndroidQrScanner.scanCamera`); the native Activity only re-checks and fails with `permission_denied` if missing.
- Gallery decoding runs off the main thread and samples large images before bitmap decode (no broad storage permission; `ACTION_OPEN_DOCUMENT` URI).
- Only exact HTTPS host `account.bilibili.com` and path `/h5/account-h5/auth/scan-web` are accepted. Validate the raw authority before relying on `Uri`: Dart normalizes an explicit default `:443`, so `Uri.hasPort` and normalized authority values cannot detect it.
- Reject user info, explicit ports, fragments, duplicate/missing keys, and keys outside the bounded identifier format.
- Bind account, QR key, and scene to one in-memory authorization generation. Late responses from an older generation must not update or confirm a newer generation.
- `scene.location_diff=true` requires a non-dismissible second confirmation before the final request.
- `scene.obtain_env=true` requires at least one valid environment option; missing options are an invalid server response.
- `scene.verify_tel=true` requires completed SMS verification before confirmation.
- Every request in the web QR authorization flow must set `RetryInterceptor.disableRetryKey`; transport failures are surfaced to the user instead of replaying security-sensitive scan, confirmation, captcha, or SMS operations.
- Never persist the QR key, captcha key, verification code, Cookie, CSRF, or access key.
- Debug HTTP logging must call `LogRedactor` before output. Redaction must cover query text, JSON, Dart Map text, and recursive structured maps.

### 4. Validation & Error Matrix

- Non-Android camera/gallery request -> user-facing unsupported message; manual URL remains available.
- Camera permission denied -> recoverable permission message.
- Camera permission permanently denied -> offer system app settings.
- Scanner Activity cancelled -> return `null`, not an error and never a late success.
- Image contains no QR -> `not_found` error.
- Invalid origin/path/key -> reject before any network request.
- Raw authority containing user info or any explicit port, including `:443` and zero-padded variants -> reject before URI normalization can erase that distinction.
- API code `86038` -> expired QR message and clean rescan path.
- Required environment list empty -> reject scene as malformed.
- Old generation completes -> discard without UI mutation, Toast, or confirmation.
- Controller/page closed -> discard late async completion.
- Scan Kit RemoteView or decode linkage failure -> release RemoteView and return `camera_unavailable` / `scanner_unavailable` / `decode_failed` as appropriate.
- No usable camera / Scan Kit init failure -> `camera_unavailable` without leaving a half-started scanner Activity.
- Authorization transport failure -> do not automatically retry the request; keep the current state recoverable and require an explicit user retry/rescan.
- Sensitive HTTP response/request failure -> log only redacted values.

### 5. Good/Base/Bad Cases

- Good: scan official QR, display target/location/environment, explicitly confirm, and PC polling succeeds.
- Good: select a large gallery image; it is sampled off-main-thread and decoded without broad storage permission.
- Good: start phone verification, then rescan; the old SMS result cannot populate the new authorization session.
- Base: manual URL submission on desktop uses the same strict parser and authorization UI.
- Bad: opening the official H5 in a normal WebView; it requires a BiliApp native bridge and attempts to launch the official app.
- Bad: allowing the global retry interceptor to replay `confirm`, captcha, or SMS requests after a response is lost.
- Bad: storing `qrcode_key` in route parameters, preferences, crash breadcrumbs, or logs.
- Bad: reading `Accounts.main` again at confirm time instead of using the account captured for the displayed scene.
- Bad: wiring Scan Kit only via a hard-coded local AAR without declaring Huawei Maven in Gradle (CI cannot resolve).

### 6. Tests Required

- URL unit tests: valid URL, lookalike host, HTTP, explicit port, user info, fragment, wrong path, duplicate/missing/invalid key.
- Explicit-port coverage must include HTTPS default port `:443`, because this is the normalization edge case that `Uri.hasPort` misses.
- Scene unit tests: target fields, environment parsing, risk flags, phone verification, safe optional defaults, required-empty environment rejection.
- Redactor tests: query form, JSON form, Dart Map form, recursive map keys, six-to-eight digit verification codes.
- Retry-interceptor coverage: requests carrying `RetryInterceptor.disableRetryKey` must immediately forward transport errors without invoking `Dio.fetch` again.
- GitHub Workflow: `flutter analyze`, `flutter test`, Android baseline-profile generation, and release Android build.
- Manual Android verification: camera cancel race, torch, permission denial, large gallery image, QR expiry, different-location confirmation, and SMS branch.
- Manual Android verification must include first camera launch on Android 16/OEM devices and assert the scanner opens with HMS Scan Kit RemoteView (no ML Kit component initialization).
- Manual Android verification must assert non-QR barcode formats are ignored.
- Manual Android verification on non-Huawei devices (no HMS Core account / no agconnect json) must still decode Bilibili web login QR codes via the scanplus local SDK path.

### 7. Wrong vs Correct

#### Wrong

```dart
final scene = await loadScene(keyA);
currentKey = keyB;
display(scene);
await confirm(currentKey);
```

This can display target A while authorizing key B.

#### Correct

```dart
final generation = beginAuthorization(account, key);
final scene = await loadScene(account, key);
if (!isCurrent(generation)) return;
display(scene);
await confirm(account, key);
```

The account, key, scene, and late-response guard remain one authorization session.

#### Wrong

```dart
LogInterceptor(); // prints raw captcha_key/qrcode_key response data
```

#### Correct

```dart
LogInterceptor(
  logPrint: (value) => debugPrint(LogRedactor.redactText(value.toString())),
);
```

The redactor must also understand Dart Map output such as `{captcha_key: secret}`.

#### Wrong

```dart
Request().post(confirmUrl, data: payload); // inherits automatic retries
```

If the server processed the request but the response was lost, the interceptor can replay a one-time authorization or SMS operation.

#### Correct

```dart
Request().post(
  confirmUrl,
  data: payload,
  options: Options(
    extra: {RetryInterceptor.disableRetryKey: true},
  ),
);
```

The failure is returned to the controller, and only an explicit user action starts another attempt.

#### Wrong

```kotlin
// CameraX + ZXing frame loop for web QR auth
```

#### Correct

```kotlin
// HMS Scan Kit RemoteView (camera) + ScanUtil.decodeWithBitmap (gallery)
// MethodChannel contract unchanged: pili_plus/android_qr_scanner
```
