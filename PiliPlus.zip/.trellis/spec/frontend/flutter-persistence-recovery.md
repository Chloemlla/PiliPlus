# Flutter Persistence and Recovery

## Scenario: Transactional settings, canonical accounts, startup session ordering, and recoverable background writes

### 1. Scope / Trigger

- Trigger: changing settings import/export, account refresh/import, WebDAV backup replacement, startup cookie/session wiring, or best-effort local persistence.
- Scope: `GStorage`, `SettingsImportTransaction`, `Accounts`, `LoginUtils`, `WebDav`, `Persistence`, and the audio heartbeat persistence/reporting seam.
- Goal: a failed write must be surfaced or compensated; it must not silently leave mixed generations or resurrect aliases.

### 2. Signatures

```dart
Future<void> replaceSettingsSections({
  required SettingsImportTarget setting,
  required SettingsSnapshot settingValues,
  required SettingsImportTarget video,
  required SettingsSnapshot videoValues,
  Future<void> Function()? applySupplemental,
  Future<void> Function()? restoreSupplemental,
  SettingsRollbackVerifier? verifySupplemental,
});

static void Accounts.configureSessionHandlers({
  required AccountActivator activateAccount,
  required AccountSessionCallback onMainLogin,
  required AccountSessionCallback onMainLogout,
});

static Future<void> LoginUtils.initializeSession();

Future<void> replaceWebDavBackup({
  required String officialPath,
  required String temporaryPath,
  required String backupPath,
  required List<int> data,
  required WebDavWrite write,
  required WebDavRead read,
  required WebDavExists exists,
  required WebDavCopy copy,
  required WebDavRename rename,
  required WebDavRemove remove,
});

static void Persistence.background(
  Future<void> operation, {
  required String label,
});
```

### 3. Contracts

#### Settings import transaction

- `SettingsBackupValidator` validates schema version and both sections before any box is cleared.
- Snapshot `setting`, `video`, and supplemental secret state before mutation.
- Apply the two boxes and supplemental state as one logical transaction.
- On any failure, independently attempt every box and supplemental rollback step even if an earlier rollback step fails, then verify the box snapshots with deep equality and the supplemental state with `verifySupplemental`.
- If rollback or verification fails, throw `SettingsImportRollbackException` containing both the import and rollback failures; never report a clean rollback when state drift remains.

#### Account canonicalization

- Persistent identity is `LoginAccount.secretKey`, never an imported map alias.
- Duplicate candidates are resolved deterministically: canonical source key first, then stable source-key order; merge their `AccountType` sets.
- Persist every selected canonical entry before deleting obsolete aliases.
- Do not delete an alias key when that key is the canonical key of another selected account.
- Replace `accountMode` only after persistence and alias cleanup succeed, so in-memory state does not get ahead of disk.
- `Accounts` owns data only and receives activation/login/logout callbacks; it must not import HTTP transport, `LoginUtils`, or page code.

#### Startup session order

The awaited order is:

```text
Request/Dio initialization
→ install AccountManager interceptor
→ configure account callbacks
→ Accounts.refresh()
→ await WebView cookie writes against https://www.bilibili.com/
→ logged-in business sync (coin/history/user data)
```

Cookie failures include the cookie name, but never its value.

#### WebDAV replacement

- Upload to a unique temporary path and byte-verify it before touching the official path.
- Probe the official path explicitly; only an actual not-found response means “no previous backup.”
- If the official file exists, its copy to `.bak` must succeed before rename is attempted.
- Rename failure restores `.bak` to the official path when possible; temporary cleanup is best effort and the failure is rethrown.
- Never swallow copy/network/auth failures as if the official file were absent.

#### Background persistence and heartbeat

- Await a write when the caller's success depends on it.
- Intentional best-effort writes use `Persistence.background` with a stable label; failures become handled crash diagnostics.
- Do not discard storage Futures directly.
- Backward audio seek resets the heartbeat throttle to the lower target, reports it immediately, then resumes normal thresholds.

### 4. Validation & Error Matrix

| Condition | Required behavior |
|---|---|
| Invalid/unknown settings section | reject before clearing either box |
| Second settings write fails | restore both box snapshots and supplemental secret |
| Rollback verification differs | throw `SettingsImportRollbackException` |
| Two account aliases share one `secretKey` | deterministic winner + merged account types |
| Canonical put succeeds, alias delete fails | keep retryable disk state; do not publish new `accountMode` |
| WebDAV official path is 404 | first upload may skip `.bak` copy |
| WebDAV probe/copy returns another failure | abort before rename |
| WebDAV rename removes official then fails | attempt `.bak` restore; surface failure |
| WebView cookie write fails | awaited startup/login failure names cookie only |
| Best-effort write fails | handled diagnostic with operation label |
| Heartbeat moves 1200 → 300 | immediately report 300; normal 5-second playing threshold resumes |

### 5. Good / Base / Bad Cases

- Good: valid settings import writes both boxes and a new WebDAV secret; a video-box failure restores all three states.
- Base: first WebDAV upload has no official file, verifies temp bytes, and renames once.
- Good: account aliases `a` and `b` resolve to key `123`; key `123` is written before `a`/`b` are deleted.
- Bad: catch every WebDAV copy error and continue rename because “the old file probably did not exist.”
- Bad: fire-and-forget `box.put(...)` without `Persistence.background` or `await`.
- Bad: mutate `Accounts.accountMode` before canonical data and alias cleanup finish.

### 6. Tests Required

- Settings: failure in either section, supplemental apply failure, supplemental restoration, and rollback verification failure.
- Accounts: deterministic duplicate resolution, alias cleanup ordering, conflicting alias/canonical keys, and deleted aliases do not reappear after refresh.
- Startup cookies: valid HTTPS origin, all writes awaited, and error diagnostics contain the cookie name only.
- WebDAV: upload mismatch, official-not-found, probe failure, old-copy failure, destructive rename failure + restore, and temp cleanup.
- Persistence: best-effort failures are routed to the central handled-error reporter through an injectable/testable seam where practical.
- Audio: backward seek immediate report and subsequent throttle boundary.
- CI: `python tool/check_import_boundaries.py` rejects new `utils -> pages`, `models -> pages`, HTTP/session cycles, and new raw page-layer storage writes.

### 7. Wrong vs Correct

#### Wrong

```dart
await setting.clear();
await setting.putAll(importedSetting);
await video.clear();
await video.putAll(importedVideo); // failure leaves mixed generations
```

#### Correct

```dart
await replaceSettingsSections(
  setting: settingTarget,
  settingValues: importedSetting,
  video: videoTarget,
  videoValues: importedVideo,
  applySupplemental: writeImportedSecret,
  restoreSupplemental: restorePreviousSecret,
);
```

#### Wrong

```dart
try {
  await client.copy(official, backup, true);
} catch (_) {}
await client.rename(temp, official, true);
```

#### Correct

```dart
if (await exists(official)) {
  await copy(official, backup, true); // failure aborts replacement
}
await rename(temp, official, true);
```

## Design Decisions

- Transaction helpers stay narrow and callback-driven so focused tests can inject exact failure positions without opening platform storage or a real WebDAV service.
- Core account storage is dependency-inverted through callbacks; transport/UI ownership stays outside `Accounts` and is guarded by the CI boundary script.

## Bilibili Settings and Search Sync

### 1. Scope / Trigger

- Trigger: Cross-repository settings/search synchronization through Synapse.
- Privacy boundary: the feature is available only while the main Bilibili account is logged in.

### 2. Signatures

- Client bind: `POST /api/bilibili-sync/uid` with `{uid, cookie}` and the existing Synapse JWT.
- Client sync: `GET /settings`, `PUT /settings`, `POST /search-records/batch`, and `GET /search-records/changes?since=...`.
- Local persistence: `SearchHistoryStore` keeps `{id, keyword, updatedAt, deleted}` tombstones in `historyWord`.

### 3. Contracts

- The bind cookie is sent only over HTTPS, validated by Bilibili `nav`, then stored server-side as AES-GCM ciphertext keyed by the Synapse user and verified UID.
- Settings exclude cookies, authorization values, tokens, passwords, API keys, and sync-internal keys, including nested values.
- Search records use a normalized keyword key and tombstones; incremental reads include tombstones.
- Synapse ordinary account authentication is completed in `flutter_inappwebview`; after the `/login` page sets the HttpOnly `synapse_token`, the client stores the session credential in the encrypted secret sidecar and never asks the user to paste a JWT.

### 4. Validation & Error Matrix

| Condition | Required behavior |
|---|---|
| No Bilibili login | Hide/disable sync and do not bind or upload |
| Invalid or mismatched cookie | Reject bind; never activate the archive |
| Missing/decryption-failed archive | Mark credential invalid and fail closed |
| Stale settings version | Return 409 with opaque summary; client asks local/remote/merge |
| Unbind | Remove ciphertext fields and mark credential invalid |

### 5. Good / Base / Bad Cases

- Good: a valid bind stores ciphertext metadata without returning the cookie; later sync revalidates the archived credential.
- Good: a search delete remains a tombstone until the other endpoint has received it.
- Bad: putting the Bilibili cookie in synced settings, logs, exceptions, or response data.
- Bad: attaching the Synapse request to the Bilibili account interceptor.

### 6. Tests Required

- Service: UID validation, cookie validation/UID match, ciphertext-only archive, revalidation failure, unbind cleanup, settings conflict, deduplication, and tombstones.
- Client contract: logged-out gating, sensitive nested-setting filtering, and conflict choices.
- CI is the authority for Flutter/Gradle and backend build/test execution; local checks remain static only.

### 7. Wrong vs Correct

#### Wrong

```dart
await client.put('/settings', data: {'cookie': account.cookieJar.toJson()});
```

#### Correct

```dart
await client.post('/uid', data: {'uid': account.mid.toString(), 'cookie': cookie});
// The backend validates and encrypts the cookie; sync payloads contain no cookie.
```

