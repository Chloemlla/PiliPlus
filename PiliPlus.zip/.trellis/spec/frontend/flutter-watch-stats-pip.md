# Flutter Watch Statistics and Persistent PiP

## Scenario: count real playback progress and restore one coherent PiP session

### 1. Scope / Trigger

- Trigger: player position/session tracking, watch-stat aggregation/export, Android/desktop PiP persistence, or player teardown.
- Scope: `WatchSessionTracker`, `WatchStatsService`, dashboard/controller widgets, `PipPersistentService`, player/audio metadata, and Android PiP mode callbacks.

### 2. Signatures

```dart
final class WatchSessionTracker {
  void begin({required WatchSessionMetadata metadata, required Duration position, required DateTime at});
  List<PendingWatchSession> onPosition({
    required Duration position,
    required DateTime at,
    required bool isPlaying,
    required bool isBuffering,
    required bool isSeeking,
    required double playbackSpeed,
  });
  List<PendingWatchSession> markSeek({required Duration position, required DateTime at});
  List<PendingWatchSession> flush(DateTime at);
  List<PendingWatchSession> finish(DateTime at);
}

class WatchStatsService {
  Future<void> init();
  Future<void> recordPendingSession(PendingWatchSession pending);
  WatchStatsData getStats(WatchStatsPeriod period, {DateTime? now});
  Future<String> exportAsJson();
  Future<String> exportAsCsv();
  Future<void> clearAll();
}

class PipPersistentService {
  void ensurePlatformCallbacks();
  Future<void> savePipState({required String bvid, required int cid, required int positionMs, String? title, String? cover});
  Duration? restorePositionFor({required String bvid, required int cid});
  Future<void> clearIfMatches({required String bvid, required int cid});
  Future<void> clearPipState();
}
```

### 3. Contracts

- Watch-stat Hive box: `watchStatsSessions`; adapter type id `102`; retain at most the current 90 local calendar days.
- Count media-position advances, not wall-clock time. Paused, buffering, seeking, backward jumps, implausibly large jumps, or events after five minutes of inactivity reset the baseline without adding time.
- Split durable sessions at local-day boundaries and persist complete seconds in 30-second chunks; flush remaining complete seconds on pause, video switch, completion, and final close.
- Session metadata includes `bvid`, title, author name, and numeric `authorMid`; the audio/background `MediaItem` path must preserve these fields.
- Week = today plus previous six days; month = today plus previous 29 days; all = retained range up to 90 days. Top creators aggregate by positive mid, falling back to normalized name; videos aggregate by bvid.
- Export JSON carries schema version and local-only marker. CSV must escape quotes, commas, and newlines.
- PiP stores exactly one versioned snapshot in `localCache`: bvid, cid, position milliseconds, save time, optional title/cover.
- Restore only when bvid and cid both match and age is between zero and 12 hours. Legacy PiP keys may be read once but are deleted with the current snapshot.
- Update PiP position while playing. Clear state on native PiP exit, natural completion, explicit close, or final player destruction; ordinary navigation reference-count returns must not clear it.
- Android native `modeChanged(false)` is authoritative for leaving system PiP. Desktop continues to use the existing mini-player/window capability.

### 4. Validation & Error Matrix

| Condition | Required behavior |
|---|---|
| empty bvid / non-positive watched time | do not persist watch session |
| paused, buffering, or seeking | no watch-time increment |
| backward or implausible position delta | reset baseline only |
| local date changes | flush prior-day whole seconds, then start new baseline |
| session older than 90 days | prune |
| malformed PiP map | ignore safely |
| PiP snapshot older than 12 hours or from the future | do not restore |
| bvid/cid mismatch | do not seek or clear another video's state |
| native PiP exits | clear current and legacy keys |
| route navigation keeps another player reference | preserve PiP state |

### 5. Good / Base / Bad Cases

- Good: position advances 30 real seconds at 1x while playing; one 30-second record is persisted even if wall time differs slightly.
- Good: seek 300s forward, then play 10s; only the post-seek 10s count.
- Base: dashboard opens before the box; controller awaits `init()` and renders a loading/error state.
- Good: Android recreates the activity in PiP; the same bvid/cid restores the saved position once.
- Bad: add `DateTime.now() - startedAt` as watched time or restore PiP by bvid alone.

### 6. Tests Required

- tracker: play/pause/buffer/seek/inactivity/day-boundary/playback-speed plausibility and 30-second chunking.
- aggregation: week/month/all boundaries, daily totals, top creator/video ordering, empty/unknown metadata.
- retention, JSON/CSV escaping, clear behavior, and Hive adapter id uniqueness.
- PiP JSON parsing, legacy migration read, matching restore, mismatch, future/expired state, mode-exit cleanup, final-dispose cleanup, and navigation reference-count preservation.
- Android channel assertion: `MainActivity.onPictureInPictureModeChanged` emits `modeChanged` without interfering with other MethodChannels.

### 7. Wrong vs Correct

#### Wrong

```dart
watchedSeconds += DateTime.now().difference(startedAt).inSeconds;
if (state.bvid == currentBvid) seek(state.position);
```

#### Correct

```dart
for (final pending in tracker.onPosition(/* real player state */)) {
  await WatchStatsService.instance.recordPendingSession(pending);
}
final restore = pip.restorePositionFor(bvid: bvid, cid: cid);
```

