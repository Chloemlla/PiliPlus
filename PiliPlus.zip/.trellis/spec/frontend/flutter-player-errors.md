# Flutter Player Error Handling

## Scenario: Recoverable media_kit stream errors

### 1. Scope / Trigger

- Trigger: `media_kit` emits `player.stream.error` from
  `lib/plugin/pl_player/controller.dart`.
- Scope: playback transport errors for remote HTTP/HTTPS media. Local file and
  codec errors follow their existing paths.

### 2. Signatures

```dart
abstract final class PlPlayerStreamError {
  static bool isNetworkOpenError(String event)
  static bool isInterruptedNetworkStream(String event)
}

Future<void>? refreshPlayer({bool play = true})
```

### 3. Contracts

- `Failed to open https://...`, `Can not open external file https://...`, and
  `tcp: ffurl_read returned ...` are recoverable network-open errors.
- `tcp: Connection to tcp://... failed: Connection refused` and
  `tcp: Failed to resolve hostname ...` are also recoverable network-open errors;
  classify them case-insensitively at the player boundary.
- `http(s): Stream ends prematurely at <received>, should be <expected>` is a
  recoverable interrupted stream, not an app crash.
- Recoverable playback transport errors must retry playback via
  `refreshPlayer()` and must not call `Utils.reportError`.
- Unknown non-audio-only player errors may still call `Utils.reportError`.

### 4. Validation & Error Matrix

- `dataSource is FileSource` and failed local open -> ignore in player error
  listener.
- live stream network-open or interrupted stream -> delayed `refreshPlayer()`.
- non-live network-open error before initial buffer -> throttled retry with the
  existing "video link open failed" toast.
- non-live interrupted HTTP stream -> throttled retry with the "stream
  interrupted" toast and the play state captured when the error arrived.
- codec-open error -> user toast only.
- unknown non-audio-only error -> crash reporter path.

### 5. Good/Base/Bad Cases

- Good: classify transport error strings in `PlPlayerStreamError` and cover
  them with unit tests.
- Base: add a new recoverable media_kit transport message by extending the
  classifier and retry matrix.
- Bad: call `Utils.reportError(event)` for CDN/network short-read messages.

### 6. Tests Required

- Assert `https: Stream ends prematurely at 43579125, should be 66466136`
  returns `true` from `isInterruptedNetworkStream`.
- Assert unrelated errors such as `Could not open codec` remain outside the
  recoverable network classifiers.
- Assert existing network-open strings continue to return `true` from
  `isNetworkOpenError`.
- Assert TCP connection-refused and hostname-resolution messages retry playback
  instead of entering crash history.

### 7. Wrong vs Correct

#### Wrong

```dart
if (!onlyPlayAudio.value) {
  Utils.reportError(event);
}
```

#### Correct

```dart
if (PlPlayerStreamError.isInterruptedNetworkStream(event)) {
  _retryInterruptedNetworkStream(playAfterRefresh: playerStatus.isPlaying);
} else if (!onlyPlayAudio.value) {
  Utils.reportError(event);
}
```
