# Flutter Seal Download Delegate

> Executable contracts for PiliPlus → Seal L3 external download (MethodChannel + status panel).
> Sources: `lib/pages/video/seal_download_utils.dart`,
> `android/.../SealDownloadChannel.kt`.
> Seal-side protocol: `EXTRA_URL` / `EXTRA_URLS` (`"url"` / `"urls"`).

---

## Scenario: Invoke blank delay + multi-P batch

### 1. Scope / Trigger

- Cross-layer: Dart MethodChannel → Kotlin Intent → Seal QuickDownloadActivity.
- UX bug class: **awaiting `SmartDialog.show` dismiss Future** blocks `delegateDownload` until the user taps 「后台等待」.
- Feature: same-`bvid` multi-page (`pages.length > 1`) batch delegate via `urls[]`.

### 2. Signatures

**Dart (`SealDownloadUtils`)**

```dart
static Future<void> downloadVideo(VideoDetailController ctr);
static Future<void> downloadAudio(VideoDetailController ctr);
// Both forward to:
static Future<void> promptDownload(
  VideoDetailController ctr, {
  required bool extractAudio,
});
// Internal:
static Future<void> _download(
  VideoDetailController ctr, {
  required bool extractAudio,
  List<String>? urls,
  int? itemCount,
});
static String? pageUrlOf(VideoDetailController ctr);
static String pageUrlForPart(String bvid, Part part, int indexInFullPagesList);
```

**Kotlin (`SealDownloadChannel.delegateDownload`)**

```kotlin
// MethodChannel method: "delegateDownload"
// args: url, urls, extractAudio, autoStart, openUi, requestId,
//       stripSegments?, keepSections?,
//       cookiesFormat?, cookies?, cookiesMid?, cookiesDomainHint?,
//       useCookies?, cookiesRequired?
// Intent extras: EXTRA_URL, EXTRA_URLS, extract_audio, auto_start, open_ui,
//                caller_request_id, protocol_version,
//                strip_segments, keep_sections,
//                cookies_format, cookies, cookies_mid, cookies_domain_hint,
//                use_cookies, cookies_required
```

### 3. Contracts

| Field | Layer | Type | Notes |
|-------|-------|------|-------|
| `url` | Dart→Kotlin | `String` | Always first/primary URL (compat) |
| `urls` | Dart→Kotlin | `List<String>` | Full batch; single-item list for one URL OK |
| `EXTRA_URL` | Kotlin→Seal | `String` | First URL |
| `EXTRA_URLS` | Kotlin→Seal | `String[]` | Key **exactly** `"urls"` |
| `extractAudio` / `extract_audio` | both | `Boolean` | Audio-only |
| `autoStart` / `auto_start` | both | `Boolean` | From `Pref.sealAutoStart` |
| `openUi` / `open_ui` | both | `Boolean` | Default `true` |
| `requestId` / `caller_request_id` | both | `String` | Session correlation |
| `stripSegments` / `strip_segments` | both | `Boolean` | Enable Approach C strip (PiliPlus marks → keep ranges) |
| `keepSections` / `keep_sections` | both | `String` (JSON) | Array of `{start,end}` in **seconds**; Seal → `videoClips` / `--download-sections` |
| `cookiesFormat` / `cookies_format` | both | `String` | Primary: `"json_map"` |
| `cookies` / `cookies` | both | `String` | JSON name→value map; **never log** |
| `cookiesMid` / `cookies_mid` | both | `Long`/int | Non-secret mid |
| `cookiesDomainHint` / `cookies_domain_hint` | both | `String` | Default `.bilibili.com` |
| `useCookies` / `use_cookies` | both | `Boolean` | true when payload attached |
| `cookiesRequired` / `cookies_required` | both | `Boolean` | Default false (soft) |
| `protocol_version` | Kotlin→Seal | `Int` | `1` legacy; `2` cookie-only; **`3` for strip concat + outcome reporting** |

**Strip protocol (v3)**

- PiliPlus owns segment filter/merge/invert (`segment_strip_math`) and the detailed removal report UI.
- **Mark source is 空降助手 only**: `SponsorBlock.getSkipSegments(bvid, cid)` (not Seal built-in SB).
- Multi-P strip: one Seal task per part (per-cid `keep_sections`); categories asked once when always-ask.
- Units for `keep_sections`: **seconds** (fractional OK). Seal floors start / ceils end to `VideoClip` integer seconds.
- Strip requests use protocol v3. Seal keeps these ranges in a dedicated
  `stripKeepSections` task field; it must not reuse ordinary `videoClips` output semantics.
- Protocol v1 ignores strip/section extras. Protocol v2 keeps its cookie and ordinary
  multi-clip behavior; dedicated `strip_segments` concat is enabled only for v3.
- Seal downloads keep ranges into a task-scoped temporary directory, concatenates them in
  chronological order with embedded FFmpeg, and exposes exactly one completed media file.
- Ordinary user-authored `videoClips` continue to export separate timestamped clips.
- If range download or concat is unavailable/fails, Seal removes task-scoped partial files,
  downloads one full source into the private task workspace, then applies every keep range with
  FFmpeg ffconcat `inpoint` / `outpoint` entries.
- Both section concat (C) and full-source post-process (D) complete with
  `strip_result=applied` only after one stripped file is finalized. If D also fails, Seal cleans
  the task workspace and sends `status=failed` + `strip_result=failed`; it never exposes an
  unstripped full source as successful.
- L3 reporting reads the actual completed `StripResult`; `stripRequested + Completed` must never
  be used to synthesize `applied`. An anomalous completed task without actual `Applied` is
  reported and rendered as failed, without open/share actions.
- Cancellation remains registered from workflow start through finalization, kills yt-dlp/FFmpeg,
  never enters D after cancellation, and rolls back a partially-created SAF document. Cache and
  SD-card staging directories are removed on every terminal path.
- PiliPlus presents the local detailed report and appends `[去广告]` only for confirmed
  `strip_result=applied`. A completed strip task without `applied` is rendered as failed and has
  no open/share actions.
- Default strip categories: `sponsor` + `selfpromo`; never default `poi_highlight`.
- No removable marks → normal download + toast (not a hard fail).
- Multi-P UI launches one independent single-URL strip task per selected part. A single delegate payload containing multiple URLs must disable strip and continue as a normal batch with a toast.
- Report is local to PiliPlus (not returned by Seal).

**Cookie protocol (v2 additive)**

- Master switch: `Pref.sealCookiePassthrough` (default **true**).
- Remember: `sealCookieRemember` + `sealCookieRememberMid` (0 = none); always-ask: `sealCookieAlwaysAsk`.
- Flow order: multi-P -> strip prep -> account/cookie resolve -> non-blocking panel -> `delegateDownload`.
- Accounts: `Accounts.account.values` with `hasRequiredCookies` / `shouldKeep`.
  - Remembered mid valid + !alwaysAsk -> skip sheet.
  - Single account + !alwaysAsk -> auto-use.
  - Multi or alwaysAsk -> bottom sheet (mid/uname, remember toggle, anonymous, cancel).
- Payload: `jsonEncode(cookieJar.toJson())`, `cookies_format=json_map`.
- Soft preflight: require `DedeUserID` + `bili_jct`; soft-cap ~200 KiB; else anonymous.
- Never log cookie values (only mid, key count, byte length).
- `cookies_required=false` so Seal accept-off still downloads without cookies.
- Intent extras: `cookies_format`, `cookies`, `cookies_mid`, `cookies_domain_hint`, `use_cookies`, `cookies_required`.
- `protocol_version=2` for cookie-only requests; strip requests use v3.


Example `keep_sections`:

```json
[{"start":0.0,"end":12.5},{"start":45.0,"end":120.0}]
```

**URL shape (UGC)**

```
https://www.bilibili.com/video/{bvid}?p={page}
```

- `page` = `Part.page ?? (indexInFullPagesList + 1)` — index must be against the **full** `pages` list, never a selected subset.
- Bangumi/ep: `${baseUrl}/bangumi/play/ep$epId` only (no season batch in MVP).
- Multi-P menu only when: Android, UGC, `!isFileSource`, `epId == null`, `pages.length > 1`.

**Media title resolution (session meta)**

- Sources: `lib/utils/seal_download_title.dart` (`resolveSealMediaTitle`), called from `SealDownloadUtils._titleOf`.
- `VideoDetailController.watchLaterTitle` is `String` default `''` (not `late`). Only assigned when `isPlayAll` (`args['favTitle']`).
- `_titleOf` must prefer **controller-cached** `ctr.args` over live `Get.arguments` (intermediate routes like `PublishRoute` can replace global arguments).
- Pure order: route `title` → route `favTitle` → non-empty `watchLaterTitle` → `bvid`.
- Never read `watchLaterTitle` as if it were always initialized; empty default is safe for normal `/videoV`.
- Unit tests: `test/utils/seal_download_title_test.dart`.

**Panel lifecycle (R1)**

1. Set session phase/message (`waitingUi` / `waitingAuto`).
2. **Non-blocking** show panel: `_showOrUpdatePanel` must **not** await `SmartDialog.show` dismiss.
3. Immediately `invokeMethod('delegateDownload', ...)`.
4. 「后台等待」 = dismiss panel only; keep session for late status.

### 4. Validation & Error Matrix

| Condition | Error / UX |
|-----------|------------|
| No URLs after resolve | Error panel: 无法构造视频链接 |
| Seal not installed | `PlatformException(code: not_installed)` → `notInstalled` panel |
| Empty `url` and empty `urls` (Kotlin) | `invalid_url` |
| `strip_segments=true` with no valid keep range | `invalid_sections` |
| User cancels multi-P sheet / empty selection | No launch |
| User cancels cookie sheet | No launch |
| No login / passthrough off / anonymous | Launch without cookie extras |
| Incomplete cookies / payload too large | Toast + anonymous launch |
| Seal `cookie_denied` / `cookies_disabled` | Rejected panel: external cookies not allowed |
| Seal `cookie_invalid` / `cookie_too_large` | Rejected panel with mapped message |
| Activity not found | `not_installed` |
| Strip `completed` + `strip_result=applied` | Show `[去广告]`, open/share actions, and the detailed local report |
| Strip `completed` without `applied` | Protocol violation; render failed, clear file actions, and do not show the report |
| Strip C and D both fail | Failed/retryable panel; never reinterpret a full original as completed |

### 5. Good / Base / Bad Cases

- **Good**: Multi-P select P3+P5 with null `Part.page` → URLs use original indices 2 and 4 → `?p=3` / `?p=5`.
- **Base**: Single-P video → one-tap, `urls: [one]`, panel parallel with Seal.
- **Bad**: `await SmartDialog.show` before `delegateDownload` → blank wait until 后台等待.
- **Bad**: `pageUrlsForParts(subset)` with subset indices when `Part.page == null` → wrong `?p=`.
- **Bad**: Current-P fallback to `pages.first` when `pageUrlOf` fails → wrong P.
- **Bad**: `_titleOf` reading bare `late watchLaterTitle` on normal `/videoV` → `LateInitializationError`.
- **Bad**: `_titleOf` using only live `Get.arguments` after intermediate route push/pop → wrong/missing title.
- **Good**: normal video (`watchLaterTitle == ''`, no route title) → `resolveSealMediaTitle` returns `bvid`, no crash.

### 6. Tests Required

- Unit (Dart): `pageUrlForPart` / multi select indices → correct `?p=` for non-contiguous selection.
- Unit (Dart): v3 status parsing and report/UI gating on terminal `strip_result=applied`.
- Seal focused tests: C failure enters D after cleanup; D success is `applied`; C+D failure fails; cancellation skips D; cleanup always runs.
- Manual: multi-P 当前 / 选择 / 全部; auto_start on/off; not_installed.
- Assertion: `_download` schedules panel then calls channel without waiting for dismiss.

### 7. Wrong vs Correct

#### Wrong

```dart
await SmartDialog.show(...); // completes only on dismiss
await _channel.invokeMethod('delegateDownload', ...);
// select subset:
for (var i = 0; i < selected.length; i++)
  pageUrlForPart(bvid, selected[i], i); // wrong if Part.page null
```

```kotlin
// Intent has NO putStringArrayExtra — fails :app:compile*Kotlin in GHA
putStringArrayExtra(EXTRA_URLS, urls.toTypedArray())
```

#### Correct

```dart
unawaited(SmartDialog.show(...)); // or unawaited(_showOrUpdatePanel)
await _channel.invokeMethod('delegateDownload', {
  'url': primaryUrl,
  'urls': resolvedUrls,
  ...
});
// select: keep full-list indices
for (final i in selectedIndices)
  pageUrlForPart(bvid, pages[i], i);
```

```kotlin
// String[] extras use putExtra(name, Array<String>)
putExtra(EXTRA_URL, url) // first URL compat
putExtra(EXTRA_URLS, urls.toTypedArray()) // key "urls"
```

---

## Design Decision: Multi-P menu in utils not header_control

**Context**: Entry was one-shot `downloadVideo`/`downloadAudio` from more-menu.

**Decision**: `promptDownload` inside `SealDownloadUtils`; wrappers keep header_control call sites unchanged.

**Why**: URL construction, session, and picker stay co-located with channel payload; menu file stays thin.

---

## Common Mistakes

1. **Await dialog show Future** — blocks Seal launch (R1 root cause).
2. **Subset list index as `?p=`** — use original `pages` index when `Part.page` is null.
3. **Omitting `EXTRA_URLS`** — Seal multi-URL path never sees batch.
4. **Offering multi-P for bangumi ep** — out of scope; keep single ep URL.
5. **`Intent.putStringArrayExtra`** — does not exist; use `putExtra(EXTRA_URLS, urls.toTypedArray())` or GHA `:app:compileNonMinifiedReleaseKotlin` fails with `Unresolved reference 'putStringArrayExtra'`.

6. **Logging cookie values** — only mid / key count / byte length in debug.
7. **Sending cookies with protocol_version=1** — Seal ignores cookie fields on v1; channel must bump to 2 when payload present.
8. **Hard-fail when Seal accept-cookies is off** — use `cookies_required=false` so download can continue without external cookies.
9. **Treating strip keep ranges as ordinary `videoClips`** — multiple sections then become
   multiple exported files. Use the dedicated concat task field and report `strip_result`.
10. **Showing the removal report before terminal `strip_result=applied`** — an unconfirmed or
    failed post-process would otherwise be mislabeled as ad-stripped.
11. **Treating D as an original-media success fallback** — D must apply the same keep ranges to
    the temporary full source; if that post-process fails, fail the task and clean the workspace.

---

## Scenario: Persisted download manager and caller-owned task control

### Data flow and ownership

```text
Seal DOWNLOAD_STATUS / control Activity result
→ SealDownloadStatusBridge (Android payload extraction)
→ SealDownloadChannelDispatcher (sole Dart MethodChannel handler)
→ SealDownloadUtils panel + DownloadManagerService listeners
→ bounded DownloadTaskRepository + reactive queue UI
```

- `SealDownloadChannelDispatcher` is the only Dart owner allowed to call
  `setMethodCallHandler` for `pili_plus/seal_download`. Consumers register typed
  listeners; they must not replace each other's handler.
- Live fields are `task_id`, `task_ids`, `caller_request_id`, `status`,
  `progress`, `downloaded_bytes`, `total_bytes`, `title`, `quality`,
  `source_url`, `extract_audio`, and the existing terminal file/error fields.
- Parse runtime payloads defensively. Progress accepts `0.0..1.0` (or a
  percentage value up to 100) and clamps to the inclusive range; byte counts
  are non-negative integers.
- Expand `task_ids` into one typed event per Seal task. Stable queue identity
  is `taskId ?? callerRequestId`; this keeps tasks in one batch distinct while
  allowing a pre-accept request row to upgrade to its real task id.

### Status and control contracts

- Map `accepted` / `queued` to waiting, `fetching` / `downloading` / `progress`
  to downloading, plus paused/completed/failed.
- A natural Seal `canceled` event removes the local row. An explicit pause is
  reported as `paused`, not canceled.
- `taskAction` launches Seal's explicit standard-mode
  `ExternalDownloadControlActivity` with its own request code. Actions are
  `pause`, `resume`, `retry`, and `delete`; send both task id and request id
  when available.
- Seal authorizes control from `Activity.callingPackage` only. It persists a
  bounded task-to-caller ownership record so paused/failed tasks remain
  resume/retry capable after process restart.
- If Seal restarts while an owned task was waiting/downloading, queue backup
  restores it as canceled internally; ownership recovery must reclassify that
  specific restart interruption as paused. A normal runtime cancellation with
  no pause marker remains terminal canceled.
- Failed and paused tasks retain ownership/task cookies. Completed, canceled,
  or deleted tasks clean them up. A natural cancellation stays terminal.

### Persistence and startup recovery

- Persist typed task JSON in `LocalCacheKey.sealDownloadTaskHistory` through
  `DownloadTaskRepository`; skip malformed rows and keep at most 200 unique
  tasks, with active tasks before newest terminal history.
- Serialize repository writes so a slower prior write cannot overwrite a
  newer snapshot. Route best-effort write failures through
  `Persistence.background` with a stable label.
- `registerFeatureServices()` may await `DownloadManagerService.initialize()`
  for deterministic restore ordering, but download management is optional.
  History/storage/channel initialization failures must be caught inside the
  service, recorded as handled diagnostics (`module=download_manager`), and
  must never abort app startup.
- Data reset must clear the feature-owned repository before shared storage is
  cleared.

### Required focused tests

- Dart: task identity/batch expansion, status metadata parsing, JSON
  round-trip/bounds, and history restore failure completing without throwing
  while emitting a handled diagnostic callback.
- Seal JVM: ownership bounding/caller validation, control action parsing,
  running progress/byte snapshots, explicit pause recovery, and natural
  cancellation remaining terminal.
