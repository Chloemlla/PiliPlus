# Flutter Startup Context

## Scenario: Startup dialogs from app builder wrappers

### 1. Scope / Trigger

- Trigger: Flutter widgets inserted from `MaterialApp.builder` or
  `GetMaterialApp.builder` need to show dialogs, push routes, or access a
  `Navigator`.
- Scope: app-start gates and services that run before the first user screen is
  fully interactive.

### 2. Signatures

```dart
static Future<void> requestMissingPermissions()
static NavigatorState? _currentNavigator()
```

### 3. Contracts

- A widget context owned by a builder wrapper must not be passed directly to
  `showDialog`, `Navigator.of`, or route push helpers.
- Startup services that need navigation must resolve the active root navigator
  from `Get.key.currentState`.
- If the navigator is not ready, retry after a frame and do not mark the flow as
  completed.
- After an async permission or settings operation, resolve the navigator again
  before showing the next dialog.

#### First-launch improvements guide

- Flag: `SettingBoxKey.firstLaunchImprovementsGuideSeen`
- Entry: `FirstLaunchImprovementsGuideGate` in `MaterialApp.builder`
- Show path: `FirstLaunchImprovementsGuideService.maybeShow()` pushes a
  fullscreen `ImprovementsGuidePage` only when the flag is unset
- Content: static `ImprovementsGuideData.pages` (branch deltas vs upstream)
- Completion: skip / last-page CTA / system back call `onFinished` (`markSeen`)
  then **force-pop** the route (`Navigator.pop`, not `maybePop`). After
  `navigator.push` returns, Android calls
  `AndroidFirstLaunchPermissionService.requestMissingPermissions()`.
- Manual reopen: About →「本分支改进说明」via `openManual(markAsSeen: false)`
- Ordering: open-source notice → improvements guide → Android first-launch
  permission dialogs. Improvements guide returns early while OSS notice flag is
  false; permission service returns early while the improvements guide flag is
  false and does **not** busy-retry each frame.

#### First-launch open-source notice

- Flag: `SettingBoxKey.firstLaunchOssNoticeSeen`
- Entry: `FirstLaunchOssNoticeGate` (outermost first-launch gate)
- Show path: `FirstLaunchOssNoticeService.maybeShow()` pushes fullscreen
  `OssNoticePage`
- Content: source URL, permanent-free / anti-scam notice, project GPL-3.0, and
  curated third-party credits (`OssNoticeData.credits`: name/author/description/license/url)
- Completion: continue / system back call `onFinished` (`markSeen`) then
  **force-pop**. After `navigator.push` returns, call
  `FirstLaunchImprovementsGuideService.maybeShow()`.
- Manual reopen: About →「开源声明与第三方鸣谢」via `openManual(markAsSeen: false)`

#### First-launch returning-user migration

- Entry: `FirstLaunchMigration.ensureSeenFlagsForReturningUsers()` from OSS /
  improvements / Android permission first-launch services (idempotent).
- Returning-user evidence (any): logged-in account, non-empty account box,
  non-empty `userInfo` / `historyWord` / `watchProgress`, non-bootstrap
  `localCache` keys, or any `setting` key other than the three first-launch
  flags.
- Bootstrap-only `localCache` keys (`buvid`, `timeStamp`, `mixinKey`) are **not**
  upgrade evidence (anonymous cold start writes them).
- Bootstrap-only `setting` keys (`horizontalScreen`, `fullScreenMode`,
  `dynamicColor`, `displayMode`) are **not** upgrade evidence. Mobile cold start
  always seeds `Pref.horizontalScreen` before first-launch gates.
- Empty/non-empty `video` box is also upgrade evidence when present.
- On returning user: set `firstLaunchOssNoticeSeen`,
  `firstLaunchImprovementsGuideSeen`, and
  `androidFirstLaunchPermissionsRequested` to true so upgrades do not re-run
  the chain.
- Mid-chain first installs (only first-launch flags progressing, no durable
  usage) must continue and must not be silenced.


#### Build-scoped what's-new guide

- Keys: `SettingBoxKey.whatsNewAckCommitHash` + `SettingBoxKey.whatsNewAckBuildTime`
- Identity: `BuildConfig.commitHash` + `BuildConfig.buildTime`
- Entry: `WhatsNewGuideGate` in `MaterialApp.builder` (after improvements guide)
- Show path: `WhatsNewGuideService.maybeShow()` only when first-launch OSS + improvements flags are true **and** stored identity differs from current build
- Content: static `WhatsNewData.pages` (intentional upstream/UI changes for this build). **Every user-facing commit must refresh these pages** — full contract in [flutter-build-whats-new.md](./flutter-build-whats-new.md).
- First install: after improvements guide completes, mark current build acknowledged so the same install does not immediately re-open what's-new
- Upgrade: returning users skip first-install chain via migration; only what's-new opens when build identity changes
- Completion: skip / last-page CTA / system back write current hash+time then force-pop
- Manual reopen: About →「本次更新说明」via `openManual(markAsSeen: false)`
- Ordering: crash report > OSS notice > improvements guide > what's-new > Android permissions
#### Startup overlay coordination

- Shared helper: `StartupOverlayCoordinator` (`Get.key` navigator resolve,
  limited post-frame retries, crash-active wait).
- First-launch push/dialog steps use `runWhenNavigatorReady` (default 3 rounds
  × 30 frames) so a single late navigator window does not permanently skip a
  step in the current cold start.
- Priority: crash report > OSS notice > improvements guide > what's-new > Android permissions.
- `CrashReportStartupGate` claims crash-active in `initState` when an initial
  report exists, `await`s its fullscreen route, then releases crash-active so
  first-launch flows can proceed.
- First-launch services `await StartupOverlayCoordinator.waitUntilCrashIdle()`
  before pushing.
- Navigator resolve uses `waitForNavigator` (default 30 frames), not a single
  one-shot post-frame retry.

#### Onboarding PopScope

- OSS / improvements pages are pushed with `MaterialPageRoute` and must use
  Flutter Material `PopScope` bound to that route.
- Do **not** use `common/widgets/flutter/pop_scope.dart` there; that helper
  registers against `Get.routing.route` and mis-binds Material fullscreen
  onboarding.
- Keep `SafeArea` **or** manual `viewPadding` insets, not both.

### 4. Validation & Error Matrix

- `Get.key.currentState == null` -> schedule a frame retry and return.
- `NavigatorState.mounted == false` -> return without completing the startup
  flow.
- User declines a permission explanation -> continue to the next permission.
- Runtime permission permanently denied -> show the app settings dialog when a
  navigator is still available.
- Guide flag already true -> do not auto-show guide; permission flow may run.
- Guide not seen yet -> permission service returns without scheduling frame
  spam; guide completion re-enters permission flow.
- OSS notice not seen yet -> improvements guide returns without showing; OSS
  completion re-enters improvements guide.
- First-launch page uses `PopScope(canPop: false)` -> close path must
  `Navigator.pop()`; `maybePop()` is a no-op and leaves the user stuck.
- Next first-launch step must start **after** the current route is popped, not
  inside `onFinished` while that route is still on the stack.
- Returning user without first-launch flags -> migration marks all three flags;
  no auto onboarding chain.
- Crash report pending at cold start -> first-launch waits until crash route
  completes.
- About manual open -> `markSeenOnClose: false`, system back pops freely.

### 5. Good/Base/Bad Cases

- Good: first-launch permission service resolves `Get.key.currentState.context`
  immediately before each dialog.
- Base: a normal page widget uses its own page context for user-initiated
  dialogs.
- Bad: a wrapper inserted around the app builder child passes its own
  `BuildContext` to `showDialog`.
- Good: first install shows improvements guide once, then Android permission
  reasons.
- Good: first install shows OSS notice, then improvements guide, then
  permissions.
- Bad: permission dialogs and guide pushed concurrently, or permission service
  polls every frame while guide is open.
- Bad: `_completeAndClose` uses `maybePop` while `canPop: false`.
- Bad: `onFinished` pushes the next first-launch route before the current one
  is popped.

### 6. Tests Required

- Assert startup permission flow does not call `showDialog` when the navigator
  is unavailable.
- Assert navigator-unavailable startup does not set the "completed" storage
  flag.
- Assert dialog calls use a navigator context once `Get.key.currentState` is
  available.
- Assert first-launch guide is not pushed when
  `firstLaunchImprovementsGuideSeen == true`.
- Assert guide completion sets the seen flag, force-pops the guide route, and
  only then invokes Android permission request on Android.
- Assert OSS notice completion force-pops before improvements guide is pushed.
- Assert returning-user migration marks the three first-launch flags and skips
  auto show.
- Assert first-launch does not push while crash overlay is active.
- Assert onboarding Material routes use Material `PopScope`, not the Get-route
  helper.

### 7. Wrong vs Correct

#### Wrong

```dart
WidgetsBinding.instance.addPostFrameCallback((_) {
  PermissionService.requestMissingPermissions(context);
});
```

#### Correct

```dart
WidgetsBinding.instance.addPostFrameCallback((_) {
  PermissionService.requestMissingPermissions();
});

static NavigatorState? _currentNavigator() => Get.key.currentState;
```

#### Wrong (guide/permission race)

```dart
if (!guideSeen) {
  _scheduleRetry(); // every frame while guide open
  return;
}
```

#### Correct

```dart
if (guideSeen != true) {
  return; // guide completion re-enters permission flow
}
```

#### Wrong (blocked pop)

```dart
// PopScope(canPop: false) on first-launch pages
Navigator.of(context).maybePop(); // no-op, user stays on guide
```

#### Correct

```dart
Navigator.of(context).pop(); // force-pop after onFinished markSeen
```

#### Wrong (stack next step under open page)

```dart
onFinished: () async {
  await markSeen();
  await nextFirstLaunchStep(); // pushes while current route still open
}
```

#### Correct

```dart
await navigator.push(... page with onFinished: markSeen);
// push returned => route already popped
await nextFirstLaunchStep();
```
