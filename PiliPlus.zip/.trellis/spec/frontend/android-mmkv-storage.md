# Android MMKV Storage

## Scenario: Android GStorage MMKV-backed boxes

### 1. Scope / Trigger

- Trigger: Android storage/cache integration under `lib/utils/storage.dart` and `lib/utils/android/android_mmkv_box.dart`.
- Scope: `GStorage` boxes that are non-sensitive and can be deterministically encoded, including the independent local-comment favorite store.

### 2. Signatures

```dart
Future<Box<E>> openAndroidMmkvBackedBox<E>({
  required String name,
  required Future<Box<E>> Function() openHive,
  KeyComparator? keyComparator,
  AndroidMmkvValueEncoder<E>? valueEncoder,
  AndroidMmkvValueDecoder<E>? valueDecoder,
  AndroidMmkvStoreBackend store = const AndroidMmkvStore(),
  bool? isAndroid,
  AndroidMmkvLoadMode loadMode = AndroidMmkvLoadMode.eager,
})
```

`AndroidMmkvLoadMode.eager` decodes all values on open.  
`AndroidMmkvLoadMode.lazy` loads keys only and materializes values on first access.

Backend seams include: `exportBox`, `exportKeys`, `getRaw`, `containsKey`,
`putRaw`, `putAllRaw`, `removeRaw`, `removeAllRaw`, `replaceBox`, `clearBox`, `sync`.

```dart
final class FavoriteReplyStore extends BoundedUint8ListStore {
  Future<void> migrateLegacy({
    required Box<Uint8List> legacyBox,
    required Box<dynamic> markerStore,
  });
}

Future<Box<Uint8List>?> prepareLegacyReplyStorage({
  required bool shouldSaveReply,
  required bool shouldMigrateFavorites,
  required Future<Box<Uint8List>> Function() openLegacyBox,
  required FavoriteReplyStore destination,
  required Box<dynamic> markerStore,
  required FavoriteReplyStartupErrorHandler onError,
});
```

### 3. Contracts

- Android with MMKV available: migrate Hive entries to MMKV once, then reopen from MMKV using `migrated:<box>:v1`.
- Non-Android or MMKV unavailable: call `openHive` and preserve existing Hive behavior.
- Value format: each entry is a JSON object with a `value` field; app-model values use codecs.
- Suitable boxes: `setting`, `video`, `watchProgress`, `historyWord`, `localCache`, `userInfo`, `reply`, `favoriteReply`.
- Excluded: `Accounts.account`.
- **Load path**:
  - Prefer single-key `getRaw` for meta markers.
  - Eager boxes use `exportBox` once on open.
  - Lazy boxes use `exportKeys` on open; values decode via `getRaw` (or bulk `exportBox` when materializing many keys).
- **Startup staging**: open critical preference boxes first; open large `watchProgress` after prefs so `Pref` is usable sooner. `favoriteReply` is always opened lazily; the legacy automatic-recording `reply` box remains optional after migration.
- **Batch writes**: `putAll` / `deleteAll` use incremental batch APIs, not whole-box `replaceBox`.
- **Sync policy**: daily put/delete do not `sync()`. `flush` may sync. `close` and `compact` must not force expensive sync.
- **Capacity**:
  - `WatchProgressStore` max 2000, write-order LRU.
  - `ReplyCacheStore` max 500, write-order LRU.
  - `FavoriteReplyStore` max 500, independent write-order LRU.
  - Search history list capped at 100 entries.
  - Order meta in `localCache`.
- **Comment-favorite ownership**:
  - Explicit favorite/unfavorite/import/export always uses `FavoriteReplyStore`; it must not depend on `Pref.saveReply`.
  - Automatic reply recording uses nullable `ReplyCacheStore` and remains controlled by `Pref.saveReply`.
  - Upgrade marker: `LocalCacheKey.favoriteReplyMigrationV1`.
  - While the marker is unset, open the legacy `reply` box even when automatic recording is disabled, copy only missing entries into unused favorite capacity, and never delete the legacy source.
  - Existing explicit favorites win over migrated entries; retrying migration must not evict them.
  - Write the marker only after all selected copies succeed. Open/copy failure records a handled diagnostic, leaves the marker unset, continues startup, and disables automatic recording for that session so the retry source cannot be mutated or evicted.
  - Full storage clear must clear both typed stores before `localCache`, then write the migration marker so an unopened legacy source cannot resurrect deleted favorites.
- **Settings import rollback**: after any failed import, independently attempt
  restoration of `setting`, `video`, and supplemental secret state even when an
  earlier rollback step fails. Verify every readable snapshot and report the
  combined rollback failures instead of hiding partial recovery.

### 4. Validation & Error Matrix

- MMKV unavailable -> Hive.
- Migrated but undecodable -> `StateError`, including values discovered during
  lazy materialization; do not restore stale Hive or silently treat corruption
  as a missing key.
- Unsupported encode on write -> `UnsupportedError`.
- Native write/remove/clear/sync fail -> `StateError`.
- Failed batch put/delete restores and verifies the backend snapshot before
  returning, while cache and watch events remain unchanged. If a pre-write
  snapshot cannot be obtained, the batch must not start.
- Lazy get materializes only the requested key when possible.
- Legacy favorite open/copy fails -> continue startup, keep source + unset marker, retry next launch.
- Migration retry with explicit favorites already present -> fill remaining capacity only; never evict explicit favorites.
- Full clear with legacy box unopened -> clear visible stores and set the marker; old legacy bytes must not reappear as favorites.
- Settings import rollback step fails -> still attempt both box snapshots and
  supplemental secret restoration, then surface a rollback exception with the
  failed operations.

### 5. Good / Base / Bad Cases

- Good: automatic recording is off, but an explicit favorite is written to `favoriteReply` and remains visible after restart.
- Good: a failed legacy copy leaves the marker unset; the next launch fills only unused capacity and preserves favorites created after the failure.
- Base: migration already completed, so startup does not open the legacy `reply` box unless automatic recording is enabled.
- Bad: set the migration marker before copying, delete the legacy source, or let migration retry evict explicit favorites.
- Bad: clear `localCache` concurrently with bounded-store LRU cleanup; an empty/stale order key can be recreated after the clear.

### 6. Tests Required

- Migration marker + subsequent open without Hive.
- Codec round trips for models/sets/bytes.
- Batch put/delete incremental paths, Nth-operation failure injection, and
  verified backend/cache/event rollback.
- Lazy open uses `exportKeys` without full value export; single-key get works.
- close does not require sync.
- LRU eviction for progress/reply stores.
- Favorite migration: copy-on-success marker, legacy source retained, retry after open/copy failure, and retry never evicts explicit favorites.
- Favorite import/clear: capacity enforcement and LRU metadata remain synchronized.
- Settings import failure restores both boxes and supplemental secret state;
  supplemental restoration and verification still run after a box rollback
  failure.

### 7. Wrong vs Correct

#### Wrong
```dart
openAndroidMmkvBackedBox(name: 'watchProgress', openHive: ...); // eager default on large box
GStorage.watchProgress.put(cid, progress); // bypasses LRU store
if (Pref.saveReply) GStorage.replyCacheStore.put(id, data); // explicit favorite coupled to recording
```

#### Correct
```dart
openAndroidMmkvBackedBox(
  name: 'watchProgress',
  loadMode: AndroidMmkvLoadMode.lazy,
  openHive: ...,
);
await GStorage.watchProgressStore.put(cid, progress);
await GStorage.favoriteReplyStore.put(id, data); // explicit favorite is always available
```

#### Wrong (migration marker consumed on failure)

```dart
await markerStore.put(LocalCacheKey.favoriteReplyMigrationV1, true);
await destination.putAll(legacyValues); // failure can lose the retry signal
```

#### Correct

```dart
await destination.migrateLegacy(
  legacyBox: legacyBox,
  markerStore: localCache,
); // copies first; marker is the final successful write
```
