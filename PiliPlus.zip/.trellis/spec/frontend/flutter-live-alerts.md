# Flutter Foreground Live Alerts

## Scenario: account-scoped keyword alerts for followed live rooms

### 1. Scope / Trigger

- Trigger: live alert rules, foreground polling, notification delivery, account switching, or notification deep links.
- Scope: `LiveAlertService`, `LiveAlertLifecycleObserver`, `LiveAlertStatusSource`, `LiveAlertNotificationGateway`, and the live-alert settings UI.
- The feature is foreground-only. It must not install a background worker or imply server push.

### 2. Signatures

```dart
abstract interface class LiveAlertStatusSource {
  Future<LiveAlertRoomSnapshot?> resolveByMid(int mid);
}

abstract interface class LiveAlertNotificationGateway {
  Future<void> init();
  Future<bool> showLiveAlert({
    required int accountMid,
    required int mid,
    required int roomId,
    required String upName,
    required String streamTitle,
    required String matchedKeyword,
  });
  Future<void> flushPendingNavigation();
}

class LiveAlertService {
  Future<void> init();
  Future<void> activateCurrentAccount();
  void startPolling();
  void stopPolling();
  Future<void> checkLiveStatus();
  Future<bool> addRule(LiveKeywordRule rule);
  Future<bool> updateRule(LiveKeywordRule rule);
  Future<bool> deleteRule(String ruleId);
  Future<bool> toggleRule(String ruleId);
}

class LiveAlertLifecycleObserver extends WidgetsBindingObserver {
  Future<void> init();
}
```

### 3. Contracts

- Rule storage box: `liveKeywordRules`; notification history box: `liveAlertLastNotified`.
- Every persisted rule has `accountMid`; reads and mutations are limited to `Accounts.main.mid`.
- Legacy rules with `accountMid == 0` are assigned only when an authenticated current account is activated.
- A Bilibili member `mid` is not a live `roomId`. Resolve member data first, then query H5 room data with the mapped room id; reject a mismatched returned owner uid.
- Foreground startup performs one immediate check, then polls every 15 minutes. Background/inactive state cancels the timer.
- Account changes increment a generation, stop the previous poll, activate the new account, and prevent any old in-flight response from notifying.
- Rate limit key is `accountMid:upMid`; one UP may notify at most once per four hours even when multiple rules match.
- Enabled rules are evaluated deterministically by `createdAt`, then `id`; the first matching rule owns the notification.
- Android/iOS/macOS may show local notifications. Unsupported platforms return `false` without failing rule management.
- Notification payload is `live-room:<roomId>`; navigation waits for the root Get navigator through `StartupOverlayCoordinator` before opening `/liveRoom`.
- Do not log account ids, rule payloads, notification payload contents, or any account secret.

### 4. Validation & Error Matrix

| Condition | Required behavior |
|---|---|
| `mid <= 0` | reject rule resolution/mutation |
| no active account | return empty rules / mutation `false`; do not poll |
| member has no valid room id | return no snapshot; no notification |
| room owner uid differs from requested mid | reject snapshot |
| title/area does not match | no notification |
| last notification is inside four hours | no notification |
| account changes during request | discard the old response |
| app leaves foreground | cancel timer and invalidate in-flight generation |
| notification permission/plugin unavailable | retain rules and polling; delivery returns `false` |
| navigator unavailable on cold-start tap | keep pending room id and retry through startup coordinator |

### 5. Good / Base / Bad Cases

- Good: account A and account B subscribe to the same UP with different rules; switching accounts never exposes or executes the other account's rules.
- Good: two rules match one live title; one notification is sent and one shared per-UP timestamp is updated.
- Base: app is foregrounded with no enabled rules; immediate check returns without API fan-out.
- Bad: call `liveRoomInfoH5(roomId: mid)` directly; mid and room id are different domains.
- Bad: keep polling after `paused` or allow an account-A response to notify after switching to account B.

### 6. Tests Required

- mid-to-room mapping, missing room, mismatched uid, and H5 title/area extraction.
- deterministic rule selection for title/area/both targets and disabled rules.
- per-account rule isolation and legacy rule activation.
- four-hour boundary and multiple matching rules producing one notification.
- lifecycle start/stop plus generation invalidation after account change.
- notification payload parsing, escaped Android keyword emphasis, stable notification id, and delayed navigator routing.

### 7. Wrong vs Correct

#### Wrong

```dart
final room = await LiveHttp.liveRoomInfoH5(roomId: rule.mid);
Timer.periodic(const Duration(minutes: 15), (_) => poll());
```

#### Correct

```dart
final snapshot = await statusSource.resolveByMid(rule.mid);
if (foreground && generation == currentGeneration) {
  await decideAndNotify(snapshot);
}
```

