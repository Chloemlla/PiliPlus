# Flutter Danmaku Highlight Rendering

## Scenario: Keyword rules preserve existing danmaku colors while adding per-item outlines

### 1. Scope / Trigger

- Trigger: changing highlight rules, danmaku color resolution, player danmaku construction, `canvas_danmaku`, or build-time Pub-cache patches.
- Scope: `DanmakuHighlightRule`, `DanmakuHighlightService`, video danmaku rendering, the pinned `canvas_danmaku` checkout, settings persistence, and platform build workflows.
- User-facing changes must also follow [Flutter Build Whats-New](./flutter-build-whats-new.md).

### 2. Signatures

```dart
final class DanmakuHighlightStyle {
  final Color fillColor;
  final Color? strokeColor;

  static DanmakuHighlightStyle resolve({
    required Color displayedColor,
    Color? highlightColor,
  });
}

class DanmakuHighlightService extends GetxService {
  static const int maxRules = 50;

  DanmakuHighlightService({
    Object? Function()? readRules,
    Future<void> Function(List<Map<String, dynamic>> data)? writeRules,
  });

  DanmakuHighlightRule? getMatchingRule(String text);
  DanmakuHighlightStyle resolveStyle({
    required String text,
    required Color displayedColor,
  });
}

SettingBoxKey.danmakuHighlightRules // "danmakuHighlightRules"

// Added to canvas_danmaku by the pinned repo patch.
DanmakuContentItem(..., {Color? strokeColor});
SpecialDanmakuContentItem.fromList(..., {Color? strokeColor});

# CI entry point, after flutter pub get
pwsh lib/scripts/patch.ps1 <android|ios|linux|macos|windows>
```

### 3. Contracts

#### Rule matching and persistence

- Persist the JSON list in the `setting` box under `SettingBoxKey.danmakuHighlightRules`.
- Load and add at most 50 rules. Enabled rules are precompiled whenever the rule set changes.
- Plain rules use trimmed, case-insensitive substring matching. Regex rules use `RegExp(pattern, caseSensitive: false)`; an invalid regex remains stored but is excluded from active matching.
- When multiple rules match, the highest numeric priority wins. Do not move matching into the per-frame painter or compile regexes per danmaku.
- Add/edit/delete/toggle operations must persist before their returned Future completes. Constructor callbacks are the focused test seam; production defaults still use `GStorage.setting`.
- Quick rules are `主播`, `谢谢`, `厉害`, and `注意`, all using the default yellow highlight color.

#### Fill and stroke resolution

- `displayedColor` is the color the user would see before highlighting. For normal danmaku it is resolved after `blockColorful`, so blocked colorful danmaku count as white.
- No matching rule: keep the displayed fill and leave `strokeColor` null.
- Matching + displayed opaque white: replace the fill with the rule color and leave the stroke null.
- Matching + existing non-white fill: preserve that fill and pass the rule color as the per-item stroke/glow.
- Normal and special video danmaku use the same resolution. This is client-side only and never changes submitted or cached server data.

#### Pinned Git dependency patch

- `pubspec.yaml` and `pubspec.lock` pin `canvas_danmaku` to `697d4516df2fc3ba7417c7ce9aba079d34ba13e5`.
- `lib/scripts/canvas_danmaku_stroke_color.patch` adds nullable per-item `strokeColor` through normal and special construction paths.
- Null must preserve upstream behavior exactly: black normal stroke, colorful gradient stroke, and special black shadow only when `hasStroke` is true.
- A custom color overrides the stroke/shadow for that item only; it must not mutate global painter options or another danmaku.
- `patch.ps1` resolves `.dart_tool/package_config.json`, validates the exact Pub-cache path, package name, and Git HEAD, then uses forward/reverse `git apply --check` for idempotence. Any mismatch terminates the job.
- Every platform workflow runs `flutter pub get --enforce-lockfile`, applies the patch, then builds with `--no-pub` so a later dependency resolution cannot replace the patched checkout.

#### Registration and UI wiring

- Register `DanmakuHighlightService` after `GStorage.init()` and before any settings page or player calls `Get.find`.
- The same Dart startup path serves Android, iOS, Linux, macOS, and Windows; registration must not be hidden in a platform branch.
- Keep the `/danmakuHighlight` route and the settings entry. The page must expose quick add, add/edit, swipe-delete confirmation, and enabled toggle.

### 4. Validation & Error Matrix

| Condition | Required behavior |
|---|---|
| No rule matches | original displayed fill; null custom stroke |
| White danmaku matches | rule-colored fill; no custom stroke |
| Colored danmaku matches | original fill; rule-colored stroke/glow |
| `blockColorful` changes display to white | rule-colored fill is allowed |
| Multiple matches | highest priority wins |
| Plain keyword differs only by case | match |
| Invalid regex | keep stored rule; exclude it from active matching |
| 50 rules already loaded | reject another add without writing |
| Package config missing | patch script terminates and requests `flutter pub get` |
| Resolved checkout/path/HEAD differs | patch script refuses to modify it |
| Patch already applied | reverse check succeeds; continue without a second mutation |
| Patch neither applies nor reverses | terminate with both check outputs |

### 5. Good / Base / Bad Cases

- Good: a red server-colored danmaku matches a yellow rule; it stays red and receives a yellow outline.
- Base: a white danmaku matches a blue rule; its fill becomes blue.
- Good: `blockColorful` turns a colorful fill white, then a purple rule supplies the visible fill.
- Good: a reused CI cache already contains the dependency patch; the reverse check recognizes it.
- Bad: overwrite every matching fill with the rule color, destroying an intentional server color.
- Bad: patch whichever `canvas_danmaku-*` directory is found first without validating package config and HEAD.
- Bad: run another implicit `flutter pub get` after patching and assume the checkout remains modified.

### 6. Tests Required

- Style unit tests: no match, white replacement, colored preservation + outline, and the `blockColorful` white case.
- Service unit tests through injected storage callbacks: plain case-insensitive substring, regex, priority, disabled/invalid rules, persistence for add/edit/toggle/delete, duplicate detection, and the 50-rule cap.
- Patch validation: `git apply --check` against the exact pinned checkout and PowerShell parser validation.
- CI-only verification: Flutter analyze/tests and every platform build; do not run Flutter or Gradle locally in this repository.
- Boundary verification: `python tool/check_import_boundaries.py` and `git diff --check`.

### 7. Wrong vs Correct

#### Wrong

```dart
final ruleColor = service.applyHighlight(text);
DanmakuContentItem(
  text,
  color: ruleColor?.value ?? displayedColor,
);
```

#### Correct

```dart
final style = service.resolveStyle(
  text: text,
  displayedColor: displayedColor,
);
DanmakuContentItem(
  text,
  color: style.fillColor,
  strokeColor: style.strokeColor,
);
```

#### Wrong

```powershell
Get-ChildItem $pubCache/git -Filter 'canvas_danmaku-*' |
  Select-Object -First 1 |
  ForEach-Object { git -C $_.FullName apply $patch }
```

#### Correct

```powershell
# Resolve package_config, require the pinned cache path and HEAD, then:
git -C $packagePath apply --check -- $patch
# Or recognize the idempotent state:
git -C $packagePath apply --reverse --check -- $patch
```

## Design Decisions

- Style resolution is a pure value decision, separate from matching, storage, and painting. This keeps the regression seam small and unit-testable.
- The dependency stays pinned and patched in CI rather than mutating app-wide painter options; nullable API additions keep all non-highlight callers on upstream defaults.
- Builds use `--no-pub` after patching because the patched Pub-cache checkout is a build input and must remain stable through compilation.
