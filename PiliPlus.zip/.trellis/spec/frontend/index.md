# Frontend Development Guidelines

> Conventions for frontend development (Vite + React + TypeScript). Read before writing any frontend code.

---

## Stack (✅ decided, doc 05 §2 / D13)

**Vite + React + TS** · **Tailwind + shadcn/ui + Radix** · **TanStack Query** (server state) + **Zustand** (UI state) · WebSocket client (activity stream) · shared types/Zod from **`packages/shared`**.

## Pre-Development Checklist

Before writing frontend code, confirm:

- [ ] Cross-cutting types come from `packages/shared` (not redeclared locally).
- [ ] Server data goes through TanStack Query; live data through the WS hook — not duplicated into local state.
- [ ] New shared component/hook is justified (a second consumer exists), else keep it feature-local.
- [ ] Network/WS data is validated (Zod) before being treated as typed.
- [ ] No secret/token touches client storage or logs.
- [ ] Flutter player transport errors are classified before crash reporting.
- [ ] Flutter player layout/network/disposal changes follow the non-blocking lifecycle contract (see [Flutter Player Layout and Lifecycle Stability](./flutter-player-lifecycle-stability.md)).
- [ ] Danmaku highlight changes preserve colored fills and keep the pinned dependency patch reproducible (see [Flutter Danmaku Highlight Rendering](./flutter-danmaku-highlight.md)).
- [ ] Flutter main navigation derives layout and safe-area data from the current build context (see [Flutter Main Navigation Layout](./flutter-main-navigation-layout.md)).
- [ ] User-facing commits refresh `WhatsNewData.pages` (see [Flutter Build Whats-New](./flutter-build-whats-new.md)).
- [ ] Failed Actions/PRs are repaired via `gh` + parallel subagents; no local Flutter/Gradle builds (see [CI Action Auto-Repair](./ci-action-auto-repair.md)).

## Quality Check

Before marking work done (see [`quality-guidelines.md`](./quality-guidelines.md)):

- [ ] Lint + type-check green; strict TS, no `any`/unsafe casts.
- [ ] Scanned for the 7 code smells; none introduced.
- [ ] Tests pass (Vitest + RTL where applicable).

---

## Guidelines Index

| Guide | Description | Status |
|-------|-------------|--------|
| [Directory Structure](./directory-structure.md) | Feature-based layout, naming | ✅ Filled |
| [Component Guidelines](./component-guidelines.md) | shadcn/Radix + Tailwind, props, a11y, real-time surfaces | ✅ Filled |
| [Hook Guidelines](./hook-guidelines.md) | TanStack Query, WS activity-stream hook | ✅ Filled |
| [State Management](./state-management.md) | Server vs live vs UI state | ✅ Filled |
| [Type Safety](./type-safety.md) | Shared types, Zod validation, forbidden casts | ✅ Filled |
| [Android MMKV Storage](./android-mmkv-storage.md) | Android MMKV-backed local storage contracts | ✅ Filled |
| [Android Baseline Profile](./android-baseline-profile.md) | Android release baseline/startup profile generation contracts | ✅ Filled |
| [Flutter Startup Context](./flutter-startup-context.md) | Navigator context contracts for startup dialogs | ✅ Filled |
| [Flutter Main Navigation Layout](./flutter-main-navigation-layout.md) | Route-return responsive mode + safe-area ownership | ✅ Filled |
| [Flutter Persistence and Recovery](./flutter-persistence-recovery.md) | Settings rollback, canonical accounts, startup cookies, WebDAV replacement, background writes | ✅ Filled |
| [Flutter Build Whats-New](./flutter-build-whats-new.md) | Per-commit/build immersive update guide content + ack identity | ✅ Filled |
| [CI Action Auto-Repair](./ci-action-auto-repair.md) | gh CLI inventory, parallel subagents, no local builds, Action re-verify | ✅ Filled |
| [Flutter Clipboard Video Links](./flutter-clipboard-video-link.md) | Clipboard video link parsing and session duplicate-dialog contracts | ✅ Filled |
| [Flutter Player Errors](./flutter-player-errors.md) | media_kit stream error classification and retry contracts | ✅ Filled |
| [Flutter Player Layout and Lifecycle Stability](./flutter-player-lifecycle-stability.md) | constrained controls, single-completion interceptors, graceful HTTP/2 reset, Android isolate disposal | ✅ Filled |
| [Flutter Danmaku Highlight Rendering](./flutter-danmaku-highlight.md) | keyword rule matching, fill/stroke resolution, pinned canvas patch, platform build order | ✅ Filled |
| [Flutter Crash Report History](./flutter-crash-reports.md) | filtered, bounded local crash history and startup-display contracts | ✅ Filled |
| [Bilibili Web QR Authorization](./bilibili-web-qr-authorization.md) | Android HMS Scan Kit QR scanning, authorization session integrity, risk flow, and secret redaction | ✅ Filled |
| [Flutter Seal Download Delegate](./flutter-seal-download-delegate.md) | Seal L3 MethodChannel/status panel: non-blocking invoke, multi-P urls[], EXTRA_URLS | ✅ Filled |
| [Android Media Notification Progress](./android-media-notification-progress.md) | MediaStyle scrubber: duration write-back, SEEK_TO gating, position throttle, seek stale-guard | ✅ Filled |
| [Flutter Media Library Tools](./flutter-media-library-tools.md) | Smart DASH quality, portable playlist schema/import, and safe local video bookmarks | ✅ Filled |
| [Quality Guidelines](./quality-guidelines.md) | Forbidden/required patterns, 7 smells, tests | ✅ Filled (⏳ test setup to confirm) |

> ⏳ items are recommendations from `docs/design/05-tech-stack-and-conventions.md` to finalize before the relevant code lands.

---

**Language**: all documentation and code identifiers are in **English** (project language policy; conversational replies may be Chinese).
