# Android Baseline Profile

## Scenario: Release workflow baseline profile generation

### 1. Scope / Trigger

- Trigger: Android release workflow changes under `.github/workflows/build.yml` and baseline profile tests under `android/baselineprofile/`.
- Scope: CI generation of baseline and startup profiles before Android release APK packaging.

### 2. Signatures

```kotlin
baselineProfileRule.collect(
    packageName = TARGET_PACKAGE,
    includeInStartupProfile = true,
) {
    pressHome()
    // Prefer startActivityAndWait, but accept a stable target process when
    // ATD/GHA emulators miss framestats or package-depth UI signals.
    startPiliPlusAndWait()
    device.waitForIdle()
}
```

```bash
gradle -p android -Pdart-defines="$DART_DEFINES" :app:generateBaselineProfile --no-daemon --stacktrace
```

### 3. Contracts

- The release workflow must run baseline profile generation before `flutter build apk`.
- The Android release workflow must run `lib/scripts/patch.ps1 android` after
  `flutter pub get` and before baseline profile generation; that script removes
  legacy `package` attributes from Pub-cache plugin Android manifests so AGP
  namespace handling remains valid during `:app:generateBaselineProfile`.
- The startup journey test must set `includeInStartupProfile = true`.
- `reactivecircus/android-emulator-runner` executes `script` with `/usr/bin/sh`; keep the script POSIX-compatible and do not use Bash-only options such as `set -o pipefail`.
- Keep `reactivecircus/android-emulator-runner` `script` to one Gradle command line. Do not put shell variables, loops, or multi-line validation in it; the action can execute lines independently as `/usr/bin/sh -c`.
- Emulator `target` must be a real system-image package id accepted by `sdkmanager` / android-emulator-runner (`default`, `google_apis`, `aosp_atd`, `google_atd`, etc.). Never use invent names such as `aosp`; invalid targets fail during `Install Android SDK` before boot.
- Prefer `api-level: 34` + `target: aosp_atd` + `arch: x86_64` for GHA baseline generation. `aosp_atd` boots more reliably than `google_apis`/`default` under SwiftShader; plain `default` can still hit `ColorBuffer` / process death after launch.
- The generator launch helper must treat a target process that remains running for a settle window as launch success even when framestats confirmation or UI Automator package-depth visibility fails.
- On hard launch failure, clear logcat before attempts and dump broader tags (`AndroidRuntime`, `DEBUG`, `libc`, `flutter`, `ActivityManager`, `WindowManager`) in the assertion message.
- `LumenCrash.install` in `PiliPlusApplication` must be best-effort and must not abort process start if the SDK install throws.
- Validate generated profile files in a separate workflow step with `shell: bash`.
- With the current pinned `gradle/actions/setup-gradle` SHA, do not add unsupported inputs such as `cache-provider`.
- Set `add-job-summary: never` and `develocity-injection-enabled: false` for the Android release job unless Gradle build summaries or Develocity scans are explicitly required.
- Generation must produce non-empty files:
  - `android/app/src/main/generated/baselineProfiles/baseline-prof.txt`
  - `android/app/src/main/generated/baselineProfiles/startup-prof.txt`
- CI should upload the generated profile files as an artifact so the release run is auditable.
- `Android_baseline_profile` uploads two files, so it must use the default
  archived artifact behavior. Do not set `archive: false` for this step.
- After uploading the generated profiles, the Android release workflow must
  clean baseline/emulator-heavy intermediates before `flutter build apk`:
  - `build`
  - `android/.gradle`
  - `$HOME/.android/avd`
  - `$ANDROID_HOME/system-images` and `$ANDROID_HOME/emulator`
- Keep one Gradle dependency cache owner in the Android job. Do not enable
  `actions/setup-java` Gradle caching when `gradle/actions/setup-gradle`
  already manages Gradle setup/cache.

### 4. Validation & Error Matrix

- `baseline-prof.txt` missing or empty -> fail the release job with a GitHub Actions error.
- `startup-prof.txt` missing or empty -> fail the release job with a GitHub Actions error.
- Baseline profile Gradle task fails -> fail before APK build.
- Pub-cache plugin `android/src/main/AndroidManifest.xml` keeps a `package`
  attribute -> remove it in `lib/scripts/patch.ps1 android` before Gradle runs.
- `script` starts with `set -euo pipefail` -> `/usr/bin/sh: set: Illegal option -o pipefail`.
- `script` contains a multi-line `for ... do ... done` block -> `/usr/bin/sh: Syntax error: end of file unexpected (expecting "done")`.
- Emulator `target: aosp` (or any non-existent package id) -> `Install Android SDK` fails in ~tens of seconds with `/usr/bin/sh` exit code 1 and the emulator is terminated before launch.
- Emulator boots and the instrumented test starts, then fails with `failed to stay running after launch` / `visible=false processRunning=false` plus `Failed to find ColorBuffer` -> switch away from plain `default` AOSP and stop requiring UI depth visibility when the process is alive; re-check Application attach crash paths (for example unguarded `LumenCrash.install`).
- `setup-gradle` emits `io.netty.util.concurrent.DefaultPromise$1` from `grpc-nio-*` after writing build results -> disable the Gradle action job summary and keep Develocity injection disabled.
- Release APK build fails with `No space left on device` after baseline
  profile generation -> add or fix the release-build disk cleanup step before
  changing APK outputs.
- Cleanup removes `android/app/src/main/generated/baselineProfiles/*` before
  release build -> invalid; generated profiles must remain available to package.
- `Android_baseline_profile` sets `archive: false` while uploading both profile
  files -> upload-artifact fails because non-archived artifacts can contain only
  one file.

### 5. Good/Base/Bad Cases

- Good: startup flow uses `includeInStartupProfile = true`, CI validates both generated files, and uploads them.
- Base: baseline profile exists and is merged into the release APK.
- Base: `lib/scripts/patch.ps1 android` reports how many Pub-cache manifests
  had `package` attributes removed before the emulator baseline-profile step.
- Bad: profile generation logs `No startup profile rules were generated` and the workflow continues silently.
- Bad: modifying checked-in app manifests to work around Pub-cache plugin
  manifests; keep third-party cache cleanup inside the Android patch script.
- Bad: emulator runner script assumes Bash semantics and fails before running Gradle.
- Bad: emulator runner script contains multi-line shell control flow; move that logic to a normal `bash` step.
- Bad: Gradle action job summaries or Develocity injection are left enabled when they cause gRPC/Netty errors in the emulator job.
- Bad: baseline profile build outputs, project Gradle execution history, AVDs,
  and emulator system images remain on disk while building three split APKs.

### 6. Tests Required

- GitHub Actions release run must show `:app:generateBaselineProfile` before `flutter build apk`.
- Workflow logs must include line counts for `baseline-prof.txt` and `startup-prof.txt`.
- Release artifacts must include `Android_baseline_profile`.
- `Android_baseline_profile` must not set `archive: false` while its `path`
  contains both generated profile files.
- Workflow logs must include a `df -h` snapshot immediately before the release
  APK build.
- Android release job must not configure both `actions/setup-java` Gradle cache
  and `gradle/actions/setup-gradle` cache for the same build.
- Android release job logs must show `Apply Patch` before
  `:app:generateBaselineProfile`, and the patch step must tolerate a missing
  Pub-cache hosted directory.

### 7. Wrong vs Correct

#### Wrong

```kotlin
baselineProfileRule.collect(packageName = TARGET_PACKAGE) {
    startActivityAndWait()
}
```

This creates baseline rules but leaves startup profile generation disabled.

#### Correct

```kotlin
baselineProfileRule.collect(
    packageName = TARGET_PACKAGE,
    includeInStartupProfile = true,
) {
    pressHome()
    killProcess()
    startPiliPlusAndWait() // process-stable success is enough on ATD
}
```

Use `includeInStartupProfile = true` for startup journeys so release builds also get startup profile rules. On GHA ATD images, do not fail solely because package-depth UI visibility is false.

#### Wrong

```yaml
- name: Set up Java
  uses: actions/setup-java@...
  with:
    distribution: zulu
    java-version: "17"
    cache: gradle

- name: Flutter Build Release Apk
  run: flutter build apk --release --split-per-abi --dart-define-from-file=pili_release.json --no-pub
```

This leaves baseline/emulator intermediates and a duplicate Gradle cache on the
runner while building all split APKs.

#### Correct

```yaml
- name: Free Android release build disk
  shell: bash
  run: |
    set -euo pipefail
    gradle --stop || true
    rm -rf build android/.gradle "$HOME/.android/avd"
```

Run the cleanup after uploading generated profiles and before release APK
packaging.

## Related

- Failed baseline/emulator Actions must be repaired under [CI Action Auto-Repair](./ci-action-auto-repair.md): gh log inventory, no local emulator builds, parallelize only when other root causes exist.
