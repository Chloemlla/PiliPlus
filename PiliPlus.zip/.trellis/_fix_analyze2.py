from pathlib import Path

# content_panel: add image_type import
p = Path("lib/pages/dynamics/widgets/content_panel.dart")
t = p.read_text(encoding="utf-8")
if "models/common/image_type.dart" not in t:
    t = t.replace(
        "import 'package:pili_plus/models/dynamics/result.dart';\n",
        "import 'package:pili_plus/models/common/image_type.dart';\n"
        "import 'package:pili_plus/models/dynamics/result.dart';\n",
        1,
    )
    p.write_text(t, encoding="utf-8", newline="\n")
    print("added image_type to content_panel")

# dyn_menu: prefer ImageType.emote for clarity
p = Path("lib/common/widgets/context_menu/dyn_menu_helper.dart")
t = p.read_text(encoding="utf-8")
t2 = t.replace("type: .emote,", "type: ImageType.emote,")
if t2 != t:
    p.write_text(t2, encoding="utf-8", newline="\n")
    print("dyn_menu ImageType.emote")
else:
    print("dyn_menu already ImageType.emote or pattern missing")
