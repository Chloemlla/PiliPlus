from pathlib import Path

# 1) common_rich_text_pub_page.dart imports
p = Path("lib/pages/common/publish/common_rich_text_pub_page.dart")
t = p.read_text(encoding="utf-8")
old = """import 'package:pili_plus/models/dynamics/result.dart'
import 'package:pili_plus/common/style.dart';
    show PicModel, FilePicModel, OpusPicModel;
"""
new = """import 'package:pili_plus/common/style.dart';
import 'package:pili_plus/models/dynamics/result.dart'
    show PicModel, FilePicModel, OpusPicModel;
"""
if old not in t:
    raise SystemExit("common_rich pattern missing:\n" + "\n".join(t.splitlines()[:20]))
t = t.replace(old, new, 1)
p.write_text(t, encoding="utf-8", newline="\n")
print("fixed common_rich_text_pub_page imports")

# 2) rich_node_panel.dart imports
p = Path("lib/pages/dynamics/widgets/rich_node_panel.dart")
t = p.read_text(encoding="utf-8")
old = """import 'package:pili_plus/models/common/image_preview_type.dart'
import 'package:pili_plus/common/widgets/emote_span.dart';
    show SourceModel;
"""
new = """import 'package:pili_plus/common/widgets/emote_span.dart';
import 'package:pili_plus/models/common/image_preview_type.dart'
    show SourceModel;
"""
if old not in t:
    raise SystemExit("rich_node pattern missing:\n" + "\n".join(t.splitlines()[:20]))
t = t.replace(old, new, 1)
p.write_text(t, encoding="utf-8", newline="\n")
print("fixed rich_node_panel imports")

# 3) content_panel.dart: add style + emote_span for dyn_menu part
p = Path("lib/pages/dynamics/widgets/content_panel.dart")
t = p.read_text(encoding="utf-8")
if "common/style.dart" not in t:
    t = t.replace(
        "import 'package:pili_plus/common/widgets/custom_icon.dart';\n",
        "import 'package:pili_plus/common/style.dart';\n"
        "import 'package:pili_plus/common/widgets/custom_icon.dart';\n"
        "import 'package:pili_plus/common/widgets/emote_span.dart';\n",
        1,
    )
    p.write_text(t, encoding="utf-8", newline="\n")
    print("restored content_panel style/emote imports")
else:
    print("content_panel already has style")

# 4) whats_new_data.dart: ]]; -> ];
p = Path("lib/pages/onboarding/whats_new_data.dart")
t = p.read_text(encoding="utf-8")
if "  ]];\n}" in t:
    t = t.replace("  ]];\n}", "  ];\n}", 1)
    p.write_text(t, encoding="utf-8", newline="\n")
    print("fixed whats_new extra bracket")
elif "  ];\n}" in t:
    print("whats_new already ok")
else:
    print("whats_new end:\n", repr(t[-80:]))

# scan for other broken multi-line imports (import without ; followed by import then show)
import re
broken = []
for path in Path("lib").rglob("*.dart"):
    text = path.read_text(encoding="utf-8", errors="replace")
    if re.search(r"import '[^']+'\nimport '[^']+';\n\s+show ", text):
        broken.append(str(path))
print("other broken show-imports:", broken)
