# Watch Statistics Dashboard

## Goal

Give users a clear view of their video watching habits: total watch time, videos watched, most watched creators, daily/weekly trends. Make visible what's currently invisible — how much time is actually spent on BiliBili.

## Requirements

### Data collection
- Track each video session: bvid, title, creator, duration watched (seconds), date
- A session starts when playback begins, ends when: the video is closed, another video is opened, or 5 minutes of inactivity
- Store sessions locally in Hive/MMKV (same storage backend as watch history)
- Schema: `{ bvid, title, authorName, authorMid, watchedSeconds, timestamp, date }`

### Dashboard UI
- Entry: "我的观看统计" in the profile or settings area
- Display:
  - **本周** / **本月** / **全部** time range tabs
  - Total watch time (hours + minutes)
  - Videos watched count
  - Daily average watch time
  - Bar chart: watch time per day (last 7 days for weekly, last 30 days for monthly)
  - Top 5 most watched creators (by time)
  - Top 5 longest videos watched

### Privacy
- All data local only; no network upload
- "Clear watch statistics" with confirmation

### Export
- Export statistics as JSON or CSV
- Share a summary card as image (watch time this week + comparison to last week)

## Technical Approach

### Storage
- New Hive box: `watchStatsSessions` (append-only session log)
- Aggregate computed on read from session log (not pre-computed) to allow flexible time ranges
- Max 90 days of sessions retained; older entries auto-pruned

### Implementation
- `WatchStatsService` / `WatchStatsController` in `lib/services/`
- `WatchStatsDashboardPage`: Flutter page with `fl_chart` (already in pubspec.yaml) for bar charts
- Session tracking: hook into `PlayerService.onPositionChanged` and `PlayerService.onVideoEnded`
- Use existing `UserInfoStore` for author mid → name resolution (cache by mid)

### Components
- `WatchStatsCard`: summary number with icon
- `WatchStatsBarChart`: daily bar chart using `fl_chart`
- `WatchStatsTopCreatorsList`: ranked list with watch time per creator

## Acceptance Criteria

- [ ] Watch sessions tracked automatically during playback
- [ ] Dashboard shows correct totals for week/month/all
- [ ] Daily bar chart renders correctly
- [ ] Top creators list is accurate
- [ ] Statistics persist across app restarts
- [ ] Clear statistics works with confirmation
- [ ] Export JSON/CSV works
- [ ] Share summary card works

## Out of Scope

- Comparison with friends/others
- Server-side sync
- Watch time goals / reminders
- Break tracking (how long between sessions)

## Technical Notes

- Check `lib/services/player_service.dart` for playback hooks
- Check `lib/utils/storage/` for existing Hive box patterns
- `fl_chart` is already in pubspec.yaml
- No new dependencies needed
- Review `lib/pages/history/` for existing history patterns to align UI
