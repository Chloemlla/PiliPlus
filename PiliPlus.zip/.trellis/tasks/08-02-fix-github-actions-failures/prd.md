# fix GitHub Actions failures

## Goal

修复最新 GitHub Actions Build 失败，使 `Analyze and Test` 恢复通过，并由 Actions 继续验证后续平台作业。

## What I already know

* 最新失败运行：`30750519431`，提交 `a49c9e01b4e4977034aa1debdd717940513c902b`。
* 失败作业：`Analyze and Test`；`Check import and storage boundaries`、依赖安装和补丁步骤均成功，失败发生在 `flutter analyze`。
* 日志已确认两个独立根因：`lib/plugin/pl_player/view/view.dart:545` 语法错误；`test/common/widgets/player_bar_test.dart` 结构/声明错误。
* 本地项目规范禁止运行本地 Flutter/Gradle 构建，Actions 是最终验证器。

## Requirements

* 修复 `view.dart` 第 545 行附近的语法错误，同时保留播放器回退功能。
* 修复 `player_bar_test.dart` 的完整 Dart 结构、辅助函数声明和测试覆盖，不回退 `PlayerBar` 生产代码改动。
* 不引入与本次 Actions 错误无关的功能变更。
* 通过静态检查、`git diff --check` 和 Actions 验证。

## Acceptance Criteria

* [ ] `flutter analyze --no-fatal-infos` 不再报告 error。
* [ ] `player_bar_test.dart` 中所有测试辅助函数在顶层正确声明，文件括号完整。
* [ ] 播放器控件回退代码仍保留，未恢复底部 `.more`。
* [ ] Actions 最新运行的 Analyze and Test 成功。
* [ ] 无本地 Flutter/Gradle 构建或测试作为验证依据。

## Definition of Done

* 两个独立失败根因均修复并经过静态检查。
* 提交并推送修复。
* 使用 `gh run list/view` 确认新 Actions 结果。

## Out of Scope

* 不升级依赖或修改 Actions runner 配置，除非失败日志证明必要。
* 不修改与失败无关的业务功能。

## Technical Notes

* Failed run log: `gh run view --repo Chloemlla/PiliPlus 30750519431 --log-failed`。
* Relevant files: `lib/plugin/pl_player/view/view.dart`, `test/common/widgets/player_bar_test.dart`。
* CI guidance: `.trellis/spec/frontend/ci-action-auto-repair.md`。
