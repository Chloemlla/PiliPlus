# Research: Implementation File Map — Strip Marked Ads

- **Date**: 2026-07-21

## PiliPlus

| File | Work |
|------|------|
| `lib/utils/segment_strip_math.dart` (new) | merge / invert / filter pure functions |
| `test/utils/segment_strip_math_test.dart` (new) | exhaustive range tests |
| `lib/models/.../strip_removal_report.dart` (new) | report models |
| `lib/http/sponsor_block.dart` | reuse getSkipSegments |
| `lib/utils/seal_download_utils.dart` | strip option, fetch segments, keep_sections payload, report sheet |
| `android/.../SealDownloadChannel.kt` | put strip extras |
| `lib/utils/storage_key.dart` / `storage_pref.dart` | prefs |
| `lib/pages/setting/...` | strip defaults UI near SponsorBlock |
| `lib/pages/video/widgets/header_control.dart` or more-menu | entry |
| `.trellis/spec/frontend/flutter-seal-download-delegate.md` | document extras |

## Seal

| File | Work |
|------|------|
| `integration/ExternalDownloadProtocol.kt` | extras keys (shared v2 with cookies) |
| `integration/ExternalDownloadRequestParser.kt` | parse keep_sections / remove_segments / strip_segments |
| `download/TaskFactory.kt` | map sections → videoClips on preferences copy |
| `util/DownloadUtil.kt` | already supports videoClips; ensure external path populates them |
| `integration/ExternalDownloadCoordinator.kt` | no report needed beyond file |
| docs third-party-* | document strip extras |
| unit tests parser sections JSON | |

## Protocol note

Cookie passthrough and strip extras both need protocol ≥2; implement as **one v2 bump** covering both feature sets when landing either, or additive extras with version gate.

## Tests (must)

- Empty segments → keep = full
- Overlap merge
- Adjacent merge within gap
- Invert multiple holes
- Full cover → error
- Min length filter
- poi_highlight never in default categories

## CI

- PiliPlus: analyze + unit tests for math
- Seal: Lint + Build Pre-Release
- `gh run watch` until green; no local APK
