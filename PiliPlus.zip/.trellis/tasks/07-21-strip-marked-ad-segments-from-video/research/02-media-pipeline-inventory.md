# Research: Media Pipeline Inventory (PiliPlus)

- **Date**: 2026-07-21

## Export / download paths

### MediaExportUtils (`lib/utils/media_export_utils.dart`)

- **Video**: `VideoHttp.videoUrl` with `fnval: 1` → MP4 **durl** single segment; multi-durl rejected; quality via supportFormats.
- **Audio**: DASH audio → `.m4a` download.
- Progress dialog; saves via platform file picker / gallery helpers.
- **No** segment cut, **no** ffmpeg, **no** SponsorBlock integration.

### SealDownloadUtils (`lib/utils/seal_download_utils.dart`)

- Android-only L3 delegate via MethodChannel `pili_plus/seal_download`.
- Multi-P URL batch (`urls` + primary `url`).
- Prefs: `sealAutoStart`.
- Status panel lifecycle; open/share content URI on complete.
- **No** strip_ads / segments extras today.

### SealDownloadChannel.kt

- Intent `ACTION_DOWNLOAD` → QuickDownloadActivity.
- Extras: protocol_version, url, urls, extract_audio, auto_start, open_ui, caller_request_id, caller_package.
- **No** cookie / segments.

### Offline cache / download manager

- App has offline cache UI (`/download` route) and models under `models_new/download/` — separate from Seal.
- Stripping should define whether input is Seal-downloaded file, MediaExport file, or re-download — product design prefers **Seal path with segments** for quality/ffmpeg.

## Player

- `media_kit` / `pl_player` for playback + BlockMixin skip.
- Player can seek; **not** used as remux engine.
- No evidence of ffmpeg FFI / package in pubspec for cut (verify: no ffmpeg in dart deps for strip).

## Conclusion

PiliPlus alone cannot high-quality remux without adding ffmpeg binary or always-using Seal’s FFmpeg/yt-dlp. Complete product should **orchestrate Seal** for cut/remux while PiliPlus owns segment list + detailed report UI.
