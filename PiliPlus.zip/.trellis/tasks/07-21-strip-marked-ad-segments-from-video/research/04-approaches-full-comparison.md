# Research: Approaches Full Comparison — Ad Segment Strip

- **Date**: 2026-07-21
- **User constraint**: complete product, detailed removal report; no thin MVP

## Approach A — Seal `--sponsorblock-remove` only

| Axis | Rating |
|------|--------|
| Fidelity to PiliPlus marks | **Poor** — yt-dlp SB API ≠ PiliPlus list |
| Report detail | **Poor** — no structured intervals back |
| Dual-repo cost | Low (pref + optional category extra) |
| Failure modes | SB API down already special-cased as fail |
| Offline marks | No |

**Reject as sole solution** for “完整版 + 详细移除报告”.

## Approach B — PiliPlus local ffmpeg keep-range concat

| Axis | Rating |
|------|--------|
| Fidelity | **Excellent** |
| Report | **Excellent** (local) |
| Dual-repo cost | High on PiliPlus — need ffmpeg binary/package, storage, Android build complexity |
| Local toolchain | This machine **cannot** build Android APK; CI heavier |
| Input file | Must already have full media (export or download first) |

**Viable long-term** but expensive; not preferred first path given Seal already has FFmpeg.

## Approach C — Hybrid: PiliPlus segments → Seal `--download-sections` KEEP ranges

| Axis | Rating |
|------|--------|
| Fidelity | **Excellent** if keep ranges inverted from PiliPlus remove list |
| Report | **Excellent** — PiliPlus shows remove list (precomputed) |
| Dual-repo cost | Medium — protocol extras `keep_sections` or `remove_segments` + Seal TaskFactory videoClips |
| Download efficiency | High (may skip ad media download depending on yt-dlp/bili) |
| Failure modes | Section boundary keyframes; need force keyframes if available |

**Strong candidate for complete product.**

## Approach D — Full download then post-process with explicit segment list

| Axis | Rating |
|------|--------|
| Fidelity | **Excellent** |
| Report | **Excellent** |
| Dual-repo cost | Medium–High — Seal post-step ffmpeg concat demux; or return file to PiliPlus for future B |
| Quality | Better control of cuts (re-encode vs stream copy) |
| Time/storage | Downloads ads then deletes — slower |

**Also complete-product grade**; good fallback when sections fail.

## Recommended COMPLETE design

**Primary: C + PiliPlus-owned report**  
**Fallback: D** if section download fails or extractor ignores sections.

Pipeline:

1. PiliPlus fetch SponsorBlock segments for bvid+cid.
2. Filter by user strip categories; merge overlaps; drop full-video labels.
3. Invert to keep ranges; validate min length.
4. Build **removal report model** (immutable for UI).
5. Delegate Seal with URL + `remove_segments` JSON (ms or sec) **or** `keep_sections` + `strip_report_id`.
6. Seal applies videoClips / post-process; returns content_uri.
7. PiliPlus shows report UI (not dependent on Seal parsing).

Optional later: Approach B for non-Android or offline-only files.

## Explicitly not enough

- A alone
- Playback skip only (already exists; not “成品视频”)
