# Research: SponsorBlock Data Model (Full)

- **Scope**: PiliPlus SponsorBlock / marked segments for ad stripping
- **Date**: 2026-07-21

## Files

| Path | Role |
|------|------|
| `lib/models/common/sponsor_block/segment_type.dart` | Category enum + UI titles/colors |
| `lib/models/common/sponsor_block/segment_model.dart` | Runtime segment + SkipType |
| `lib/models/common/sponsor_block/skip_type.dart` | alwaysSkip / skipOnce / skipManually / showOnly / disable |
| `lib/models/common/sponsor_block/action_type.dart` | skip / mute / full / poi |
| `lib/models/common/sponsor_block/post_segment_model.dart` | User submit payload |
| `lib/models_new/sponsor_block/segment_item.dart` | API DTO |
| `lib/http/sponsor_block.dart` | HTTP client |
| `lib/http/sponsor_block_api.dart` | Path constants |
| `lib/pages/sponsor_block/block_mixin.dart` | Load + skip during playback |
| `lib/pages/sponsor_block/view.dart` | Settings UI |
| `lib/utils/storage_pref.dart` | enableSponsorBlock, blockSettings, blockLimit, blockServer |

## SegmentType catalog

| Enum name | ZH title | Ad-like? | Typical strip? |
|-----------|----------|----------|----------------|
| `sponsor` | 赞助/恰饭 | **Yes (primary ad)** | **Default ON** |
| `selfpromo` | 无偿/自我推广 | Soft ad | Default ON (user choice) |
| `exclusive_access` | 独家访问/品牌合作 | Brand full-video | Optional; often full-video mark |
| `interaction` | 三连/互动提醒 | Not commercial ad | Optional |
| `poi_highlight` | 精彩时刻 | **No (highlight)** | **Never strip** |
| `intro` | 过场/开场动画 | Not ad | Optional |
| `outro` | 鸣谢/结束画面 | Not ad | Optional |
| `preview` | 回顾/概要 | Not ad | Optional |
| `padding` | 填充/前黑后黑 | Not ad | Optional (useful for clean cuts) |
| `filler` | 离题闲聊 | Aggressive | Optional off by default |
| `music_offtopic` | 音乐:非音乐部分 | Music-video only | Optional |

**Product default strip set (complete product):**  
`sponsor` + `selfpromo` + user multi-select of other **skip-capable** types.  
**Hard exclude:** `poi_highlight` (not a removal target).  
`exclusive_access` with full-video (0,0) or entire duration → treat as label, not cut-all.

## Units

- API (`SegmentItemModel.fromJson`): `segment` values in **seconds** (num) → converted with `* 1000` → **milliseconds** list.
- `SegmentModel.segment`: `(int startMs, int endMs)`.
- `videoDuration` also stored in ms when present.
- PGC OP/ED via `fromPgcJson` uses start/end seconds → ms.

## Fetch

```dart
SponsorBlock.getSkipSegments(bvid: bvid, cid: cid)
// GET {blockServer}/api/skipSegments?videoID={bvid}&cid={cid}
```

Server default: `Pref.blockServer` / `HttpString.sponsorBlockBaseUrl` (BilibiliSponsorBlock compatible).

## User config

- `Pref.enableSponsorBlock` master toggle
- `Pref.blockSettings`: `List<Pair<SegmentType, SkipType>>` per category
- `Pref.blockLimit`: min segment length (seconds-ish) below which skipType forced to showOnly
- `BlockConfigMixin.enableList`: categories where SkipType ≠ disable

Playback skip (`BlockMixin`) ≠ file strip. For strip product:
- Source segments = same API list filtered by **strip category multi-select** (new pref), not necessarily SkipType.
- Still apply min duration / merge / validate end≥start.

## Full-video / invalid segments

- `segment == (0,0)` used as video-level label (exclusive_access style) — **exclude from cut list**.
- `end < start` dropped (handleSBData already filters `end >= start`).
- Overlaps: merge before invert to keep-ranges.

## Local user marks

- Users can post segments (`post_segment_model` / vote APIs).
- After post, list refresh returns community+self; strip should re-fetch or use in-memory `_segmentList` for current bvid+cid.

## Report fields per removed segment

| Field | Source |
|-------|--------|
| category / SegmentType | item.category |
| title (ZH) | SegmentType.title |
| start / end | ms → display `HH:MM:SS.mmm` |
| duration | end-start |
| uuid | item.uuid |
| source | `sponsorblock` / `pgc` / `user` |
| votes | optional |
