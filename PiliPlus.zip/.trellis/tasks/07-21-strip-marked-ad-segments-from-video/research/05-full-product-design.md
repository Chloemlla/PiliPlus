# Research: Full Product Design — Strip Marked Ad Segments

- **Date**: 2026-07-21

## User-facing goal

下载/导出成品视频时，可选择剥离 PiliPlus 已标记（SponsorBlock 等）广告类片段，合成连续正片，并**逐条**告知移除了哪里（类型 + 时间轴）。

## Entry points

1. Video more menu near Seal 下载：子选项「下载并去除标记片段」
2. Seal 委托流程中的开关（与 extractAudio 同级）
3. Settings → SponsorBlock / 下载：默认类别、默认开启剥离、最小片段时长

## Settings

| Pref | Type | Default |
|------|------|---------|
| `stripMarkedSegmentsEnabled` | bool | false (opt-in) |
| `stripSegmentCategories` | Set/List of SegmentType names | {sponsor, selfpromo} |
| `stripMinSegmentMs` | int | max(blockLimit*1000, 1000) |
| `stripAlwaysAskCategories` | bool | false |

## Algorithm (PiliPlus pure Dart — unit tested)

```
input: segments[{type, startMs, endMs, uuid}], durationMs, categories, minMs
1. filter type in categories AND end>start AND length>=minMs AND not (0,0) full-label
2. sort by start; merge overlaps/adjacent within gapMs (e.g. 200ms)
3. removed[] = merged list (for report)
4. keep[] = invert(removed, 0..durationMs)
5. drop keep ranges shorter than minKeepMs (e.g. 500ms)
6. if keep empty → error 片段覆盖全片
7. if removed empty → skip strip, normal download + toast 无标记片段
```

## Report model

```dart
class StripRemovalReport {
  String bvid; int cid;
  List<StripRemovalItem> removed;
  List<(int,int)> keepRanges;
  int originalDurationMs;
  int estimatedResultMs; // sum keep
}
class StripRemovalItem {
  SegmentType type;
  int startMs, endMs;
  String? uuid;
  String source; // sponsorblock|pgc
}
```

### Report UI

- Bottom sheet / full page after enqueue **or** on completed:
  - Summary: 已去除 N 段，共 M 分 S 秒
  - ListTile each: color dot + shortTitle + `00:12–00:45 (33s)` + type title
  - Expandable description
  - Actions: 打开成品 / 分享 / 关闭

Report is shown from **local model** even if Seal only returns file.

## Protocol extras (Seal v2 additive)

| Key | Type | Meaning |
|-----|------|---------|
| `strip_segments` | Boolean | enable strip mode |
| `keep_sections` | String (JSON array of `{start,end}` seconds) | preferred |
| `remove_segments` | String (JSON array of `{start,end,category?}`) | alt for post-process |
| `strip_report_token` | String | optional correlation id |

Seal TaskFactory maps `keep_sections` → `videoClips` before download.

## Integration with cookie passthrough

- Same download sheet: account picker then strip options (or single combined sheet).
- Strip does not require cookies but bilibili success does.

## File naming

- Seal output template unchanged when possible.
- PiliPlus display name: append ` [去广告]` / ` [stripped]` when showing report / share.

## Errors

| Condition | UX |
|-----------|-----|
| No segments | 普通下载 + toast |
| All filtered out | 普通下载 + toast |
| Full video marked ad | 错误：无法剥离（无剩余正片） |
| Seal sections fail | 回落整段下载 + 可选 D 后处理；或 failed + 重试 |
| duration unknown | fetch from video detail timeLength |

## Progress

- Reuse Seal panel phases; message: `正在去除 N 段标记内容…` when strip on.
- On completed: auto-present report sheet.

## Accessibility / i18n

- ZH primary strings; EN for Seal-side prefs if any.
