# Full CI Status Audit — PiliPlus + Seal

**Audit date:** 2026-07-21  
**Method:** `gh` CLI (runs, workflows, PRs, commit status, check-runs)  
**Repos:** `Chloemlla/PiliPlus`, `Chloemlla/Seal`

---

## STATUS SUMMARY

| Repo | Default branch | HEAD SHA | Critical workflow | HEAD conclusion | Overall |
|------|----------------|----------|-------------------|-----------------|---------|
| **PiliPlus** | `main` | `8efeedd207ad9e1120231b931f26d6fceabe4bbf` | **Build** | **success** | **GREEN** |
| **Seal** | `main` | `3371479090f2c7cacda6704d555e267e1b95e99e` | **Build Pre-Release** | **success** | **GREEN** |

### Verdict: **both main green**

---

## 1. Latest 10 runs each repo

### PiliPlus (`Chloemlla/PiliPlus`) — workflow: **Build**

| # | Conclusion | Workflow | Title | ID | Created (UTC) |
|---|------------|----------|-------|-----|---------------|
| 1 | **success** | Build | fix(deps): align pubspec.lock git package versions with pinned refs | `29760982309` | 2026-07-20T16:45:52Z |
| 2 | **failure** | Build | merge(upstream): integrate origin/upstream into main | `29760667461` | 2026-07-20T16:41:25Z |
| 3 | **success** | Build | fix(seal): use Intent.putExtra for EXTRA_URLS string array | `29758424237` | 2026-07-20T16:10:14Z |
| 4 | **failure** | Build | fix(seal): unblock invoke delay and support multi-P batch URLs | `29756775170` | 2026-07-20T15:47:38Z |
| 5 | **success** | Build | chore(claude): wire Trellis hooks, agents, skills for Claude Code | `29752859882` | 2026-07-20T14:55:54Z |
| 6 | **success** | Build | fix(crash): wait for exit-history staging before native import | `29588393483` | 2026-07-17T14:32:16Z |
| 7 | **success** | Build | fix(crash): import native pending reports after channel ready | `29587315901` | 2026-07-17T14:16:35Z |
| 8 | **success** | Build | fix(crash): align host with lumen-crash-core source | `29586985408` | 2026-07-17T14:11:55Z |
| 9 | **success** | Build | fix(android): align host with Vivo Android 11-17 guidance | `29586588192` | 2026-07-17T14:06:05Z |
| 10 | **success** | Build | fix(onboarding): retry first-launch when navigator is late | `29586102708` | 2026-07-17T13:59:07Z |

**Active workflows:** Build, Build for iOS, Build for Linux x64, Build for Mac, Build for Windows x64  
(Desktop/iOS jobs typically **skipped** on normal main pushes; critical path is Android **Release Android** + **Analyze and Test**.)

### Seal (`Chloemlla/Seal`) — workflow: **Build Pre-Release**

| # | Conclusion | Workflow | Title | ID | Created (UTC) |
|---|------------|----------|-------|-----|---------------|
| 1 | **success** | Build Pre-Release | fix(ui): align glass fill helpers and soften scrim | `29758705118` | 2026-07-20T16:14:03Z |
| 2 | **success** | Build Pre-Release | fix(ui): drop ReadOnlyComposable on glassContainerColor | `29758417117` | 2026-07-20T16:10:09Z |
| 3 | **failure** | Build Pre-Release | style(ui): add local glass surfaces for premium low-cost polish | `29758245332` | 2026-07-20T16:07:49Z |
| 4 | **success** | Build Pre-Release | fix(i18n): escape apostrophe in credit_readyou_desc | `29582481933` | 2026-07-17T13:03:01Z |
| 5 | **failure** | Build Pre-Release | fix(notification): dismiss download notifications on completion | `29582065225` | 2026-07-17T12:56:12Z |
| 6 | **failure** | Build Pre-Release | fix(ui): make open-source notice page compile cleanly | `29577628199` | 2026-07-17T11:40:33Z |
| 7 | **failure** | Build Pre-Release | feat(ui): add first-run open-source notice and richer credits | `29577440490` | 2026-07-17T11:37:09Z |
| 8 | **failure** | Build Pre-Release | feat(onboarding): add first-run fork guide and settings EN/ZH i18n | `29577295452` | 2026-07-17T11:34:32Z |
| 9 | **success** | Build Pre-Release | style(ui): polish download queue actions and empty states | `29507763366` | 2026-07-16T14:41:57Z |
| 10 | **success** | Build Pre-Release | fix(history): restore FileUtil import for media delete reporting | `29505763119` | 2026-07-16T14:15:24Z |

**Active workflows:** Check and Close Issues, Android CI, Build Pre-Release, Generate Sponsors README  
Critical path: **Build Pre-Release** (Lint / BuildPreRelease / Publish).

---

## 2. Failed runs: still relevant vs superseded by later green

### PiliPlus

| Run | Failure root cause | Superseded? |
|-----|--------------------|-------------|
| `29760667461` merge(upstream) | `flutter pub get --enforce-lockfile` exit 65: pubspec.lock mismatched git package versions (`file_picker`, `flutter_smart_dialog`) | **YES** — fixed by HEAD `29760982309` |
| `29756775170` fix(seal) multi-P | Release Android baseline-profile Kotlin compile error; Analyze and Test OK | **YES** — later main green |

**No open red failures relevant to main HEAD.**

### Seal

| Run | Failure root cause | Superseded? |
|-----|--------------------|-------------|
| `29758245332` glass UI | Lint + BuildPreRelease Compose/glass helpers | **YES** — next two commits green |
| `29582065225`…`29577295452` | Compile/i18n/UI iteration failures | **YES** — later green |

**No open red failures relevant to main HEAD.**

---

## 3. Open PRs

### PiliPlus

| PR | Title | Mergeable | Checks | Notes |
|----|-------|-----------|--------|-------|
| **#1** | chore(sync): merge upstream | **CONFLICTING** | CodeRabbit FAILURE; no Build checks | Known fork-sync debt; fork behind_by ~115, ahead_by ~7. **Not** blocking main CI. |

URL: https://github.com/Chloemlla/PiliPlus/pull/1

### Seal

**No open PRs.**

---

## 4. Main HEAD green?

### PiliPlus `8efeedd` — **YES, GREEN**

| Job | Conclusion |
|-----|------------|
| Analyze and Test | success |
| Release Android | success |
| ios / mac / linux / win | skipped (expected) |

### Seal `3371479` — **YES, GREEN**

| Job | Conclusion |
|-----|------------|
| Lint | success |
| BuildPreRelease | success |
| Publish | success |

---

## 5. Remediation

**Current main: nothing red — no main remediation required.**

Historical fixes (already landed):
- PiliPlus lockfile: align `pubspec.lock` with pinned git refs
- PiliPlus baseline profile: later commits compile cleanly
- Seal glass UI: drop ReadOnlyComposable + align fill helpers

Still open (non-main): resolve PR#1 upstream sync on a dedicated branch when ready — do **not** force-merge CONFLICTING PR.

---

## 6. Operational note (post-feature)

```bash
# PiliPlus
gh run list --repo Chloemlla/PiliPlus --branch main --limit 5
gh run watch --repo Chloemlla/PiliPlus <run-id>
gh run view --repo Chloemlla/PiliPlus <run-id> --log-failed

# Seal
gh run list --repo Chloemlla/Seal --branch main --limit 5
gh run watch --repo Chloemlla/Seal <run-id>
gh run view --repo Chloemlla/Seal <run-id> --log-failed
```

- No local Android build required for gatekeeping
- PiliPlus critical: Build → Analyze and Test + Release Android
- Seal critical: Build Pre-Release → Lint + BuildPreRelease

---

## Final one-liner

**Both mains are GREEN.** Failures in latest-10 are superseded. Only open risk is **PiliPlus PR#1 CONFLICTING** (known, not main-blocking). After feature work: `gh run watch` / fix until green.
