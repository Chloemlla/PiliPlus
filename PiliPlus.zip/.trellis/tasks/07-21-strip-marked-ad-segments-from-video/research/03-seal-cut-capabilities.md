# Research: Seal Cut / SponsorBlock Capabilities

- **Date**: 2026-07-21
- **Repo**: `F:\Repositories\GitHub\Seal`

## FFmpeg

- `App.kt` initializes `FFmpeg.init` alongside YoutubeDL / Aria2c.
- yt-dlp postprocessing uses embedded FFmpeg (sponsorblock remove, merge, etc.).

## `--sponsorblock-remove`

**DownloadUtil.downloadVideo** ~L750–752:

```kotlin
if (sponsorBlock) {
    addOption("--sponsorblock-remove", sponsorBlockCategory)
}
```

- Categories from `PreferenceUtil.getSponsorBlockCategories()` when `SPONSORBLOCK` pref true.
- Uses **SponsorBlock network API inside yt-dlp**, **not** PiliPlus segment list.
- Fidelity gap: may differ from PiliPlus `getSkipSegments(bvid,cid)` server/categories.
- **Per-segment report**: yt-dlp does not return structured removed intervals to Seal UI; at best parse stderr (fragile). **Cannot meet “detailed report of PiliPlus marks” alone.**

## `--download-sections` / videoClips

**DownloadUtil** ~L768–772:

```kotlin
videoClips.forEach {
    addOption("--download-sections", "*%d-%d".format(Locale.US, it.start, it.end))
}
```

- `DownloadPreferences.videoClips: List<VideoClip>` — set from UI (FormatPage / VideoSectionSlider), empty by default in `buildFromPreferenceStore`.
- **Keep ranges** semantics: download only listed sections then concat via yt-dlp/ffmpeg.
- Ideal for **PiliPlus-computed keep ranges** if protocol can pass clips.

## L3 completion

- `ExternalDownloadCoordinator` watches task → `completed` + `content_uri` / display_name / mime.
- Caller (PiliPlus) can open/share final file.
- No structured “removed segments” extra today — **report must be owned by PiliPlus** from its own segment list (computed before/at delegate time).

## Limits for detailed report

| Need | sponsorblock-remove | download-sections keep ranges | post-process cut |
|------|---------------------|-------------------------------|------------------|
| Match PiliPlus marks | No (own SB API) | Yes if PiliPlus sends ranges | Yes |
| Detailed ZH report | No | Yes (PiliPlus local list) | Yes |
| Protocol change | Categories string optional | custom keep/remove JSON | remove JSON + file in |

## Recommendation input

For **complete** product: pass **PiliPlus segments** (or keep ranges) into Seal; PiliPlus renders report from same list. Prefer keep-range `download-sections` or explicit remove post-process with known intervals.
