# strip-marked-ad-segments-from-video

## Goal

在 PiliPlus 提供完整能力：基于**已标记**广告/SponsorBlock 片段从视频中剥离并合成成品，**逐条**向用户展示移除的类型与时间范围。不是播放跳过，不是仅 Seal 内置 SB 黑盒。

## Background

- PiliPlus 已有 BilibiliSponsorBlock 数据与播放跳过（`BlockMixin`）。
- 本机无完整 Android 出包；验证 analyze/test + CI。
- Seal 有 FFmpeg、yt-dlp `--sponsorblock-remove` 与 `--download-sections`（videoClips）。
- 仅 A（sponsorblock-remove）**无法**保证与 PiliPlus 标记一致，也**无法**给出逐段报告 → 否决为唯一方案。

## Product decision (完整版)

**主路径 C**：PiliPlus 计算 remove/keep → Seal `download-sections` 只保留 keep → PiliPlus 用同一列表展示详细报告。  
**回落 D**：整段下载后按片段后处理（若 sections 失败）。  
**报告所有权**：始终在 PiliPlus。

## Requirements

### R1 — 标记源

- 使用 `SponsorBlock.getSkipSegments(bvid,cid)`（及当前页已加载列表若一致）。
- 用户可多选剥离类别；默认 `sponsor` + `selfpromo`；禁止默认剥离 `poi_highlight`。
- 过滤 (0,0) 全片标签、过短片段、非法区间。

### R2 — 区间算法

- 合并重叠/邻近；反演 keep ranges；全覆盖时明确失败。
- 纯 Dart 可单测模块（`segment_strip_math`）。

### R3 — 下载集成

- 委托 Seal 时传 `strip_segments` + `keep_sections`（秒或毫秒，文档钉死一种）。
- Seal 映射到 `videoClips` / `--download-sections`。
- 与 cookie 透传、多 P 批量兼容（每 P 各自 segments）。

### R4 — 详细报告（must-have）

每条移除项包含：类型中文名、起止时间、时长、uuid（若有）、来源。  
摘要：段数、总去除时长、预计成品时长。  
完成后可打开/分享成品。

### R5 — 设置

- 总开关、默认类别、最小时长、是否每次询问类别。

### R6 — 错误与回落

- 无标记：普通下载 + 提示。
- sections 失败：可配置回落 D 或失败重试提示。
- Seal 未安装：现有面板。

### R7 — 质量 / CI

- 单测覆盖算法。
- 两仓文档与 CI 绿。

## Acceptance Criteria

- [ ] 用户可一键「下载并去除标记片段」。
- [ ] 成品不包含所选类别标记区间（在 keyframe 精度内）。
- [ ] 报告列出**每一个**移除片段的类型与时间。
- [ ] 默认不移除精彩时刻等非广告类。
- [ ] 无标记时不静默当失败。
- [ ] 多 P 每 P 独立处理或明确仅当前 P（产品默认：与下载选择的 P 集合一致）。
- [ ] 算法单测通过；CI 绿。
- [ ] 协议/文档写清 extras。

## Edge Cases

| Case | Behavior |
|------|----------|
| 片段覆盖片头片尾 | keep 中间 |
| 仅 outro 被选 | 去片尾 |
| bangumi OP/ED (pgc) | 若类别匹配则剥离 |
| 时长未知 | 用详情页 timeLength；仍未知则拒绝 strip |
| 与 extractAudio | 音频同样可 sections 或声明仅视频 |

## Out of Scope

- 云端处理
- 实时播放去广告（已有）
- 帧级手动剪辑器
- 仅依赖 yt-dlp 自带 SB 且无报告

## Technical Notes

- Research `01`–`06`, CI `00`
- Seal `DownloadUtil` videoClips + sponsorBlock paths
- Dual-repo protocol v2 可与 cookie 任务共用版本位

## Definition of Done

- 完整功能 + 详细报告 + 测试 + 文档 + CI
- 非 MVP 缩水交付
