# Video Quality Smart Recommendation

## Goal

Automatically recommend the optimal video quality for each playback based on the user's current network conditions, device performance, battery level, and explicit preferences — without requiring manual selection every time.

## Requirements

### Recommendation factors
| Factor | Weight | Source |
|--------|--------|--------|
| Network speed | High | `connectivity_plus`测速 or recent average throughput |
| Battery level | Medium | `battery_plus` |
| User preference | High | Explicit "省电模式" / "流畅优先" / "画质优先" toggle |
| Device tier | Low | `device_info_plus` (RAM, CPU) |
| Video resolution | Context | Available quality options from player API |

### Recommendation engine
- `QualityRecommendationService` computes recommended quality on each playback start
- Outputs: preferred quality label (e.g., "1080P", "720P60", "480P", "自动")
- "自动" means: dynamically switch quality based on network changes during playback

### User controls
- **Quality mode selector** in player toolbar or settings:
  - `画质优先`: always highest available
  - `流畅优先`: prefer lower resolution + high frame rate
  - `省电模式`: lowest stable resolution, reduces GPU decoding
  - `自动` (default): smart recommendation engine
- When "自动" is active, show a subtle quality chip (e.g., "自动: 1080P → 720P") in the player

### Quality options
- Map to BiliBili quality codes: 120 (4K), 116 (1080P60), 112 (1080P+), 80 (1080P), 74 (720P60), 64 (720P), 32 (480P), 16 (360P), 6 (240P), 0 (auto)
- Respect regional availability (some qualities may not be available in all regions)

### Network speed estimation
- Measure download speed of 2-3 second probe (small file from BiliBili CDN)
- Cache result for 5 minutes
- If no recent data, use `connectivity_plus` network type as heuristic:
  - WiFi → suggest high quality
  - 5G/LTE → suggest medium quality
  - 3G → suggest low quality

## Technical Approach

### Implementation
- `QualityRecommendationService` in `lib/services/`
- `QualityRecommendationController` in `lib/controllers/`
- Hook into `PlayerService.onVideoStart` to compute and apply recommendation
- Store user mode preference in `setting` Hive box

### Quality mapping
```dart
enum QualityMode { qualityFirst, smoothFirst, batterySaver, auto }

String recommendQuality({
  required QualityMode mode,
  required int batteryPercent,
  required NetworkType networkType,
  required double? measuredMbps,
  required List<int> availableQualities,
});
```

### Player integration
- After recommendation is computed, set the player's preferred quality
- If quality is not in available options, fall back to next best
- Show quality chip overlay for 3 seconds when "自动" mode makes a recommendation

## Acceptance Criteria

- [x] Quality mode selector works: 画质优先/流畅优先/省电模式/自动
- [x] "自动" mode recommends quality based on network + battery + preference
- [x] Quality chip shown briefly when auto mode makes recommendation
- [x] Network speed probe works and caches result
- [x] Battery-aware: below 20% battery, lower quality is recommended
- [x] Player respects recommended quality
- [x] Preference persists across restarts
- [x] Works on all platforms

Static implementation review is complete; GitHub Workflow verification remains pending.

## Out of Scope

- Real-time quality switching during playback (future)
- Per-UP master quality preference (future)
- Network quality trending over time
- WiFi vs cellular separate profiles

## Technical Notes

- Check `lib/services/player_service.dart` for player control hooks
- Check `lib/services/setting_service.dart` for preference storage
- `connectivity_plus` is already in pubspec.yaml
- `battery_plus` is already in pubspec.yaml
- `device_info_plus` is already in pubspec.yaml
- No new dependencies needed
