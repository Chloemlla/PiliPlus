# Current local comment favorites audit

- `ReplyCacheStore` and the optional `reply` box currently serve two meanings:
  automatic comment recording (`Pref.saveReply`) and explicit favorites.
- `GStorage.init` does not open the box when `saveReply` is false, so the Mine
  entry and favorite action disappear with recording disabled.
- Auto-recorded replies make `containsKey` return true, so the comment menu can
  label a merely recorded reply as already favorited.
- `MyReply` reads every reply-cache value, while malformed import entries can
  throw before a useful partial-import summary is shown.
- A separate favorite store is the narrowest way to preserve automatic history
  behavior while making explicit favorites reliable and independently bounded.
- Legacy data cannot distinguish old auto-records from explicit favorites. Copy
  all legacy entries once favors preservation over silent loss; new writes are
  separated after migration.
