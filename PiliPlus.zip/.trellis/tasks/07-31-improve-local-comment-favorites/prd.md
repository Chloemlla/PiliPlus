# 完善本地评论收藏夹功能

## Goal

把当前“收藏的评论”从复用自动评论记录的临时实现，完善为独立、可靠且始终可用的本地收藏夹；保留已有收藏数据，避免自动记录把普通浏览过的评论误判为已收藏。

## Requirements

- 主动收藏与 `Pref.saveReply` 自动记录必须使用独立语义：关闭“记录评论”后仍可收藏、查看、导入和导出。
- 为显式收藏使用独立的有界存储 API；页面和评论菜单不得直接操作裸 Box。
- 首次升级时把旧实现中已有的 `reply` 数据一次性迁移到新收藏存储，迁移成功后写入 marker；迁移失败不得清空旧数据，后续启动可重试。
- 自动评论记录继续遵守 `Pref.saveReply`，不得因收藏夹常开而重新启用后台记录。
- 评论更多菜单用独立收藏状态显示“收藏评论 / 取消收藏”，不再把自动记录过的评论当作收藏。
- “我的 → 收藏的评论”入口始终可达；列表显示收藏数量、按时间排序，提供正式的清空入口和确认提示。
- 导入必须逐项验证、按评论 id 去重；坏条目跳过并给出导入摘要，不得因单条格式错误破坏已有收藏。
- 导出只包含显式收藏；取消收藏、批量清空和导入完成后列表立即同步。
- 将列表状态、导入解析等逻辑放入窄 controller/store，避免继续膨胀现有 view 或评论大文件。
- 同一用户可见变更集更新 `WhatsNewData.pages`；主线程统一合并该文件。

## Acceptance Criteria

- [x] 关闭“记录评论”并重启后，仍能收藏评论并从“我的”进入收藏列表。
- [x] 浏览/自动记录的评论不会自动显示为已收藏。
- [x] 升级后旧“收藏的评论”数据仍可见；失败迁移不会删除旧数据。
- [x] 收藏、取消收藏、清空、合法导入与去重导入均正确更新列表和计数。
- [x] 非法导入条目被跳过并提示，已有收藏不丢失。
- [x] 页面层仅通过 typed store/controller 操作收藏数据。
- [ ] GitHub Actions 中 Analyze/Test/Android 构建通过；本地不运行 Flutter、Gradle、analyze 或测试。

## Technical Approach

新增独立 `favoriteReply` MMKV/Hive backed box 与小型 `FavoriteReplyStore`，沿用现有 `BoundedStringKeyLru` 模式但使用独立 order key。`GStorage.init` 始终打开收藏 box；旧 `reply` box 仍仅在 `saveReply` 开启时用于自动记录。以 local-cache marker 驱动一次性 copy-on-success 迁移。评论菜单改用 favorite store，`MyReply` 抽取 controller 负责读取、排序、导入校验、清空和状态刷新。

## Out of Scope

- Bilibili 服务端收藏 API。
- 视频、动态、专栏等非评论类型的通用本地收藏系统。
- 标签、文件夹、云同步或全文索引。
- 本地执行 Flutter/Gradle/模拟器/分析/测试。

## Definition of Done

- 独立收藏存储、迁移、菜单和列表体验落地。
- 新增 focused tests，由 GitHub Actions 执行。
- `WhatsNewData.pages` 同步说明。
- 提交、推送、CI 全绿后归档任务。
