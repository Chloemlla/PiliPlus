# Synapse mapping

## Existing service

* Express 5 app assembly is in `src/app.ts` and `src/app/assembly.ts`; routes are registered through `src/routes/index.ts`.
* Existing authentication includes `src/middleware/authenticateToken.ts` (session JWT/cookie) and NexAI-specific JWT auth. Existing NexAI sync routes and models provide revision/incremental-sync patterns.
* MongoDB is initialized in `src/app/startup.ts`; existing sync models include `src/models/nexaiSyncModel.ts` and `src/models/nexaiEncryptedSyncModel.ts`.

## Security conclusion

Synapse has no existing Bilibili identity binding. A client-provided UID cannot authorize access. The API must bind a verified Bilibili identity to an authenticated Synapse principal or issue a short-lived token after a one-time Bilibili authorization flow.

## Recommended contract

Add an isolated `/api/bilibili-sync` module. Use an authenticated principal derived server-side, with a HMAC/opaque owner key rather than a raw UID. Store versioned settings and search records with `ownerKey`, category, record ID, revision, deletion state, device ID, and timestamps. Enforce unique owner/category/record indexes, incremental revision reads, rate limits, bounded records, and payload validation. Keep cookies, access tokens, passwords, and API keys out of payloads and logs.

## Deployment/CORS

Reuse the configured credentialed CORS allowlist, WAF/security pipeline, JWT middleware, and route limiters. Do not use wildcard open CORS for private sync data. The service is deployed as the existing Node/Bun-compatible Docker application backed by external MongoDB.
