# PiliPlus mapping

## Local storage

* `lib/utils/storage.dart`: `GStorage.setting`, `GStorage.video`, and `GStorage.historyWord` are the relevant Hive boxes. `GStorage.exportAllSettings()` and `importAllJsonSettings()` provide the existing settings snapshot/import seam.
* `lib/utils/storage_key.dart` and `lib/utils/storage_pref.dart`: settings keys and typed preference accessors. Search-history opt-in is `Pref.recordSearchHistory`.
* `lib/utils/storage/settings_import_transaction.dart`: existing rollback contract for multi-box settings replacement. Do not include `SettingSecretStore` data in the remote payload.

## Search history

* `lib/pages/search/controller.dart`: local history is `GStorage.historyWord['cacheList']`, capped at 100 entries. Submit, single-delete, and clear are separate write paths.
* `lib/http/user.dart` / `lib/http/api.dart` `searchHistory` refers to Bilibili's remote search-history endpoint, not PiliPlus local search keywords. The new sync must not reuse it.
* Local history is currently global across accounts; syncing must namespace by `Accounts.main.mid` and define dedupe/delete/ordering behavior.

## Account and lifecycle

* `lib/utils/accounts/account.dart`: `LoginAccount.mid` is derived from the `DedeUserID` cookie; cookies and access tokens are secrets and must never enter the sync payload.
* `lib/utils/accounts.dart`: `Accounts.main` is the current account authority. Account storage must not depend on HTTP or UI.
* `lib/utils/login_utils.dart`: `initializeSession()`, `onLoginMain()`, and `onLogoutMain()` are the lifecycle seams. Startup sync should run only after account refresh and WebView cookie writes; login sync should run after user identity confirmation.

## Integration recommendation

Use a dedicated sync service/repository: `Accounts.main.mid` -> namespace, `GStorage` -> safe snapshot, `Request` -> external transport, and settings/search UI -> user actions. Avoid putting network calls in `Accounts`, `AccountManager`, or individual settings models. External sync requests must not be routed through Bilibili account cookie injection.
