# Bilibili account settings and search history remote sync

## Goal

Allow PiliPlus users to opt in to syncing selected app settings and search history with the Synapse service. On a later login using the same Bilibili account ID, the app should ask before enabling sync, detect an available saved configuration, and let the user pull and apply it. The PiliPlus client and Synapse service must share a versioned, authenticated, privacy-preserving contract.

## What I Already Know

* The user requests changes in `F:\Repositories\GitHub\PiliPlus` and the remote service source under `F:\Repositories\GitHub\Synapse\src`.
* The user requires automatic parallel subagent delegation, `gh`-based inspection and repair of all GitHub Actions, and forbids local Flutter, Gradle, emulator, and full build/test execution.
* Declarative dependency installation is allowed when needed for static inspection.
* PiliPlus is a Flutter application with existing settings, search-history, Bilibili account, startup, and onboarding flows.
* Synapse is a Bun/TypeScript service with existing route, middleware, storage, authentication, and model modules.
* User-facing behavior must update `lib/pages/onboarding/whats_new_data.dart` in the same PiliPlus change set.

## Assumptions

* Existing Synapse authentication/storage primitives can be reused; no new secret is stored in the Flutter client.
* Bilibili account ID is an identifier, not sufficient authentication by itself. The sync API will bind it to an authenticated Synapse identity or a short-lived signed client token.
* The first MVP syncs settings and search history only; cookies, access tokens, downloads, playback history, and other secrets remain local.
* Pull is explicit after the user sees the opt-in/available-backup prompt. Background upload may occur only after opt-in and successful authentication.

## Open Questions

* What exact settings are safe and useful to include in the portable sync payload?
* Should a remote/local conflict default to remote, local, or an explicit choice?

## Requirements (Evolving)

* Add a clearly labeled opt-in setting and first-use confirmation explaining data scope, remote storage, disable/delete behavior, and offline behavior.
* Associate sync records with the authenticated user and Bilibili account ID, with account ID normalization and authorization checks.
* Reuse the existing Synapse account JWT. The user must sign in to Synapse and explicitly bind the current Bilibili UID before sync is enabled; sync endpoints derive ownership from the authenticated Synapse user and server-side binding.
* Sync is unavailable when no valid logged-in Bilibili account is present. The client must gate the UI and all automatic sync triggers on `Accounts.main.isLogin` and a non-zero current UID.
* During binding, the client sends the current Bilibili session proof only over TLS. Synapse must verify the cookie by calling an authoritative Bilibili identity endpoint, confirm the returned UID matches the requested current UID, and reject expired, malformed, mismatched, or unverifiable cookies. After successful validation, Synapse stores the cookie only as an encrypted credential archive scoped to the authenticated Synapse user and verified Bilibili UID; it is never stored in plaintext, sync records, logs, responses, or analytics.
* Archived Bilibili credentials must support explicit revocation/ deletion on unbind, invalidation when revalidation fails, and replacement by a newly validated cookie. Sync requests must fail closed when the archive is absent or invalid.
* Merge search records by stable record identity/normalized keyword and timestamps; propagate deletions with tombstones so deleted records do not reappear from another device.
* Do not silently overwrite settings when both local and remote snapshots changed. Present a conflict summary and let the user choose remote, local, or a safe-field merge.
* Upload versioned settings and search-history snapshots/deltas idempotently, with bounded payloads and retry/backoff that cannot block login or playback.
* On the same-account login, check whether a compatible saved configuration exists, ask whether to use it, and apply only after confirmation.
* Support explicit upload now, pull now, disable sync, and delete remote data where the existing UI architecture permits.
* Validate all remote payloads at both boundaries and never log/store secrets or authentication tokens in the sync payload.
* Keep Android, iOS, desktop, and web behavior consistent through platform-neutral Dart service/UI code; native code is only used where existing networking/storage constraints require it.
* Add focused unit/service tests for serialization, authorization, opt-in gating, conflict handling, retries, payload limits, and startup/login behavior.
* Update the build What's New content for the user-visible feature.

## Acceptance Criteria (Evolving)

* [ ] A user can enable sync only after an explicit consent prompt and can later disable it.
* [ ] An opted-in user can upload settings and search history without blocking normal app use.
* [ ] A later login with the same Bilibili account ID detects an available compatible remote snapshot and asks before applying it.
* [ ] A declined or incompatible snapshot is not applied and does not silently overwrite local data.
* [ ] Search records merge deterministically, preserve the newest valid record, and propagate deletions with tombstones.
* [ ] Concurrent settings changes produce an explicit conflict choice rather than silent overwrite.
* [ ] Unauthorized users cannot read or write another user's snapshot by changing the Bilibili account ID.
* [ ] A sync request with a valid JWT but an unbound or mismatched Bilibili UID is rejected without revealing another binding.
* [ ] Logged-out or invalid-Bilibili-account users cannot see an active sync action and all automatic sync paths no-op safely.
* [ ] Binding rejects invalid/expired/mismatched Bilibili cookies and only succeeds when server-side identity verification matches the current UID.
* [ ] Binding verification never stores the submitted Bilibili cookie in plaintext, logs, responses, sync records, or analytics; a successful bind stores only an encrypted credential archive.
* [ ] Unbinding removes or cryptographically invalidates the archived Bilibili credential and later sync requests fail closed.
* [ ] Offline/network/server failures are surfaced as recoverable status and do not crash startup.
* [ ] Secrets, cookies, access tokens, and unrelated private data are excluded from sync payloads and logs.
* [ ] CI is inspected with `gh`; any failures are repaired and re-verified until green or explicitly blocked.

## Definition of Done

* Tests and static checks are added/updated for both repositories.
* No local Flutter, Gradle, emulator, or full build/test command is run; GitHub Actions remains the build/test authority.
* API/data contract documentation is updated.
* `WhatsNewData.pages` is updated in the PiliPlus change set.
* Changes are committed and pushed for both repositories after verification.

## Out of Scope

* Syncing Bilibili cookies, access tokens, passwords, API keys, downloads, media files, or playback position as application settings or cross-device sync data. The validated Bilibili cookie archive is a separate encrypted server credential store.
* Anonymous public sync keyed only by a Bilibili UID.
* Replacing Synapse's existing identity system; the feature extends its account identity/binding model.
* Running local Flutter/Gradle builds or emulator tests.

## Technical Notes

* Relevant local specs: `.trellis/spec/frontend/flutter-persistence-recovery.md`, `.trellis/spec/frontend/flutter-startup-context.md`, `.trellis/spec/frontend/flutter-build-whats-new.md`, `.trellis/spec/frontend/ci-action-auto-repair.md`, `.trellis/spec/backend/directory-structure.md`, `.trellis/spec/backend/error-handling.md`, `.trellis/spec/backend/database-guidelines.md`, `.trellis/spec/backend/logging-guidelines.md`.
* Research artifacts will be added under `research/` after repository and CI reconnaissance.

## Decision (ADR-lite)

**Context**: The sync record needs both a convenient Bilibili account namespace and real authorization. A raw Bilibili UID or client-provided cookie is not sufficient and would allow account probing or takeover.

**Decision**: Reuse Synapse's existing account JWT. Add an explicit binding flow that associates the currently logged-in Synapse user with the current PiliPlus Bilibili UID. Subsequent settings/search sync requests authenticate with the Synapse JWT; the server resolves the owner from the JWT and verifies the bound Bilibili UID. The client never treats the UID as a credential.

**Consequences**: Users have an extra sign-in/binding step, but the implementation reuses existing session authentication, server storage, CORS, and revocation behavior. Binding replacement/unbinding, one-user/multi-account policy, and conflict handling must be explicit before implementation.

## Conflict Decision

**Decision**: Search history uses deterministic merge/dedupe with tombstone deletion propagation. Settings use an explicit conflict prompt with remote, local, and safe-field merge choices.

**Rationale**: Search history is append-oriented and can be merged without losing independent entries. Settings contain heterogeneous values and platform-specific options, so silent last-write-wins would risk unexpected behavior or data loss.
