# 三端 Synapse OAuth 授权与设备会话管理

## Goal

让 PiliPlus 与其他第三方应用可以调用已登录的 Synapse-Client 完成 Synapse 用户授权，消除授权过程中对浏览器登录跳转和 JWT 回调的依赖；同时让 Synapse-Client 与 Happy-TTS 记录、展示和安全管理登录设备及活跃会话，并在 Profile 中显示 IP 属地。

## Requirements

* Synapse-Client 接收第三方应用发起的 OAuth authorization request，使用本机已登录的 Synapse 账号请求服务端预览，在 App 内展示客户端、回调地址、scope 和授权账号，用户确认后才批准或拒绝。
* 设备内授权必须复用现有 OAuth authorization-code + PKCE 机制；授权 URI 只携带 OAuth 请求参数，不携带 JWT、access token、refresh token 或 client secret；授权结果仅通过已登记的 redirect URI 返回一次性 code 和 state。
* Happy-TTS 增加与 Synapse-Client 配套的受保护 mobile OAuth preview/approve/deny API，服务端校验 Bearer JWT、OAuth client、redirect URI、scope、PKCE 和用户授权资格，并复用现有 `approveAuthorization` / `denyAuthorization` 逻辑。
* PiliPlus 将 Synapse 云同步授权改为调用 Synapse-Client 的设备内授权 URI；PiliPlus 使用 PKCE code 换取 OAuth token，保存凭据到现有加密存储，并保留当前 B 站 UID 绑定与同步行为。授权失败、拒绝、超时和回调参数错误必须可恢复，不能回退到浏览器登录或接收 JWT。
* Happy-TTS 在每次成功登录、移动端 client token 签发/交换、OAuth 授权和普通受保护会话请求时记录用户设备/会话活动：设备标识、名称、平台/UA、首次/最近活动时间、IP、IP 属地、当前会话标识和撤销状态；敏感 token 只能存哈希或加密值，日志不得输出原文。
* Synapse-Client 可以查看当前账号的活动设备/会话，显示设备名、平台、最近活动、IP 属地和当前设备标识；在通过当前设备的安全确认后，只允许撤销其他设备/会话，撤销后服务端 token/session 立即失效。
* Happy-TTS Profile 展示当前用户活动设备/会话和 IP 属地，提供安全会话校验后的网页设备登出操作；当前查看 Profile 的设备必须标记为当前设备且不可从该列表自助撤销，当前 Profile 会话不能被该操作意外注销。
* PiliPlus 作为独立的客户端设备纳入设备追踪名单，记录客户端标识、设备活动、IP 和 IP 属地；PiliPlus 设备登出按客户端/设备维度撤销该账号对应的全部会话、client token 及 OAuth access/refresh token。
* 网页设备登出按选中的网页设备撤销其全部关联会话；其他 Clients 登录的设备/客户端按客户端维度撤销该账号对应的全部会话、client token 及 OAuth access/refresh token，不能只撤销单个 token。
* IP 属地使用现有项目 IP 归属能力或配置的提供方，失败时返回稳定的“未知”而不是阻断登录；页面同时遵守隐私边界，不在日志、错误和客户端持久化中暴露 token。
* 同步更新用户可见的 PiliPlus `WhatsNewData.pages`，使用现有动态 build identity getter，不硬编码 hash/time。

## Acceptance Criteria

* [ ] 已登录 Synapse-Client 可以从 `synapse://oauth/authorize` 接收合法 PKCE 请求并在 App 内完成同意/拒绝；无登录凭据、过期请求、非法来源或不合法 redirect URI 均失败关闭。
* [ ] Happy-TTS mobile OAuth API 对授权者、client、redirect URI、scope、state 和 PKCE 做完整校验，返回一次性 code/错误回调，服务端测试覆盖成功、拒绝、过期和重放。
* [ ] PiliPlus 授权流程不再打开 `/login`，不解析 `token` query 参数，能够交换 code 并完成既有 B 站 UID 绑定/同步；取消和失败会清理临时 PKCE 状态。
* [ ] 登录/移动 client token/OAuth 访问会更新设备会话记录，设备列表只返回当前用户数据，并包含 PiliPlus 客户端设备；网页设备登出会使该设备全部会话失效，PiliPlus 或其他 Clients 登出会使该客户端对应的全部会话和 token 失效。
* [ ] Synapse-Client 和 Happy-TTS Profile 展示设备活动与 IP 属地；安全状态失效时撤销操作被拒绝；当前 Profile 设备不可撤销。
* [ ] 修改后的代码遵守各仓库 AGENTS.md；不运行本地 Flutter、Gradle、构建或测试命令，验证交由 GitHub Actions。

## Definition of Done

* 三个仓库的实现、API/URI 契约文档和必要的单元/集成测试已更新。
* 静态检查、类型检查和测试由 CI 执行并通过；本地仅进行源码检查和 diff 审阅。
* 每个仓库的用户可见功能变更分别生成 conventional commit 并推送；不包含用户未修改的脏文件。
* 没有向根目录超级文件写入；Synapse-Client 当前已有 `.trellis` 删除改动保持原样。

## Technical Approach

* Happy-TTS 作为 OAuth Provider，新增 mobile 授权入口，授权请求仍采用既有 `OAuthAuthorizeRequest`、`validateAuthorizeRequest`、`approveAuthorization` 和 `denyAuthorization`，用当前 Synapse JWT 作为授权会话而不是让 App 读取浏览器 cookie。
* Synapse-Client 新增 OAuth intent parser、预览/确认 ViewModel 状态和安全 UI，回调使用 OAuth 标准 redirect URI；URI 来源校验、HTTPS API origin 校验和 token 脱敏沿用现有 auth 组件。
* PiliPlus 新增 PKCE 生成/校验和 OAuth token transport，使用 Android `synapse` handoff URI；平台不支持打开 Synapse-Client 或回调时显示可重试错误，不使用浏览器 token 兜底。
* 设备会话以稳定的 server-side session/client-token 记录为主，PiliPlus 使用明确的 client/device 标识写入同一设备名单；现有风险设备追踪继续承担风控职责。Profile 的撤销接口通过安全会话 token 和当前 session id 做保护。IP 属地通过现有配置能力解析并缓存短期结果。

## Decision (ADR-lite)

**Context**: 浏览器跳转会把登录态和回调处理分散到浏览器、WebView 与第三方应用，当前 PiliPlus 还接收 URI 中的 JWT；同时现有设备追踪不等同于可撤销登录会话。

**Decision**: 采用 Synapse-Client 作为本地授权代理，服务端仅签发一次性 OAuth code；增加独立可撤销的会话/设备活动视图，撤销操作要求安全状态且排除当前 Profile 设备。保留现有 OAuth 的 admin/trusted 授权资格和 PKCE 规则。

**Consequences**: Android 需要新增 intent/UI 和服务端 mobile endpoints，PiliPlus 需要配置/使用 public OAuth client；不会泄露 JWT，但部署需要为 PiliPlus/第三方登记 redirect URI 和 client ID。浏览器作为登录入口不再用于此授权流程，但仍可保留在其他独立登录场景。

## Out of Scope

* 不改变 Synapse OAuth 现有 admin/trusted 授权资格，不开放后台通配 scope。
* 不重构已有 Bilibili 登录设备页面；本需求中的设备列表指 Synapse/Happy-TTS 登录会话。
* 不在本地运行 Flutter、Gradle、模拟器、完整测试或构建；不安装依赖。
* 不修改 Synapse-Client 工作区已有 `.trellis` 删除内容，不写任何超级文件。

## Technical Notes

* PiliPlus 当前授权入口：`lib/services/synapse_sync_service.dart` 中 `_SynapseAuthorizationDialog`，使用 `PageUtils.launchURL` 和 `piliplus://synapse-auth?token=...`。
* PiliPlus 当前加密凭据：`lib/utils/setting_secret_store.dart`、`lib/services/synapse_sync_service.dart`。
* Happy-TTS OAuth 核心：`src/services/oauthService.ts`、`src/controllers/oauthController.ts`、`src/routes/oauthRoutes.ts`、`src/models/oauthModel.ts`。
* Happy-TTS Profile：`src/routes/admin/profile.ts`、`frontend/src/components/UserProfile.tsx`、`frontend/src/components/user-profile/profileHelpers.ts`。
* Happy-TTS 现有风险设备模型：`src/models/deviceTrackingModel.ts`，需与可撤销登录会话区分。
* Synapse-Client 当前 auth 核心：`SynapseAuthRepository.kt`、`SynapseMobileLoginApi.kt`、`SynapseLoginViewModel.kt`、`MainActivity.kt`；已注册 `synapse://mobile-login` 和 `synapse://linuxdo-callback` intent。
* 用户约束：本地不执行 Flutter/Gradle/build/test；实际验证必须在 GitHub workflow 完成；修改后自动 commit/push。
