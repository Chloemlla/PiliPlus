# 确认文档 —— 三条需求完整版落地计划

> **日期**：2026-07-21  
> **状态**：research + PRD 完整撰写完毕，jsonl 已 curation，等待确认后启动实现

---

## 实施路线 （最优性能并行）

```
        ┌── T1: Metadata 修复（Seal only, ~2 个常量）
Push ──┤
        ├── T2: Cookie v2 协议（Seal 侧前置、PiliPlus 侧 UX）
        │
        └── T3: 广告剥离（依赖 v2 extras，并行工程）
```

| 序号 | 任务 | 改动量 | 仓库 | 关键变更 |
|------|------|--------|------|----------|
| **1** | B 站 JSON metadata / Errno 103 修复 | **最小**（3 处常量） | Seal | `-R 1→10`, `socket-timeout 5→30`, 错误文案 |
| **2** | Cookie 多账号透传 Seal | 中等（双仓协议 + UX） | Seal + PiliPlus | 协议 v2、`json_map`/netscape cookie extras、Seal 门禁、PiliPlus 账号选择 |
| **3** | 广告剥离 + 详细报告 | 中高（算法 + 协议 + 报告 UI） | Seal + PiliPlus | keep-range 算法、`keep_sections` extra、Seal videoClips、PiliPlus 报告 |

---

## 各任务详细计划

### T1: B 站 JSON metadata / Errno 103

**改 Seal (`F:\Repositories\GitHub\Seal`)：**

| 文件 | 改动 |
|------|------|
| `app/.../util/DownloadUtil.kt` L88–93, L174–176 | `-R 1` → `-R 10`; `--socket-timeout 5` → `--socket-timeout 30`(getPlaylistOrVideoInfo + fetchVideoInfoFromUrl) |
| `res/values/strings.xml` + `zh` | 新字符串 `fetch_info_transport_error`（ZH: "网络中断，获取视频信息失败。请重试；若为 B 站，请在 Seal 设置中启用 Cookies 或登录"） |
| `app/.../download/DownloaderV2.kt` | 外部任务失败时包可读 error_message（不改签名，仅文案） |

**不改 PiliPlus**（独立交付，不依赖 cookie 任务）。

**验证**：Seal Build Pre-Release `gh run watch`。

---

### T2: Cookie 多账号透传

**Phase 1 — Seal 侧（协议基础 + 门禁，无 PiliPlus 也能落地）：**
- `ExternalDownloadProtocol.kt`：PROTOCOL_VERSION=2, MAX=2；新 extras (`cookies_format`, `cookies`, `cookies_uri`, `cookies_mid`, `use_cookies`)；新错误码
- `ExternalDownloadRequestParser.kt`：解析 cookie extras，size cap 256KB
- `ExternalDownloadGate.kt`：新策略项 `EXTERNAL_ACCEPT_COOKIES`，默认**关**
- `ExternalDownloadCoordinator.kt`：session 绑 task cookie 文件路径
- `DownloadUtil.kt`：task-scoped `--cookies` 替代全局路径
- `FileUtil.kt`：`getExternalTaskCookiesFile(taskId)`，终态删除
- `InteractionPreferencePage.kt`：开关 "允许外部应用提供 Cookies"
- 单元测试：parser cookie 格式 + gate reject

**Phase 2 — PiliPlus 侧（UX + Channel）：**
- `seal_download_utils.dart`：多账号选择 sheet、记住 mid、attach cookie map
- `SealDownloadChannel.kt`：`protocol_version=2` 当有 cookie
- `storage_key.dart` / `storage_pref.dart`：`sealCookiePassthrough`, `sealCookieRememberMid`, `sealCookieAlwaysAsk`
- 设置 UI + 文档 `flutter-seal-download-delegate.md`

**不写 Seal CookieProfile DB**（任务级文件，终态删除）。

---

### T3: 广告剥离完整版

**PiliPlus 侧（核心算法 + 报告 UI）：**
- 新 `lib/utils/segment_strip_math.dart`：mergeOverlap / invertToKeep / filterByCategory / minDuration
- 新 `test/utils/segment_strip_math_test.dart`
- 新 report model class
- `seal_download_utils.dart`：strip 分支；fetch segments → compute keep → `keep_sections` JSON → delegate
- Report bottom sheet UI

**Seal 侧（协议 + sections）：**
- `ExternalDownloadProtocol.kt`：`strip_segments`, `keep_sections`, `remove_segments` extras
- `TaskFactory.kt`：`keep_sections` → `videoClips` on preferences
- `DownloadUtil.kt`：已有 videoClips 支持，无需大改

**下载前 PiliPlus 已持有完整报告模型**——即使 Seal 只返回文件。

---

## 改动统计

| 仓库 | T1 | T2 | T3 | 总计（约） |
|------|-----|-----|-----|----------|
| Seal | ~3 文件 | ~9 文件 | ~3 文件 | ~12 文件 |
| PiliPlus | 0 | ~7 文件 | ~7 文件 | ~12 文件 |
| **总** | **~3** | **~16** | **~10** | **~24 文件** |

---

## CI 策略

- 每条实现 -> push -> `gh run watch` -> 检查失败日志 -> 修复 -> re-push -> 直至绿
- 无本地 Android 出包；Build (PiliPlus) + Build Pre-Release (Seal) 为唯一门禁
- 两仓 main HEAD 当前均绿

---

## 验收总表

| 功能 | 关键 AC |
|------|---------|
| Metadata 修复 | 暂态 abort 自恢复；不配 cookie 时错误文案 cue 用户配置 |
| Cookie 透传 | 账号选择 + 记住；Seal 门禁可关；任务级文件隔离；日志无 secret；v1 仍可用 |
| 广告剥离 | 一键去广告成品；报告逐条 ZH 类型+时间；默认 sponsor+selfpromo；无标记提示 |

---

**确认后即刻开始三路并行落地实现。**
