# Implement PiliPlus 2026-07-10 Audit Fixes

## Goal

Implement every confirmed or suspected corrective action in `audit-report-PiliPlus-2026-07-09.md`, prioritizing data integrity and recovery guarantees while also establishing typed persistence and dependency boundaries that prevent the same failure classes from returning.

## Requirements

- Treat a completed Hive-to-MMKV migration as authoritative: a later MMKV decode failure must never restore stale Hive data automatically.
- Make MMKV logical batches (`putAll`, `deleteAll`, whole-box replacement) all-or-nothing from the caller's perspective, including persistent contents, cache, and emitted events.
- Validate imported settings before mutation using a versioned schema with key-specific type, enum range, numeric range, list-shape, and startup-critical validation.
- Canonicalize imported and refreshed accounts by `LoginAccount.secretKey`, resolve duplicate aliases deterministically, and delete obsolete aliases only after canonical data is safely persisted.
- Remove silent persistence failures on critical paths. Await writes where completion is part of the operation; use an explicit centrally reported background-write helper only where best-effort persistence is intended.
- Introduce typed storage boundaries for settings, watch progress, reply cache, and accounts. Migrate high-risk page/controller writes covered by the report and prevent new page-layer raw `GStorage` mutations.
- Break the identified core dependency cycles: Accounts must not depend on Mine UI, storage initialization must not depend circularly on Pref, HTTP transport must not depend on concrete endpoint modules, and model enums must not construct page widgets.
- Make account and setting secret files crash-safe using same-directory temporary files, validation, atomic replacement where supported, and last-known-good backups. Invalid key/data files must be quarantined or recovered without silently destroying valid metadata.
- Make WebDAV backup replacement preserve the previous valid backup if upload or replacement fails; validate uploaded content and clean temporary files on success/best effort.
- Ensure common data/list controllers always release their loading guard and convert thrown handler/parsing errors to diagnosable UI error state.
- Synchronize WebView cookies against a valid HTTPS origin and await completion in startup/login flows with per-cookie diagnostics.
- Handle backward audio seeks as explicit playback-history events: reset throttling state and immediately report the lower progress before normal throttling resumes.
- Add or update focused tests for migration corruption, batch failure injection, settings schema rejection/rollback, account aliases, secret recovery, WebDAV replacement, controller retry, cookie ordering, and backward seek behavior.
- Add a lightweight import-boundary CI check that prevents new `utils -> pages` and `models -> pages` dependencies and protects the newly removed core cycles.
- Keep changes split across cohesive files and modules; do not create a new oversized "super file".

## Acceptance Criteria

- [ ] Completed MMKV migrations never fall back to legacy Hive after MMKV decode failure, and corrupt data remains diagnosable/recoverable.
- [ ] Injected failure on the Nth batch operation leaves backend data, cache, and events at the pre-operation state.
- [ ] Invalid/unknown settings backups are rejected before clearing boxes, while valid older supported backups migrate successfully.
- [ ] Account storage contains only canonical keys after import/refresh; deleting an imported alias account cannot resurrect it.
- [ ] Critical storage failures are awaited and surfaced or compensated; intentional background writes have explicit error reporting.
- [ ] Secret writes retain a readable previous generation when replacement is interrupted or validation fails.
- [ ] Failed WebDAV upload/replacement leaves the old official backup untouched.
- [ ] Common controllers can successfully retry after a thrown request/parse/handler exception.
- [ ] Cookie URLs contain no whitespace/invalid host and login completion occurs after all cookie writes settle.
- [ ] A backward audio seek immediately reports the target progress and subsequent heartbeats resume normally.
- [ ] Typed store/repository APIs own schemas for the audited high-risk domains, and boundary checks reject new forbidden imports.
- [ ] Repository-approved CI workflow covers analysis/tests; no Flutter or Gradle command is run locally.
- [ ] Changes are committed and pushed to the current branch without GPG signing if signing is unavailable.

## Definition of Done

- Code and tests are updated for every audit finding.
- Static inspection and non-Flutter repository checks show no unresolved audited call sites or forbidden new dependencies.
- GitHub Actions is used for actual Flutter analysis/tests/build verification.
- Relevant Trellis specs record the new persistence, recovery, and dependency contracts.
- The task changes and audit report are committed and pushed.

## Technical Approach

Use narrow adapters and transactional helpers rather than a broad rewrite. Extend the MMKV backend contract with snapshot/replace or batch primitives and implement rollback verification in both Dart and Android adapters. Add small typed store/repository classes around existing boxes, then migrate audited callers. Use reusable atomic-file helpers for both secret stores. Keep UI behavior stable while moving ownership out of pages/models through callbacks, events, factories, or injected ports.

Tests should use existing fake/in-memory backends and mocks so failure positions and ordering are deterministic. Actual Flutter/Gradle execution remains CI-only per repository instructions.

## Decision (ADR-lite)

**Context**: The audit spans immediate correctness bugs and structural causes. Fixing only symptoms would leave raw storage access, cyclic dependencies, and inconsistent error contracts that recreate the same failures.

**Decision**: Implement all twelve detailed findings plus the report's minimum typed-boundary and dependency-cycle remediations in one coordinated task, using incremental adapters and focused migrations rather than rewriting the application.

**Consequences**: The diff will be broad, but each change remains independently reviewable and testable. Full feature-first reorganization and splitting every existing large player/video file are excluded because they are not necessary to close the reported invariants and would materially increase regression risk.

## Out of Scope

- A complete rewrite of storage, account, networking, video, or player subsystems.
- Eliminating every historical bidirectional import pair unrelated to the four core cycles identified for immediate remediation.
- Splitting all existing 1,000+ line files solely based on size.
- Adding a new platform credential-store dependency without an existing project-approved implementation.
- Running Flutter, Dart analyzer through Flutter, Gradle, Android builds, or tests locally.

## Technical Notes

- Source of truth: `audit-report-PiliPlus-2026-07-09.md`.
- Repository instruction: all real build/test commands run in GitHub workflows only.
- Relevant specs: `.trellis/spec/frontend/android-mmkv-storage.md`, `.trellis/spec/frontend/quality-guidelines.md`, and thinking guides under `.trellis/spec/guides/`.
- Existing working-tree change at task start: the audit report itself was untracked and belongs to this task.
