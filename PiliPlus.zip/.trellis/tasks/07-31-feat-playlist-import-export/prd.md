# Playlist Import and Export

## Goal

Let users save their video playlists (收藏夹、稍后再看、追番列表) as portable files (JSON/m3u8), and import playlists from files. Enables backup, transfer between accounts/devices, and sharing playlists with others.

## Requirements

### Export formats
| Format | Content |
|--------|---------|
| JSON | Full metadata: bvid, title, cover, author, addedAt, description |
| m3u8 | Simple playlist: `#EXTINF:duration,title\nhttps://...` with direct video URLs (if resolvable) or bvid references |

### What to export
- 收藏夹 (favorite lists): select one or multiple lists
- 稍后再看 (watch later)
- 追番/追剧列表 (following series)
- Custom playlist (if supported by the app)

### Export flow
- Select what to export → choose format → generate file → share via system share sheet or save to Downloads
- For m3u8: if direct URLs are not resolvable client-side, export as bvid-reference format with a note

### Import
- Import from JSON file: parse and validate, show preview (title + count), confirm import
- Import behavior: add videos to "稍后再看" or a dedicated "已导入" playlist
- Duplicate handling: skip bvid duplicates with a summary ("已跳过 3 个重复")

### Storage format
- JSON export schema:
```json
{
  "version": 1,
  "app": "PiliPlus",
  "exportedAt": "2026-07-31T...",
  "playlistName": "我的收藏",
  "count": 42,
  "videos": [
    {
      "bvid": "BVxxxx",
      "title": "...",
      "cover": "https://...",
      "author": "...",
      "authorMid": "...",
      "duration": 1234,
      "addedAt": "..."
    }
  ]
}
```

## Technical Approach

### Implementation
- `PlaylistExportService` / `PlaylistImportService` in `lib/services/`
- Use `file_picker` (already in pubspec.yaml) for file save/load dialogs
- Use `share_plus` (already in pubspec.yaml) for system share sheet
- Use `dio` for URL resolution if direct URLs needed for m3u8

### API integration
- `FavoriteAPI.getList(fid)` for favorite list items with full metadata
- `FavoriteAPI.getSeasonFollowList()` for 追番
- `WatchLaterAPI.getList()` for 稍后再看

### File handling
- Desktop: `FilePicker` saves to user-chosen location
- Mobile: save to Downloads or share via system sheet

## Acceptance Criteria

- [x] Export single favorite list as JSON with full metadata
- [x] Export multiple favorite lists as JSON
- [x] Export watch later list
- [x] Export as m3u8 format
- [x] Import JSON playlist from file
- [x] Preview before import showing title + count
- [x] Skip duplicates on import with summary
- [x] Share exported file via system share sheet
- [x] Works on all platforms

Static implementation review is complete; GitHub Workflow verification remains pending.

## Out of Scope

- Import from m3u8 (only export m3u8; import is JSON-only)
- Merge duplicate videos across multiple import files
- Real-time playlist sync across devices
- Import from third-party playlist formats (YouTube, etc.)

## Technical Notes

- Check `lib/utils/api/` for existing API call patterns
- Check `file_picker` usage in existing code
- Check `share_plus` usage in existing code
- `dio` is already in pubspec.yaml
- No new dependencies needed
