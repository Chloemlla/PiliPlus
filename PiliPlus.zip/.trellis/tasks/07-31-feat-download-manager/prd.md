# Batch Download Management Panel

## Goal

Give users a unified view and control over all Seal委托 download tasks: see queue status, pause/resume/delete individual tasks or batch-operate on multiple, and retry failed tasks. Currently downloads are managed inside Seal; this adds a read-only monitoring and control surface inside PiliPlus.

## Requirements

### Download queue panel
- Entry: "下载管理" in the settings or Advanced tab
- Show all active download tasks:
  - Task info: video title, quality, format (video/audio), progress %, downloaded size / total size
  - Status: waiting / downloading / paused / completed / failed
  - Source: which page triggered the download (video detail, batch, etc.)
- Color-coded status indicators

### Per-task actions
| Action | Condition |
|--------|-----------|
| Pause | Active or waiting task |
| Resume | Paused task |
| Retry | Failed task |
| Delete | Any task (with confirmation if downloading) |
| Open | Completed task (open in file manager) |
| Share | Completed task |

### Batch operations
- Multi-select mode: long-press to enter, tap to select
- Batch actions: Pause all / Resume all / Delete selected / Retry failed

### Task stats
- Total: N tasks (X completed, Y downloading, Z waiting, W failed)
- Storage used: total downloaded size

### Seal integration
- Query task status via Seal's content provider or broadcast state (same mechanism as status bridge)
- For failed tasks: Seal's failure reason surfaced in the panel
- If Seal is not installed: show "请安装 Seal 以管理下载" with a link to releases

## Technical Approach

### Seal state bridge
- Reuse existing `SealDownloadStatusBridge` from PiliPlus (receives `DOWNLOAD_STATUS` broadcasts)
- Extend bridge to keep a local task list in sync
- Alternatively: query Seal's content provider if available

### Implementation
- `DownloadManagerService` / `DownloadManagerController` in `lib/services/`
- `DownloadManagerPage`: Flutter page with list view and batch controls
- `DownloadTaskCard`: individual task card with status, progress, actions
- Store task list in memory (synced from Seal) + persisted completed task history

### State management
- `RxDart` BehaviorSubject or GetX reactive: `tasks: RxList<DownloadTask>`
- Sync with Seal on app launch, on broadcast receive, and on pull-to-refresh

### Schema
```dart
class DownloadTask {
  String requestId;
  String bvid;
  String title;
  String quality;
  String format; // video / audio
  DownloadStatus status; // waiting/downloading/paused/completed/failed
  double progress; // 0.0 - 1.0
  int downloadedBytes;
  int totalBytes;
  String? errorMessage;
  DateTime createdAt;
  DateTime? completedAt;
}
```

## Acceptance Criteria

- [ ] Download queue shows all Seal tasks with correct status
- [ ] Pause/resume/retry/delete work for individual tasks
- [ ] Open completed task in file manager
- [ ] Share completed task
- [ ] Batch select mode with multi-select
- [ ] Batch pause/resume/delete/retry all work
- [ ] Task stats (counts, storage used) shown
- [ ] Graceful handling when Seal is not installed
- [ ] List refreshes when Seal broadcasts status changes

## Out of Scope

- Initiating new downloads from this panel (keep using video detail page)
- Reordering queue priority (Seal manages queue order)
- Download speed limit controls
- Download scheduling (download at night, etc.)

## Technical Notes

- Check existing `SealDownloadStatusBridge` and `SealDownloadUtils` for current integration
- Check `lib/services/download_service.dart` for existing download patterns
- No new dependencies needed
- Review Seal's third-party call documentation for task control intents
