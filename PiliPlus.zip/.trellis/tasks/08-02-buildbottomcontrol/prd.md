# 修复 buildBottomControl 底部控制条渲染问题

## Goal

修复视频播放器 `buildBottomControl()` 生成的左右控制条在窄屏、全屏、桌面 PIP 与弹出菜单场景下出现的错误缩放、位置错位和坐标变换问题，并补充能验证实际布局结果的 widget 测试。

## Requirements

* `RenderBottomBar` 布局左右两个控制 Row 时，不应因父级 `minWidth` 约束将每个 Row 强制撑满整个播放器宽度。
* 只有左右控制内容总宽度超过可用宽度时才进行整体缩放。
* 缩放绘制时保持 RenderObject 自身在父级中的位置，不重复缩放父级 offset。
* `applyPaintTransform()` 必须表达与实际绘制一致的完整子节点变换，保证全局坐标、Tooltip、PopupMenu 锚点和无障碍坐标正确。
* 保持 `hitTestChildren()` 使用 Flutter 的 paint-transform 逆变换机制，不重复手动求逆。
* `buildBottomControl()` 保持恰好两个 `PlayerBar` 子节点：左侧 Row 与右侧 Row；不改变控制项业务条件和顺序。
* 测试覆盖宽屏不缩放、窄屏缩放以及实际子节点布局/绘制变换的关键结果。

## Acceptance Criteria

* [ ] `RenderBottomBar` 的子 Row 可以按内容宽度布局，不受父级 `minWidth` 错误撑大。
* [ ] 可用宽度足够时，左右 Row 保持原始尺寸，右侧 Row 贴合右边界。
* [ ] 可用宽度不足时，左右 Row 按统一比例缩放，并且 RenderObject 的父级 offset 不被重复缩放。
* [ ] `applyPaintTransform()` 与绘制路径使用一致的变换顺序和完整矩阵。
* [ ] `hitTestChildren()` 在缩放状态下仍能命中对应控制按钮。
* [ ] `flutter analyze lib/common/widgets/player_bar.dart` 无问题。
* [ ] `flutter test test/common/widgets/player_bar_test.dart` 全部通过。
* [ ] 若全量测试受当前 Flutter SDK/仓库既有编译问题阻塞，记录具体错误且不将其归因于本修复。

## Definition of Done

* 代码、测试和必要的测试辅助实现完成。
* 目标文件 analyzer 与相关 widget tests 通过。
* 变更符合现有 Flutter RenderObject 代码风格。
* 验证结果和全量测试阻塞项已记录。

## Technical Approach

* 在 `lib/common/widgets/player_bar.dart` 的 `performLayout()` 中仅放宽两个子 Row 的宽度约束，保留高度约束，避免使用会意外放宽高度的整体 `loosen()`。
* 统一定义/使用缩放矩阵的语义：RenderBottomBar 的局部坐标中，子节点先按 `parentData.offset` 定位，再应用 `_transform`；RenderObject 自身的父级 offset 由 Flutter paint context 单独处理。
* 使用 `pushTransform()` 的官方 offset 语义，避免手工合成出与 `PaintingContext` 坐标约定不一致的矩阵。
* `applyPaintTransform()` 使用 `_transform` 与 child offset 的正确矩阵乘法顺序，而不是只缩放 child offset 的 x 坐标。
* 为测试增加可观察的 RenderObject/子节点几何断言；避免只检查 `takeException()`。

## Decision (ADR-lite)

**Context**: 底部控制条使用自定义 MultiChild RenderObject 在空间不足时缩放左右控制组。此前布局约束只改了 `maxWidth`，而父级常带有 tight `minWidth`；同时子节点坐标变换与绘制变换不一致。

**Decision**: 修复约束、保留 Flutter `pushTransform` 的标准 offset 语义，并使 `applyPaintTransform()` 直接表达完整的 `transform × child translation`。不修改 `buildBottomControl()` 的业务控制项列表。

**Consequences**: 控件将按实际内容宽度参与总宽计算，避免不必要缩放；缩放状态下全局坐标相关能力更准确。自定义 RenderObject 仍要求 `PlayerBar` 有两个子节点，业务调用保持该契约。

## Out of Scope

* 不重构或更换 `PlayerBar` 的自定义 RenderObject 架构。
* 不改变控制项显示条件、业务回调、菜单内容或控制条视觉设计。
* 不修复与本次改动无关的全量测试中已有的 Flutter SDK API 兼容问题。

## Technical Notes

* 主要入口：`lib/plugin/pl_player/view/view.dart:407-1000`。
* 包装组件：`lib/plugin/pl_player/widgets/bottom_control.dart:57-123`。
* RenderObject：`lib/common/widgets/player_bar.dart`。
* 现有测试：`test/common/widgets/player_bar_test.dart`。
* Flutter `PaintingContext.pushTransform()` 的 offset 不应包含在 transform 矩阵中；其内部会按官方语义组合 offset 与 transform。
* 项目当前本地 Flutter 版本与部分仓库 API 存在既有兼容性问题，全量测试需单独记录。
