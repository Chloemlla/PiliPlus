# PiP Persistent Mode

## Goal

Keep video playing in a floating Picture-in-Picture window when the user navigates away from the video page (to comments, dynamics, search, etc.). Currently PiP likely exits when leaving the video page; this change makes it survive navigation within the app.

## Requirements

### Core behavior
- Enter PiP: existing PiP button or auto-enter on app minimize
- Stay in PiP when navigating to: comments, dynamics, search, user profile, favorites, watch history, settings
- Return to full player: tap the PiP window to restore
- Background audio: when PiP is active and screen is off, audio continues playing

### PiP window controls
- Play/pause toggle
- Close PiP
- Swipe to dismiss
- Mini progress bar at the bottom edge

### Exit conditions
- Video ends naturally
- User explicitly closes PiP
- App is killed
- Memory pressure (system reclaims)

### Auto-enter policy
- User can enable "Auto-enter PiP on app minimize" in settings
- When navigating away from video page while playing, optionally prompt to keep in PiP

## Technical Approach

### Flutter / Android
- `android/app/src/main/AndroidManifest.xml`: declare `android:supportsPictureInPicture="true"` and `android:configChanges="orientation|screenSize|smallestScreenSize|screenLayout|keyboard|keyboardHidden|navigation"`
- `MediaSessionService` / `audio_service` already handles background audio — ensure PiP doesn't conflict
- PiP entry via `AppLifecycleListener` or `WidgetsBindingObserver` on `AppLifecycleState.paused`
- On Android, use `PictureInPictureParams` with `autoEnterEnabled=true` where supported
- Navigation observer: when `RouterDelegate` or `Navigator` changes pages, don't stop PiP

### Desktop (Win/Mac/Linux)
- Mini floating window via `window_manager` or platform-native mini player
- Keep `MediaKitPlayer` running in background service/controller

### State persistence
- Store: current video bvid + position when entering PiP
- On restore: seek to stored position

## Acceptance Criteria

- [ ] PiP window stays visible when navigating to comments/dynamics/search
- [ ] Play/pause and close buttons work in PiP window
- [ ] Background audio continues when screen is off
- [ ] Tap PiP returns to full player at correct position
- [ ] PiP exits on video end or explicit close
- [ ] Auto-enter PiP on app minimize (optional setting)
- [ ] Works on Android and desktop platforms

## Out of Scope

- iOS PiP (platform API differs; separate implementation)
- PiP with multiple concurrent videos
- Cross-device PiP continuity

## Technical Notes

- Check `lib/pages/video/` for existing player lifecycle hooks
- Review `audio_service` integration for background audio path
- Android PiP: `Activity.enterPictureInPictureMode()` and `PictureInPictureParams`
- No new dependencies needed
