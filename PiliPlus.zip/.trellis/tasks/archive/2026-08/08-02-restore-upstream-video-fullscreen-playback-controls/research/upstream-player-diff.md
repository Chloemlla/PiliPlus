# Research: Upstream Player and Fullscreen Control Diff

- **Query**: Research the current branch versus `upstream/main` for video playback and fullscreen controls; identify exact behavior/layout regressions and the smallest safe restoration approach.
- **Scope**: Internal
- **Date**: 2026-08-02

## Findings

### Files Found

| File Path | Description |
|---|---|
| `lib/plugin/pl_player/view/view.dart` | Player overlay, bottom-control composition, fullscreen gestures, and control-layer layout. |
| `lib/plugin/pl_player/widgets/bottom_control.dart` | Progress-bar and bottom-control wrapper. |
| `lib/plugin/pl_player/widgets/app_bar_ani.dart` | Top/bottom control slide animation and gradient decoration. |
| `lib/plugin/pl_player/controller.dart` | Playback state, fullscreen transition, orientation, and control-lock behavior. |
| `lib/plugin/pl_player/models/bottom_control_type.dart` | Bottom-control enum; branch adds `more`. |
| `lib/pages/video/widgets/header_control.dart` | Player top bar and existing top `更多设置` sheet. |
| `lib/pages/video/view.dart` | Video detail page hosting player/fullscreen state. |
| `lib/common/widgets/player_bar.dart` | Uncommitted PlayerBar render/layout changes; unrelated and must be preserved. |
| `test/common/widgets/player_bar_test.dart` | Uncommitted PlayerBar tests; unrelated and must be preserved. |

### Code Patterns

#### Baseline and scope

- `upstream/main` is `f9a9e221b08159f08a8a007fb82bd82c6170e5ea`; current HEAD is `43787d6af88cf8254b4f396102f31ce64ab84140`.
- The branch contains substantial independent player-adjacent features (watch statistics, persistent PiP, quality recommendation, stream retry/error handling, long-press speed formulas, downloads/export, and API/path synchronization). Whole-file upstream checkout would remove unrelated functionality and is not safe.
- Current uncommitted changes are only `lib/common/widgets/player_bar.dart` and `test/common/widgets/player_bar_test.dart`; neither was changed.

#### Exact bottom-control/layout divergence

- Upstream `lib/plugin/pl_player/view/view.dart:401-402` uses `widgetWidth = isLandscape && isFullScreen ? 42 : 35`; controls use height `30`.
- Current `view.dart:417-422` adds mobile-specific geometry: widths `48/40`, height `36`, and icon size `24` versus upstream `35/42`, height `30`, and icon size `22`. This changes both video-detail and fullscreen bottom-control footprint.
- Current `view.dart:909-922` and `lib/plugin/pl_player/models/bottom_control_type.dart:15` add `BottomControlType.more`. Current right-side order at `view.dart:975-986` appends `.more` after `.fullscreen`; upstream ends at `.fullscreen` and has no bottom-bar more button.
- Current `view.dart:924-1051` implements a bottom “更多” popup whose only item is the branch bookmark action (`value: 'bookmark'`, lines 933-943). The bookmark capability should remain, but the new bottom control changes the upstream default layout.
- Upstream `lib/plugin/pl_player/widgets/bottom_control.dart:57` uses bottom padding `12`; current line 57 uses `6`, moving the controls/progress assembly vertically.
- Upstream `lib/plugin/pl_player/widgets/app_bar_ani.dart:25-48` has a strong top gradient (`0xBF000000`) and a bottom gradient. Current branch weakens the top gradient to `0x66000000` and removes `_bottomDecoration`, changing bottom-control visual separation.

#### Exact fullscreen/gesture divergence

- Upstream `view.dart:1354-1386` registers long press for every eligible non-live pointer after lock checks. Current branch adds `_isLongPressSpeedArea` and registers long press only for `event.localPosition.dx >= maxWidth / 2` (`view.dart:1354`, `1375-1399`). This changes the gesture hit area and is separate from the fullscreen transition.
- Current `view.dart:1489-1493` adds `QualityChipOverlay`, and `view.dart:1563-1593` adds a keyboard speed toast; these are overlay additions, not changes to the fullscreen trigger.
- Current `lib/plugin/pl_player/controller.dart:1513-1555` retains upstream fullscreen sequencing: desktop-PiP guard, `_fsProcessing` serialization, mobile system-bar/orientation changes, desktop enter/exit, and `_setFullScreen` in `finally`.
- Current controller dispose additions around `1657-1727` (`_isDetached`, watch/PiP cleanup) are independent and should not be reverted.
- Current player layer `view.dart:1750-1788` still uses `AppBarAni` for header/bottom controls and the same `BottomControl` composition. The principal fullscreen UI regression is changed child geometry/order and removed bottom decoration, not replacement of fullscreen transition machinery.

#### Top `更多设置` location

- Existing top menu is `HeaderControlState.showSettingSheet` at `lib/pages/video/widgets/header_control.dart:369` onward. Its button is around lines `2240-2252`, tooltip `更多设置`, callback `showSettingSheet`, icon `Icons.more_vert_outlined`.
- Current top sheet does not contain video bookmarks. Bookmark access exists only in the new bottom `BottomControlType.more` popup (`view.dart:925-960`). The relocation seam is to preserve bookmark sheet/service/pages and invoke it from the existing top menu, while removing it from the default bottom bar.

#### Relevant branch commits

- `8be0fee37` changed player controls and bottom-control padding as part of broader app changes.
- `6a9fd2af8` introduced the bookmark button in the player more menu, adding `BottomControlType.more` and bookmark-sheet logic.
- `18f6fe414` added player/lifecycle stability changes; do not wholesale revert its independent behavior.
- `7fd3110fc` removed the bottom gradient overlay from `AppBarAni`.
- `9ce5a18de`, `ae6f4acff`, and `6012434ad` concern `PlayerBar` rendering/layout and are represented by current uncommitted PlayerBar changes; preserve them.

### Smallest Safe Restoration Boundary

1. `lib/plugin/pl_player/view/view.dart`: restore upstream default control geometry, remove `.more` from the default right-side list and its bottom-popup/type rendering, while preserving bookmark implementation for reuse from the top menu. Keep unrelated overlay, lifecycle, stream, PiP, quality, and speed additions.
2. `lib/plugin/pl_player/models/bottom_control_type.dart`: remove only branch-only `more` if the bottom popup is removed.
3. `lib/plugin/pl_player/widgets/bottom_control.dart`: restore bottom padding `12`.
4. `lib/plugin/pl_player/widgets/app_bar_ani.dart`: restore upstream top-gradient strength and bottom gradient.
5. `lib/pages/video/widgets/header_control.dart`: add bookmark invocation to existing `showSettingSheet`, using current timestamp and existing metadata/sheet/service path.

`lib/plugin/pl_player/controller.dart` should not be wholesale reverted: its `triggerFullScreen` remains structurally upstream-compatible, while controller changes are independent playback/lifecycle functionality.

### Related Specs

- `.trellis/spec/frontend/flutter-player-lifecycle-stability.md` — constrained player controls, intrinsic PlayerBar layout, and CI-only Flutter/test execution.
- `.trellis/spec/frontend/index.md` — frontend checklist linking player layout/lifecycle stability and CI authority.
- `.trellis/tasks/08-02-restore-upstream-video-fullscreen-playback-controls/prd.md` — task requirements for upstream default controls/fullscreen behavior, top-menu access for branch features, and preserving PlayerBar edits.

### External References

- None; this is an internal Git comparison against the checked-out `upstream/main` ref.

## Caveats / Not Found

- No local Flutter/analyzer/test commands were run because repository instructions forbid local Flutter/Gradle execution; verification must occur in GitHub Actions.
- The top menu already contains many expanded settings. The bookmark action is the clearly player-specific branch feature currently exposed only by the new bottom menu; other relocation decisions require implementation review.
- Import-case and unrelated feature changes make whole-file upstream replacement unsafe.
