# Research: Player feature inventory versus upstream/main

- **Query**: Inventory features added on this branch to the video player compared with upstream/main, especially controls/buttons/menu items and top/header more menus. Determine which new features must remain available and how to place them under the top More settings without changing upstream default controls.
- **Scope**: Internal
- **Date**: 2026-08-02

## Findings

### Files Found

| File Path | Description |
|---|---|
| `lib/plugin/pl_player/view/view.dart` | Player bottom-control construction, fullscreen control, branch-only bookmark/quality UI, gesture and in-player overlays. |
| `lib/plugin/pl_player/models/bottom_control_type.dart` | Branch adds the `.more` bottom-control enum value. |
| `lib/plugin/pl_player/widgets/bottom_control.dart` | Bottom control container/padding and progress-bar composition. |
| `lib/plugin/pl_player/widgets/app_bar_ani.dart` | Top/bottom animated control decoration; branch changes top opacity and removes bottom gradient. |
| `lib/pages/video/widgets/header_control.dart` | Top/header controls and the existing `showSettingSheet` “更多设置” menu. |
| `lib/pages/video/controller.dart` | Quality recommendation state/application and in-app mini-player entry point. |
| `lib/plugin/pl_player/controller.dart` | Branch playback additions including long-press-speed formula, keyboard speed toast, persistent PiP/watch-session behavior, and fullscreen integration. |
| `lib/pages/video/bookmark/video_bookmark_sheet.dart` | Branch video-bookmark sheet used by the player More menu. |
| `lib/pages/video/quality/quality_widgets.dart` | Branch quality recommendation indicator/selector used by the quality popup and in-player overlay. |
| `lib/common/widgets/in_app_mini_player.dart` | Branch in-app mini-player implementation exposed by the header. |
| `lib/services/pip_persistent_service.dart` | Branch persistent PiP state used by the player controller. |
| `lib/services/watch_stats_service.dart` | Branch watch-session/statistics persistence used by the player controller. |

### Upstream default bottom controls

`upstream/main:lib/plugin/pl_player/view/view.dart:391-927` builds the baseline bottom bar with a left group of play/pause, time, and conditional previous/next, and a right group of conditional danmaku chart, super-resolution, view points, episode, fit, AI translation, subtitles, speed, quality, and fullscreen. The baseline right-group order is visible at upstream lines 902-915:

```dart
if (isNotFileSource && plPlayerController.showDmChart) .dmChart,
if (plPlayerController.isAnim) .superResolution,
if (isNotFileSource && plPlayerController.showViewPoints) .viewPoints,
if (isNotFileSource && anySeason) .episode,
if (flag) .fit,
if (isNotFileSource) .aiTranslate,
.subtitle,
.speed,
if (isNotFileSource && flag) .qa,
if (!plPlayerController.isDesktopPip) .fullscreen,
```

The branch appends `.more` at `lib/plugin/pl_player/view/view.dart:975-986`, and therefore changes the default bottom layout by adding a visible ellipsis control after fullscreen. The branch-only `.more` enum is at `lib/plugin/pl_player/models/bottom_control_type.dart:16` and its popup currently only exposes `视频标记` at `view.dart:924-961`.

The branch also changes mobile bottom-control dimensions from upstream’s fixed width/height/icon sizes (`view.dart` upstream lines 402, 415-884) to mobile width 40/48, height 36, and icon size 24 at `view.dart:418-422`; desktop retains upstream 35/42 width but shares the new variables. These are layout changes, not additional retained features, and are part of the default-control divergence.

### Branch-only player controls/features that must remain available

1. **Video bookmarks / timestamps**
   - Introduced by branch commit `8d32a17a9 feat(bookmarks): add video bookmarks and timestamps`; moved into the player popup by `6a9fd2af8 feat: move video bookmark button to player more menu`.
   - The player imports `VideoBookmarkSheet` at `view.dart:33`, defines `_showBookmarkSheet` at `view.dart:1006-1022`, derives title/author metadata at `view.dart:1025-1049`, and seeks to a selected timestamp through `plPlayerController.seekTo`.
   - Current bottom popup entry is `视频标记` at `view.dart:933-949`, conditional for non-file/non-desktop-PiP playback.
   - Retention location: keep as a child of the top/header `showSettingSheet` More menu, not as a new bottom-bar button. The underlying bookmark pages/sheet remain available; only the player entry point moves.

2. **Quality recommendation mode and in-player quality indicator**
   - `VideoDetailController` owns `qualityRecommendationController` at `lib/pages/video/controller.dart:121-123,383-384`; quality application is `_applyRecommendedQuality` at `controller.dart:702` and available/current qualities are updated around `controller.dart:984-1030`.
   - The branch quality popup adds a `QualityModeIndicator` action and `showQualityModeSelector` at `view.dart:834-875`, replacing the upstream `PopupMenuButton<int>` callback arrangement with `PopupMenuButton<Object>`; the actual quality choices remain in the same popup at `view.dart:877-905`.
   - `QualityChipOverlay` is rendered over non-live video at `view.dart:1486-1494`.
   - Retention location: preserve quality recommendation state and application. The quality recommendation mode selector and any quality-management entry should be reachable from the top/header More settings. Do not leave a new bottom control beyond upstream’s existing conditional `.qa`; the upstream quality button/order remains the default. The branch quality-choice behavior can remain behind the existing upstream quality control if implementation needs it, while recommendation mode is exposed from More.

3. **Formula-configurable long-press speed and keyboard speed feedback**
   - Controller fields/methods are at `lib/plugin/pl_player/controller.dart:116-124` (`keyboardSpeedToast`), `:186-195` (`longPressTargetSpeed`/text), and `:347-351` (`LongPressSpeedFormula` preferences). The branch adds `models/long_press_speed_formula.dart`.
   - Player gestures restrict long-press speed recognition to the right half via `_isLongPressSpeedArea` and pointer registration at `view.dart:1351-1399`; the displayed target now uses `longPressTargetSpeedText` at `view.dart:1546-1550`.
   - The keyboard Z/X/C speed toast is rendered at `view.dart:1560-1590` and is a transient playback overlay rather than a button/menu item.
   - Retention location: retain the controller behavior, formula setting, and transient toast; these should not become bottom-bar controls. Any user-facing configuration belongs in the top/header More settings (or the existing player settings sheet reached by its More button). The actual default bottom controls stay upstream.

4. **Persistent PiP and watch-session/statistics support**
   - `PlPlayerController` uses `PipPersistentService` and `WatchSessionTracker` at `controller.dart:35-36,166-169`; PiP restoration/persistence is initialized around `controller.dart:656-662`, and persisted/cleared around `controller.dart:1936-1966`.
   - The branch also adds desktop PiP and related controller operations at `controller.dart:228-323`, plus watch-session persistence around `controller.dart:1871-1927`.
   - The top header’s existing PiP entry remains at `header_control.dart:2216-2238`; desktop PiP and Android PiP are conditional there. These capabilities are not part of upstream’s bottom-right default control list.
   - Retention location: retain existing PiP behavior and persistence. Keep PiP entry in the top/header controls/More settings as appropriate; do not add PiP to the bottom control bar. The upstream bottom bar still suppresses fullscreen in desktop PiP through its existing condition.

5. **In-app mini-player button**
   - `VideoDetailController.openInAppMiniPlayer` is at `lib/pages/video/controller.dart:815`; implementation is in `lib/common/widgets/in_app_mini_player.dart`.
   - Branch adds the top/header button at `lib/pages/video/widgets/header_control.dart:2199-2215`, tooltip `应用内小窗`, calling `videoDetailCtr.openInAppMiniPlayer(...)`. It is absent from `upstream/main` at the corresponding header region.
   - Retention location: keep this as a top/header action, preferably grouped with the header More settings if the goal is one More entry for branch additions; it must not enter the bottom playback control list.

6. **Header menu additions and settings capability**
   - Compared with upstream, branch `showSettingSheet` adds/retains a broad set of player actions in `header_control.dart:368-698` and the parallel branch path at `:709-934`: video/audio download, Android “download and remove sponsor marks,” save cover, shutdown timer, playback URL/reload, super-resolution, player volume, CDN, flip X/Y, audio-only, background playback, video/audio quality, decode format, repeat mode, subtitle loading/saving, and player info.
   - The branch’s existing top More button is `header_control.dart:2240-2252`, tooltip `更多设置`, calling `showSettingSheet`; this is the authoritative top More menu to retain/extend. Upstream already has a header More button at the same role (`upstream/main:lib/pages/video/widgets/header_control.dart:2002-2015`), so expanding this sheet does not alter upstream bottom controls.
   - The branch adds a shutdown timer display to `TimeBatteryMixin` at `header_control.dart:145-184`; this is header status information, not a bottom control.

### Header controls that are upstream or branch layout changes

- Upstream header controls include back, home (when applicable), desktop always-on-top, audio page/cast, sponsor-block actions, danmaku send/toggle/settings, PiP, and More; see `upstream/main:lib/pages/video/widgets/header_control.dart:1951-2015`.
- Branch adds the in-app mini-player button at `header_control.dart:2199-2215`. Other header differences in the branch are primarily formatting, expanded settings-sheet content, timer display, and platform/API adaptations; they do not identify additional new bottom controls.
- `lib/plugin/pl_player/widgets/app_bar_ani.dart:24-40` changes the top gradient opacity and removes the bottom gradient. This is rendering/layout behavior, not a feature requiring a menu entry. The branch commits `7fd3110fc` and `9ce5a18de` specifically concern player rendering/PlayerBar fixes; preserve unrelated working-tree `lib/common/widgets/player_bar.dart` and its test as the task PRD states.

### Placement map for implementation

| Branch feature | Keep available through | Must stay out of upstream default bottom bar |
|---|---|---|
| Video bookmarks/timestamps | Header More (`showSettingSheet`) item opening `VideoBookmarkSheet` | Yes |
| Quality recommendation mode | Header More item opening selector; retain existing upstream quality control for actual quality choice | Yes, except upstream `.qa` |
| Long-press speed formula/configuration | Header More/player settings; gesture remains in player surface | Yes |
| Keyboard speed toast | Automatic player overlay after keyboard action | Yes |
| Persistent Android/desktop PiP | Existing header PiP/More actions and controller persistence | Yes |
| In-app mini-player | Existing header action or header More | Yes |
| Download/export, audio-only, background playback, CDN, decode, repeat, subtitle tools, timer, flip, player volume | Existing header `showSettingSheet` More menu | Yes |

### Related Specs

- `.trellis/tasks/08-02-restore-upstream-video-fullscreen-playback-controls/prd.md` — task goal explicitly requires upstream default video/fullscreen controls while retaining branch features under top More; also records the pre-existing `PlayerBar` working-tree modifications that must not be overwritten.
- `.trellis/spec/frontend/quality-guidelines.md` — frontend quality/checking guidance relevant to the eventual implementation.
- `.trellis/spec/frontend/component-guidelines.md` — frontend component conventions.
- `.trellis/spec/frontend/flutter-player-lifecycle-stability.md` — player lifecycle behavior relevant to retaining PiP/fullscreen integrations.
- `.trellis/spec/frontend/flutter-watch-stats-pip.md` — existing PiP/watch-stat behavior context.

## Caveats / Not Found

- The branch contains a very large upstream-sync/import-casing diff. Inventory above excludes import casing and formatting-only changes.
- No separate top-level “More” widget exists in the player plugin; the top/header More entry is `HeaderControlState.showSettingSheet` and its `Icons.more_vert_outlined` button. The bottom `.more` popup is branch-only and currently only contains bookmarks.
- The task’s phrase “top More settings” is interpreted as the header `更多设置` action, consistent with `prd.md:16`; no production code was modified.
