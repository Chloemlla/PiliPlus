# restore upstream video fullscreen playback controls

## Goal

将视频详情页进入播放后的播放器控件，以及全屏播放交互完全恢复到 `upstream/main`（对应用户指定的 `bggRGjQaUbCoE/PiliPlus`）；本分支新增的播放器相关功能继续保留，但统一收纳到顶部“更多”设置入口，避免改变上游默认播放布局与全屏操作习惯。

## What I already know

* 用户要求：视频播放全屏播放和点入播放的视频播放控件完全回退到上游；本分支新功能移入顶部更多设置。
* 当前仓库远端 `upstream` 指向 `https://github.com/bggRGjQaUbCoE/PiliPlus.git`，已获取 `upstream/main`。
* 播放器主实现位于 `lib/plugin/pl_player/view/view.dart`、`lib/plugin/pl_player/widgets/bottom_control.dart`、`lib/plugin/pl_player/controller.dart`；播放器承载页还涉及 `lib/pages/video/widgets/header_control.dart`。
* 当前工作区已有用户未提交修改：`lib/common/widgets/player_bar.dart` 与 `test/common/widgets/player_bar_test.dart`，本任务不应覆盖或回退它们。
* 本分支已有播放器新增功能痕迹，包括视频书签入口（提交 `6a9fd2af8`）以及若干播放器/设置相关扩展；需要逐项与上游差异核对后重新放入顶部更多菜单。

## Assumptions (temporary)

* “顶部的更多设置”指播放器全屏/顶部控制层中的更多菜单，而不是应用全局设置页面。
* “完全回退”优先以 `upstream/main` 当前代码和布局为行为基线，不删除本分支底层能力、设置项或数据模型，除非它们只服务于非上游播放器交互。
* 当前已有的 `PlayerBar` 工作区改动属于独立任务，保留原样并单独验证。

## Open Questions

* None blocking. The confirmed implementation boundary is the smallest safe upstream-alignment patch described in the research notes.

## Requirements (evolving)

* 视频详情页点入播放时，默认控制条布局、按钮顺序、显示/隐藏行为与上游一致。
* 全屏进入、退出、手势/方向及全屏控制层行为与上游一致。
* 本分支新增且仍需保留的播放器功能不出现在上游默认控制条布局中，统一从顶部更多菜单访问。
* 不影响本分支其他非播放器功能。
* 不覆盖当前工作区已有的 `PlayerBar` 与其测试修改。

## Acceptance Criteria (evolving)

* [ ] `view.dart` 及相关播放器控件的默认行为与 `upstream/main` 对齐。
* [ ] 分支新增播放器功能仍可从顶部更多菜单访问，且不挤占上游默认按钮布局。
* [ ] 全屏进入/退出及视频详情页初始播放控件通过静态检查和测试验证。
* [ ] 现有 `PlayerBar` 未提交改动保持不变并通过原有测试。
* [ ] `flutter analyze`（至少目标文件）和相关测试通过，或明确记录环境限制。

## Definition of Done (team quality bar)

* Tests added/updated where behavior is testable.
* Lint / typecheck / relevant tests green.
* Behavior-changing implementation notes updated if needed.
* Existing unrelated working-tree changes preserved.

## Out of Scope (explicit)

* 不回退本分支其他页面、下载、设置、账号或数据功能。
* 不删除本分支新增播放器功能的底层实现或持久化设置，仅调整播放器入口与默认布局。
* 不修改 `PlayerBar` 当前独立的未提交渲染修复。

## Technical Approach

Apply the smallest safe upstream-alignment patch rather than replacing whole files:

* `lib/plugin/pl_player/view/view.dart`: restore upstream default control geometry, remove the branch-only bottom `.more` entry from the default right-side list, and preserve branch-only overlays and controller behavior.
* `lib/plugin/pl_player/models/bottom_control_type.dart`: remove only the branch-only `more` enum value if no bottom popup remains.
* `lib/plugin/pl_player/widgets/bottom_control.dart`: restore upstream bottom padding.
* `lib/plugin/pl_player/widgets/app_bar_ani.dart`: restore upstream top-gradient strength and bottom gradient.
* `lib/pages/video/widgets/header_control.dart`: expose the existing bookmark sheet through the existing top `更多设置` menu, keeping the underlying bookmark capability intact.
* Do not wholesale revert `controller.dart`; its fullscreen sequencing is already upstream-compatible and its PiP/watch/quality/speed additions are independent.
* Preserve the unrelated uncommitted `PlayerBar` and test changes exactly as found.

## Decision (ADR-lite)

**Context**: The branch mixed upstream player behavior with many independent features. Whole-file rollback would remove useful branch functionality and risk lifecycle regressions.

**Decision**: Restore only the verified upstream control geometry, bottom menu composition, bottom decoration, and relocate the bookmark entry to the existing header More menu. Keep independent controller and overlay features.

**Consequences**: Default video and fullscreen controls regain upstream dimensions/order and visual treatment; branch features remain available without occupying the default bottom bar. The patch is narrow and reviewable, but the header More menu grows and should be verified for overflow/availability.

## Technical Notes

* Upstream comparison baseline: `upstream/main`.
* Research: [`research/upstream-player-diff.md`](research/upstream-player-diff.md) — exact geometry, menu, decoration, and safe restoration boundary.
* Research: [`research/player-feature-inventory.md`](research/player-feature-inventory.md) — branch-only feature inventory and retention map.
* Relevant branch commits include `6a9fd2af8 fix: move video bookmark button to player more menu` and later player rendering fixes; all relevant file-level differences are classified rather than blindly reverting whole files.
* Repository guidance forbids local Flutter/Gradle builds; use static inspection and CI-authoritative verification.
