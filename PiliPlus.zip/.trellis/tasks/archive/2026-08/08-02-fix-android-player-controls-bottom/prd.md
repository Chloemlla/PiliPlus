# 修复 Android 视频播放控件底部显示异常

## Goal

修复 Android 窄屏或非全屏播放器中底部播放控件无法完整显示、右侧控件溢出或被截断的问题，同时修复用户提供的三类 Android 致命崩溃，并保持桌面端和宽屏布局稳定。

## What I already know

- 用户报告 Android 下视频播放控件底部显示异常。
- `8be0fee37` 将底部控件布局从会整体缩放的 `PlayerBar` 改成 `Row + Spacer + SingleChildScrollView`，并增大了移动端控件尺寸。
- 当前横向 `SingleChildScrollView` 是 `Row` 的非弹性子节点，没有被限制为“左侧控件之后的剩余宽度”。在窄屏下它会按右侧全部控件的固有宽度参与布局，可能造成 Row 溢出或右侧控件被裁切，而不是在剩余空间内滚动。
- `AppBarAni` 目前仅处理左右安全区，不处理底部 inset；但全屏 Android 会隐藏系统栏，目前没有日志或代码证据表明这次问题一定由系统导航栏遮挡引起。
- 用户确认实际症状是右侧按钮横向截断/溢出，整条底部控制栏被挤到接近上方功能区的位置，并在右下角出现灰色正方形渲染异常。
- 崩溃报告 `bedb2a950d3e`：Dio `RequestInterceptorHandler.reject` 在 handler 已完成后再次调用，启动后约 200ms 发生。
- 崩溃报告 `ec06383840f3`：HTTP/2 `FrameWriter.writeGoawayFrame` 在字节流已关闭后继续 `add`，启动后约 270ms 发生。
- 崩溃报告 `8caff7d21a23`：Android 输入分发超时；主线程阻塞在 `MediaKitEventLoopHandler::Dispose` 的线程 `join`，同时 NativeMediaService 正以约 2 秒间隔刷新。

## Confirmed Technical Direction

- 灰色正方形与错误高度按同一底部 Row 约束溢出修复；当前没有独立 GPU 故障证据。
- 底栏复用独立 `PlayerBar`：左侧固定，右侧 `Expanded` 后横向反向滚动，不缩小触控目标。
- Dio 所有异步 handler 路径使用单一 Future 成功/失败分支，禁止完成 handler 后再由宽泛 `catchError` 二次处理。
- HTTP/2 网络切换先安装新池，再以非强制方式排空旧池；仅精确过滤第三方 GOAWAY 写入已关闭 writer 的终止竞态。
- Android media_kit 在锁定依赖上通过 CI pinned patch 使用 isolate event loop，绕过 UI 线程同步 native `join`；不在本次热修中整体升级依赖。
- NativeMediaService 对已存在的 service 只直接刷新一次，不再同时排队额外的 start intent。

## Open Questions

- 无阻塞问题；用户已要求四类问题同时修复。

## Requirements (evolving)

- 左侧播放、时间等核心控件保持可见。
- 右侧控件只使用剩余宽度；内容过多时可横向滚动，默认显示最右端的全屏/更多等高频控件。
- 不恢复整体缩放方案，避免移动端触控目标被缩小。
- 不改变控制按钮行为、排序、弹出菜单或全屏逻辑。
- 修复 Dio 拦截器路径，保证每个 handler 只完成一次，异步分支不会在 `next/resolve/reject` 后继续落入第二次处理。
- 修复或隔离 HTTP/2 关闭竞态，连接关闭后不得再发送 GOAWAY/数据帧，且不把包内部关闭噪声升级为应用致命崩溃。
- 避免在 Android UI 主线程同步等待 media_kit 原生事件线程退出；播放器释放和 NativeMediaService 刷新必须避免形成输入阻塞。
- 对预期的第三方异步关闭竞态进行精确分类时，不得吞掉无关应用异常。

## Acceptance Criteria (evolving)

- [ ] Android 窄屏非全屏时底部控制栏不发生横向 overflow，右侧控件可滚动访问。
- [ ] 左侧播放和时间控件不会被右侧控件挤出。
- [ ] Android 全屏横屏和桌面宽屏仍保持左右控件分组布局。
- [ ] 右下角灰色方块和控制栏异常高度不再出现。
- [ ] 所有 Dio interceptor handler 路径最多完成一次。
- [ ] HTTP/2 已关闭写入竞态不再作为未捕获致命异常进入崩溃历史。
- [ ] media_kit 释放不会在 Android 主线程阻塞超过输入超时阈值；高频媒体通知刷新不放大释放竞态。
- [ ] 相关 widget/policy 测试覆盖窄宽度与宽宽度布局约束。
- [ ] 针对崩溃分类/释放策略增加可静态验证的 focused tests。
- [ ] `WhatsNewData.pages` 包含本次修复说明。
- [ ] GitHub Actions 全绿；本地不运行 Flutter、Gradle 或完整测试。

## Definition of Done

- 修复代码、回归测试和本次更新说明已提交并推送。
- GitHub Actions 对最新提交验证成功。
- 未引入新的 overflow、触控目标缩小或安全区回归。

## Out of Scope

- 重新设计整套播放器控制栏视觉样式。
- 改变用户自定义底部控件配置或按钮顺序。
- 与本问题无关的播放器手势、画质、书签或弹幕功能调整。
- 升级或重写整个 Dio、HTTP/2、gRPC 或 media_kit 技术栈，除非当前锁定依赖已知必须升级才能修复。

## Technical Notes

- 主要文件：`lib/plugin/pl_player/view/view.dart`、`lib/plugin/pl_player/widgets/bottom_control.dart`。
- 回归提交：`8be0fee3798f83874e186b6209ae135d76858e87`。
- 旧实现：`PlayerBar` 在总宽度超限时整体缩放；新实现意图保留触控尺寸并让右侧滚动，但缺少剩余宽度约束。
- 依赖热修复使用 `lib/scripts/patch.ps1` 既有的 post-`pub get` pinned patch 机制，并严格校验 media_kit 锁定 revision。
- 详细取舍与验证方案见同目录 `info.md` 和 `research/*.md`。
- Android/Flutter/Gradle 验证只能在 GitHub Actions 中运行。
- 用户报告路径：`D:/Downloads/pili_plus_crash_report_1785281764239.txt`、`1785387536048.txt`、`1785555246226.txt`。
