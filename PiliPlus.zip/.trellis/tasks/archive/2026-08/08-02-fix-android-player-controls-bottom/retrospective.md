# Bug Analysis: Android player layout and lifecycle repair

## 1. Root Cause Category

- **Category**: E - Implicit Assumption
- **Specific Cause**: the trailing horizontal scroll view was allowed to
  participate in a `Row` at intrinsic width instead of receiving only the
  remaining width. The same repair also exposed undocumented async ownership
  assumptions in Dio handlers, HTTP/2 shutdown, and Android media disposal.
- **Secondary categories**: C - Change Propagation Failure, because the new
  HTTP lifecycle helper was not added to the exact transport boundary
  allowlist; D - Test Coverage Gap, because analyzer-only test issues reached
  the first two CI runs.

## 2. Why Fixes Failed

1. The first implementation fixed the runtime roots, but omitted the new Dart
   module from `tool/check_import_boundaries.py`; the quality job rejected the
   intentional dependency.
2. The boundary follow-up still contained a missing const constructor and an
   assumed Dio header constant in focused tests; Actions correctly rejected
   both analyzer issues.
3. After fixing each independent root cause, the next workflow passed quality,
   Android patching, baseline profile generation, APK release, and uploads.

## 3. Prevention Mechanisms

| Priority | Mechanism | Specific Action | Status |
|---|---|---|---|
| P0 | Test coverage | Keep narrow/wide layout, handler ownership, adapter ordering, crash filter, and patch validation tests | DONE |
| P0 | Documentation | Keep the player layout/lifecycle contract in `flutter-player-lifecycle-stability.md` | DONE |
| P0 | Static pre-push | Run CI-invoked non-Flutter boundary scripts and inspect exact allowlists for new Dart modules | DONE |
| P1 | Code review | Verify dependency symbols and analyzer-only const/import details in new tests before push | DONE |
| P1 | CI completion | Treat quality success as intermediate until the dependent Android job and artifacts are green | DONE |

## 4. Systematic Expansion

- **Similar Issues**: new modules imported by `http/init.dart`, accounts,
  storage, or other ownership-heavy entry points can require exact boundary
  classifier updates.
- **Design Improvement**: isolate lifecycle ordering in small helpers with
  focused policy tests instead of embedding it in large controllers.
- **Process Improvement**: pair each new source file with a search of
  workflow-invoked static classifiers; verify the complete workflow DAG rather
  than stopping after the quality job.

## 5. Knowledge Capture

- [x] Added the executable player layout/lifecycle spec and frontend index link.
- [x] Added CI static pre-push and dependent-job completion guards to the local
  Trellis spec and tracked documentation.
- [x] Added focused regression tests and confirmed the full GitHub Actions run
  `30727139256` succeeded.
