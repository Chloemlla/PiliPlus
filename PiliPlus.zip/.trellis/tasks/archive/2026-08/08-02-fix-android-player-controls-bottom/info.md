# Technical Design: Android player controls and lifecycle stability

## Scope

This task fixes one visible layout regression and three independent lifecycle
failures reported from Android:

1. constrained bottom-control layout;
2. single-completion Dio interceptors;
3. graceful HTTP/2 pool replacement plus precise terminal-close filtering;
4. non-blocking media_kit disposal on Android.

## Decision 1: reusable constrained PlayerBar

Replace the unused scaling render-object implementation in
`lib/common/widgets/player_bar.dart` with a small widget that accepts explicit
leading and trailing groups. The leading group keeps intrinsic width. The
trailing group is the sole `Expanded` child and owns a reversed horizontal
`SingleChildScrollView`.

This preserves mobile touch targets, shows the rightmost high-priority actions
by default, and keeps the desktop/wide-screen left/right grouping. The large
player view only assembles controls and delegates layout to `PlayerBar`.

Rejected alternatives:

- restoring scale-to-fit, because it shrinks touch targets;
- calculating widths manually, because Flutter flex constraints already model
  the required remaining-width contract;
- adding safe-area changes without evidence that system insets caused the
  reported overflow.

## Decision 2: one Future outcome owns one Dio handler completion

Every asynchronous interceptor path that completes a Dio handler will use the
two-callback form of `Future.then(success, onError: failure)`. No broad
`catchError` or `whenComplete` may sit downstream of a callback that has already
called `next`, `resolve`, or `reject`.

Cookie persistence remains secondary to a valid response. A response is
forwarded once even when saving cookies fails; request/error paths wrap the
source Future error and complete the handler once.

## Decision 3: install new pools before gracefully draining old pools

Network-context reset snapshots the old HTTP/2 manager and HTTP/1.1 fallback,
installs the replacement references first, updates the auxiliary HTTP/1.1 Dio,
then closes old resources with `force: false`.

The known `http2` terminal GOAWAY-after-writer-close race is also classified at
the crash boundary, but only when the error type, exact message, and third-party
stack frames all match. Generic `Cannot add event after closing` failures and
Dio duplicate-handler failures remain reportable. Root-zone and platform error
handlers must consult the same precise filter before fatal persistence.

Rejected alternatives:

- force-closing the active transport during a network swap;
- ignoring all closed-stream StateErrors;
- upgrading the complete Dio/http2 stack without an upstream fix specific to
  this race.

## Decision 4: Android media_kit uses the isolate event loop

The pinned media_kit revision synchronously joins a native event-loop thread
from `Initializer.dispose`, which is proven in the ANR main-thread stack. The
Android native artifact is prebuilt, so editing C++ in the dependency checkout
would not change the shipped `.so` without a separate artifact release.

Use the repository's existing post-`pub get` pinned-patch mechanism to patch
`package:media_kit` at the exact locked revision. Android creation and disposal
select `InitializerIsolate`; other platforms retain the current native-first
fallback. The existing isolate disposer is asynchronous and bounds its worker
cleanup, removing `std::thread::join` from the Android UI isolate.

The patch script must validate package identity, resolved checkout, pinned HEAD,
clean/applicable patch state, and the resulting Android backend markers. No
pubspec or lockfile upgrade is required.

`NativeMediaService.startOrUpdate` refreshes an existing service directly and
returns; it starts a foreground service only when no instance exists. This
removes duplicate refreshes but is a mitigation, not the ANR root fix.

Rejected alternatives:

- delaying or merely marking `Player.dispose` unawaited, because its later FFI
  continuation still runs on the UI isolate;
- detaching the C++ join without a proven handle-lifetime protocol;
- wholesale media_kit upgrade across the fork's large API/native delta.

## Validation

- focused narrow/wide `PlayerBar` widget tests;
- interceptor retry/cookie tests and zone-error assertions where practical;
- adapter replacement policy tests or an extracted test seam;
- exact HTTP/2 crash-filter positive and negative tests;
- the dependency patch script verifies the resolved pinned media_kit source;
- GitHub Actions is the only Flutter/Gradle/analyzer/test authority.

