# Research: Android player bottom-control layout regression

- Query: Inspect the Android player bottom-control regression introduced by `8be0fee37`, current `PlayerBar`/bottom-control code, and available widget tests; recommend the smallest robust layout and test change that preserves the left controls while constraining and scrolling the right controls.
- Scope: internal, with Flutter framework source used to confirm layout semantics
- Date: 2026-08-02
- Snapshot: local `main` ref `6947dfe0db7992f402c421c113c72e5b3b862ca2`

## Findings

### Files found

- `.trellis/tasks/08-02-fix-android-player-controls-bottom/prd.md` — requires the left play/time group to remain visible, the right group to use only remaining width, and narrow/wide widget coverage.
- `lib/plugin/pl_player/view/view.dart` — builds the actual left/right control groups and currently places an unconstrained horizontal scroll view in the outer `Row`.
- `lib/plugin/pl_player/widgets/bottom_control.dart` — gives `buildBottomControl()` the full available bar width through `Expanded`; the bad constraint is therefore introduced inside `buildBottomControl`, not by this wrapper.
- `lib/common/widgets/player_bar.dart` — old two-group custom render object that scaled the complete bar when content was too wide; it is currently unused and has no test coverage.
- `lib/plugin/pl_player/widgets/play_pause_btn.dart` — the leading play control has a fixed `42 x 34` layout target.
- `lib/plugin/pl_player/view/widgets.dart` — `_VideoTime` sizes itself from the duration paragraph's intrinsic width and is part of the fixed leading group.
- `test/common/widgets/dynamic_color_illustration_test.dart` — only current example of a focused widget test under `test/common/widgets/`; it uses `pumpWidget` with a minimal `MaterialApp` shell.
- `pubspec.yaml` — pins Flutter `3.44.8` and includes `flutter_test`.

No `PlayerBar`, bottom-control layout, or other player widget test exists. The only current `pl_player` test is `test/plugin/pl_player/utils/stream_error_test.dart`, which is unrelated to layout.

### Regression evidence

1. Before `8be0fee37`, `buildBottomControl` returned `PlayerBar` with two intrinsic-width rows. `PlayerBar` right-aligned them when they fit and scaled both groups together when they did not. This preserved layout but reduced mobile touch targets.
2. Commit `8be0fee3798f83874e186b6209ae135d76858e87` intentionally removed `PlayerBar`, enlarged mobile controls, and changed the layout to `Row(left, Spacer, SingleChildScrollView(right))`.
3. The current code retains that structure at `lib/plugin/pl_player/view/view.dart:987-1003`; the right group has since also gained `.more` as its last/high-priority item at `lib/plugin/pl_player/view/view.dart:974-986`.
4. In a horizontal Flutter `RenderFlex`, non-flex children are first laid out without a horizontal maximum. The current `SingleChildScrollView` is non-flex, so it sizes to the entire intrinsic width of its right-control row before the `Spacer` receives any space. If `leftWidth + rightWidth > barWidth`, the spacer collapses to zero and the outer row overflows; the scroll view never becomes a viewport over the remainder.
5. `BottomControl` already puts the returned bar in `Expanded` at `lib/plugin/pl_player/widgets/bottom_control.dart:121-125`, so the bar itself has a valid finite width. No extra `LayoutBuilder`, hard-coded width calculation, or system-inset change is needed for this regression.
6. The old `PlayerBar` implementation at `lib/common/widgets/player_bar.dart:55-90` lays out both children at infinite width and applies a paint transform when their combined width exceeds the bar. Reusing that behavior would violate the requirement not to shrink touch targets.

### Smallest robust layout change

The essential correction is to remove the `Spacer` and make the right scroll viewport the one flex child after the fixed leading group:

```dart
Row(
  children: [
    leading,
    Expanded(
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        reverse: true,
        child: trailing,
      ),
    ),
  ],
)
```

Why this satisfies the contract:

- Flutter lays out `leading` at its intrinsic width first, so play/time/previous/next remain unscaled and visible.
- `Expanded` then receives exactly the remaining width; only the trailing viewport is allowed to shrink.
- The scroll view still gives its child unbounded horizontal space internally, so every right-side control keeps its full touch width and becomes scrollable rather than compressed.
- With horizontal `reverse: true` in LTR, the viewport paints from `AxisDirection.left`. At scroll position zero, Flutter computes `viewportWidth - childWidth`, which right-aligns short content and shows the rightmost end of long content. Thus fullscreen and `.more`, which are last at `view.dart:984-985`, stay visible by default.
- A separate `Spacer` must not remain beside the `Expanded` viewport; two flex children would divide the remainder and unnecessarily reduce the usable scroll viewport.

### Recommended production seam

For the smallest change that is also meaningfully testable, repurpose the existing unused `PlayerBar` as a small `StatelessWidget` with explicit `leading` and `trailing` children implementing the row above, then use it from `buildBottomControl`.

This is preferable to testing a duplicated row only inside the test because:

- `buildBottomControl` is a private method on a large state object with controller/media dependencies, so a direct full-player widget test would be disproportionately fragile.
- `PlayerBar` already names the layout concept and has no remaining callers; replacing its custom scaling render object removes dead complexity rather than adding another wrapper.
- A focused test can exercise the exact production widget without constructing `PLVideoPlayer` or changing button behavior/order.

The absolute minimal hotfix is to apply `Expanded` inline in `view.dart`, but without exposing the layout through `PlayerBar` there is no small production-level widget seam for the required narrow/wide regression tests.

### Focused widget test proposal

Add `test/common/widgets/player_bar_test.dart` and use keyed fixed-size boxes as leading/trailing controls.

1. Narrow bar, for example width `240`, leading width `140`, trailing content width `180`:
   - `tester.takeException()` is null (no `RenderFlex` overflow).
   - leading rect remains exactly `140` wide and fully inside the bar (guards against restoring scale-to-fit).
   - the `SingleChildScrollView` rect starts at the leading rect's right edge and ends at the bar's right edge, so its width is the `100` remainder.
   - trailing children retain their original widths.
   - scroll position has a positive `maxScrollExtent`.
   - the last/high-priority trailing child is visible at the right edge initially; after a horizontal drag/jump, earlier trailing controls become reachable.
2. Wide bar, for example width `500`, leading width `140`, trailing content width `180`:
   - no exception and zero scroll extent.
   - leading remains left-aligned and unscaled.
   - trailing content is right-aligned to the bar edge, preserving the former two-group desktop/wide-screen appearance.

These assertions cover the actual constraint contract and are more stable than snapshotting the complete player UI.

### External references

- Regression commit: `https://github.com/Chloemlla/PiliPlus/commit/8be0fee3798f83874e186b6209ae135d76858e87`.
- Flutter version: `3.44.8` from `pubspec.yaml:22-24`.
- Flutter `RenderFlex` non-flex/flex constraints: `https://github.com/flutter/flutter/blob/3.44.8/packages/flutter/lib/src/rendering/flex.dart#L881-L923` and flex-space allocation at `#L1212-L1275`.
- Flutter `SingleChildScrollView` viewport layout: `https://github.com/flutter/flutter/blob/3.44.8/packages/flutter/lib/src/widgets/single_child_scroll_view.dart#L455-L503`.
- Flutter reverse-axis paint offset/right alignment: `https://github.com/flutter/flutter/blob/3.44.8/packages/flutter/lib/src/widgets/single_child_scroll_view.dart#L518-L526`.

### Related specs

- `.trellis/spec/frontend/index.md` — user-facing commits must refresh `WhatsNewData.pages`, and Flutter/Gradle validation must be CI-owned.
- `.trellis/spec/frontend/flutter-build-whats-new.md` — this visible player fix must be included in `lib/pages/onboarding/whats_new_data.dart` in the implementation commit.
- `.trellis/spec/frontend/quality-guidelines.md` — favors focused tests at user-visible boundaries, although this document is otherwise written for the web package.
- `.trellis/spec/guides/code-reuse-thinking-guide.md` — supports reusing the existing `PlayerBar` concept rather than adding a second near-identical layout wrapper.

## Caveats / Not Found

- `python ./.trellis/scripts/task.py current --source` reported no active task. This file uses the exact task directory supplied in the delegation prompt.
- No existing `PlayerBar` or bottom-control widget test was found locally or in the historical commits that introduced/adjusted `PlayerBar`.
- No Flutter, Gradle, analyzer, or test command was run, per repository rules; the proposed assertions require GitHub Actions validation.
- The reported gray square and abnormal bar height are consistent with the same overflow/clipping path, but there is no independent rendering trace proving they are a separate GPU defect. The constrained viewport is the smallest evidence-backed fix.
- If a hypothetical viewport is narrower than the leading group's own intrinsic width, no layout can keep every leading control fully visible without changing that group. Normal phone widths leave sufficient space for the current fixed leading controls; the proposed regression test should use a width where the leading group fits and the trailing group does not.
