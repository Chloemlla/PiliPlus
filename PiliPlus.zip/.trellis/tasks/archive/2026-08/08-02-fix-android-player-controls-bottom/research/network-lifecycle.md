# Research: network lifecycle crashes

- Query: Audit Dio interceptor handler completion and HTTP/2 connection shutdown/reset paths behind crash reports `bedb2a950d3e` and `ec06383840f3`; recommend minimal patches and focused test seams.
- Scope: mixed
- Date: 2026-08-02

## Findings

### Files found

- `.trellis/tasks/08-02-fix-android-player-controls-bottom/prd.md` — requires single-completion Dio handlers, safe HTTP/2 shutdown, and precise filtering of third-party close noise.
- `lib/utils/accounts/account_manager/account_mgr.dart` — custom request/response/error interceptor with asynchronous cookie I/O.
- `lib/http/retry_interceptor.dart` — custom redirect and transport retry interceptor.
- `lib/http/init.dart` — constructs HTTP/1.1 and HTTP/2 pools and replaces them on Clash/connectivity changes.
- `lib/services/crash/crash_report_filter.dart` — current message/stack-aware diagnostic classifier.
- `lib/services/crash/crash_reporter.dart` — platform capture boundary; fatal candidates currently bypass `shouldIgnore` during persistence.
- `lib/main.dart` — guarded root Zone records startup errors as fatal and rethrows them.
- `test/http/retry_interceptor_test.dart` — only covers the retry-disable flag; it does not cover success-after-retry, exhausted retries, redirects, or duplicate completion.
- `test/services/crash/crash_report_filter_test.dart` — covers player/network diagnostics and application-stack preservation, but no HTTP/2 writer-close signature.
- `pubspec.lock` — locks `dio 5.11.0`, `dio_http2_adapter 2.8.0`, and `http2 2.3.1` (`pubspec.lock:403-418`, `pubspec.lock:855-862`).
- `D:/Downloads/pili_plus_crash_report_1785281764239.txt` — report `bedb2a950d3e`, startup `StateError`: Dio request handler already called.
- `D:/Downloads/pili_plus_crash_report_1785387536048.txt` — report `ec06383840f3`, startup `StateError`: HTTP/2 GOAWAY write after byte stream close.

### Dio handler completion audit

Only two project-owned Dio interceptors exist: `AccountManager` and `RetryInterceptor`.

1. `AccountManager.onRequest` starts `loadForRequest(...).then(...)` and attaches a broad `catchError` (`account_mgr.dart:85-109`). The success callback calls `handler.next`; the broad downstream catch also catches errors thrown by that callback and then calls `handler.reject`. Therefore an error occurring after `next` can re-enter the same completed handler. This is the highest-risk match for the reported request-handler crash.
2. `AccountManager.onResponse` uses `_saveCookies(...).whenComplete(() => handler.next(response))` (`account_mgr.dart:114-137`). `whenComplete` always completes the handler, while the Future remains failed when cookie persistence fails. The failure is observed only inside an `assert`; in release it can remain an uncaught asynchronous error. It does not intentionally call the handler twice, but it has unsafe detached error ownership.
3. `AccountManager.onError` has a definite double-completion path (`account_mgr.dart:141-164`): `_saveCookies(...).whenComplete(() => handler.next(err)).catchError(...)`; when `_saveCookies` fails, `whenComplete` first calls `next(err)`, then `catchError` calls `next(error)` on the already completed handler.
4. `RetryInterceptor` completes once on each ordinary branch (`retry_interceptor.dart:14-83`), but both replay chains use `then(...).onError(...)` (`retry_interceptor.dart:36-48`, `66-74`). Rewriting them as the two-callback form of `then(success, onError: failure)` makes it explicit that only the fetch Future's failure selects the error completion and prevents downstream callback failures from being reinterpreted as a second outcome. The typed `onError<DioException>` currently reduces, but does not make the ownership pattern as clear or complete for non-Dio failures.
5. Dio 5.11.0 enforces one completion in `_BaseHandler._throwIfCompleted` and observes returned interceptor Futures. Its changelog also specifically mentions fixes around failing shared interceptor Futures. Project interceptors should therefore never combine `whenComplete` with a later handler call or use a broad catch after a handler-completing success callback.

### HTTP/2 reset and shutdown root cause

`Request._resetAdaptersForNetworkChange` creates a new pool, then closes the active HTTP/2 manager with `force: true` before replacing it (`lib/http/init.dart:195-210`). Android can invoke this shortly after startup from Clash auto-adapt initialization/status changes (`lib/http/init.dart:281-314`), matching report `ec06383840f3` roughly 270 ms after launch.

The locked `dio_http2_adapter 2.8.0` implementation makes forced close unsafe for an in-flight connect:

- `_ConnectionManager.close(force: true)` sets `_forceClosed` and disposes cached transports immediately (`dio_http2_adapter-2.8.0/lib/src/connection_manager_imp.dart:295-301`).
- If a connection Future finishes after that flag is set, `getConnection` calls `transportState.dispose()` but still proceeds to return `transportState.activeTransport` (`connection_manager_imp.dart:79-99`).
- `dispose()` calls `transport.finish()` without awaiting it (`connection_manager_imp.dart:332-335`).
- `http2 2.3.1` `Connection.finish()` enqueues a GOAWAY and later closes the frame writer (`http2-2.3.1/lib/src/connection.dart:281-287`, `373-405`). `FrameWriter.writeGoawayFrame` ultimately calls `_outWriter.add` without a closed guard (`http2-2.3.1/lib/src/frames/frame_writer.dart:238-252`, `271-277`).

The supplied crash stack is exactly this terminal write: `BufferedBytesWriter.add` -> `FrameWriter.writeGoawayFrame` -> `ConnectionMessageQueueOut`, with `Bad state: Cannot add event after closing`. The application-triggered forced pool reset materially widens the package-level close race.

### Existing crash filtering and capture behavior

`CrashReportFilter` currently ignores broad known player diagnostics but preserves exception objects whose stack contains `package:pili_plus/` (`crash_report_filter.dart:1-40`). It has no HTTP/2 GOAWAY/closed-writer predicate.

Filtering only inside `CrashReporter.recordErrorSync` is insufficient for this startup race: fatal candidates deliberately bypass `shouldIgnore` (`crash_reporter.dart:131-170`), and the guarded root Zone records pre-startup errors as fatal and rethrows them (`lib/main.dart:106-130`). The two supplied reports show duplicate capture events, consistent with root-zone recording followed by another uncaught boundary.

Do not add a generic fragment such as `Cannot add event after closing`; that message also identifies real application StreamController lifecycle bugs. A safe predicate must require all of:

- `error is StateError`;
- exact normalized message `Bad state: Cannot add event after closing`;
- stack contains `package:http2/src/frames/frame_writer.dart` and `FrameWriter.writeGoawayFrame`;
- stack contains `package:http2/src/flowcontrol/connection_queues.dart`;
- stack does not contain `package:pili_plus/`.

The Dio duplicate-handler `StateError` must remain reportable; it is an application-owned lifecycle defect, not third-party close noise.

### Recommended minimal patches

1. In `AccountManager`, replace every `then(...).catchError(...)` or `whenComplete(...).catchError(...)` sequence that completes a handler with a single `then(success, onError: failure)` decision. Each callback must call exactly one of `next`, `resolve`, or `reject`, then end. For `onError`, preserve the apparent intended mapping: cookie-save success forwards the original Dio error; cookie-save failure forwards one wrapped Dio error. For `onResponse`, explicitly choose and test the existing user-facing policy (recommended: continue the valid response while consuming/reporting the secondary cookie persistence failure) rather than leaving a failed detached Future.
2. Apply the same two-callback Future form to both `RetryInterceptor` replay paths. This is a small hardening change and makes completion ownership mechanically auditable.
3. In `_resetAdaptersForNetworkChange`, snapshot the old manager/adapters, install the newly created manager and fallback adapter first, update `_http11Dio`, then close the old resources gracefully (`force: false`, or default). Non-forced manager close marks it closed to new connections but permits active/in-flight requests to finish and lets its idle lifecycle close the transport. Do not force-finish an HTTP/2 transport during a network-context swap.
4. Add the exact HTTP/2 writer-close predicate to `CrashReportFilter`. Have the guarded root Zone check `CrashReporter.shouldIgnore(error, stackTrace)` before recording/rethrowing. Also short-circuit the installed `PlatformDispatcher` handler for the same precise predicate so the race is handled if it arrives outside the guarded Zone. Keep the fatal bypass in `recordErrorSync` for all unrelated fatal errors.
5. Do not upgrade or patch the whole HTTP/2 stack for this task. The locked package changelogs contain no stated GOAWAY-after-close fix; removing the application-induced forced shutdown plus exact boundary filtering is the smaller and lower-risk response.

### Focused test seams

- Add `test/utils/accounts/account_manager_test.dart` using a fake `DefaultCookieJar`, an account passed through `RequestOptions.extra`, and a fake Dio adapter. Cover request cookie-load failure, response cookie-save failure, and error-response cookie-save failure. Capture zone errors and assert there is no `handler has already been called` StateError and that each request resolves/rejects once.
- Extend `test/http/retry_interceptor_test.dart` with failure-then-success, exhausted retry, and redirect replay failure. Assert adapter call counts, one terminal result, and no uncaught duplicate-handler StateError.
- Extract the small adapter-swap operation into a public `@visibleForTesting` helper (or equivalent injected lifecycle function). With fake `ConnectionManager`/fallback adapters, assert the new references are installed before old close callbacks run and old HTTP/2/HTTP/1.1 resources receive `force == false`. Avoid a socket-level HTTP/2 reproduction test; it would be slow and package-internal.
- Extend `test/services/crash/crash_report_filter_test.dart` with the exact supplied HTTP/2 stack (ignored), the same message without `FrameWriter.writeGoawayFrame` (reportable), the same stack plus `package:pili_plus/` (reportable), and the Dio duplicate-handler message/stack (reportable).
- If root-zone handling is extracted into a small testable policy/helper, assert the exact HTTP/2 race is treated as handled without fatal persistence/rethrow while a generic closed StreamController `StateError` still follows the fatal path.

### External references

- Dio 5.11.0 package/source: https://pub.dev/packages/dio/versions/5.11.0 and https://github.com/cfug/dio
- dio_http2_adapter 2.8.0 package/source: https://pub.dev/packages/dio_http2_adapter/versions/2.8.0 and https://github.com/cfug/dio/tree/main/plugins/http2_adapter
- http2 2.3.1 package/source: https://pub.dev/packages/http2/versions/2.3.1 and https://github.com/dart-lang/http/tree/master/pkgs/http2
- `dio_http2_adapter 2.8.0` changelog mentions a different closed-connection upload `StateError`, not the reported GOAWAY writer race.

### Related specs

- `.trellis/spec/frontend/flutter-crash-reports.md` — known diagnostics may be ignored, but unrelated Dart/Flutter exceptions and app-owned stacks must remain reportable; regression tests are required for every benign signature.
- `.trellis/spec/frontend/flutter-player-errors.md` — precedent for classifying recoverable third-party transport errors at the correct boundary instead of escalating them as crashes.
- `.trellis/spec/frontend/index.md` — explicitly requires Flutter player transport classification before crash reporting.
- `.trellis/spec/guides/cross-layer-thinking-guide.md` — applies to the reset flow spanning connectivity events, adapter replacement, package transport shutdown, root Zone, and persisted crash history.

## Caveats / Not Found

- `python ./.trellis/scripts/task.py current --source` reported no active task. This file uses the task path explicitly assigned by the parent agent.
- No production or test code was edited, and no Flutter, Gradle, analyzer, or test command was run.
- Historical source at crash commit `b9949558a` was not inspected because this researcher role forbids git operations. Conclusions are based on the supplied reports, current source, and the exact locked package implementations.
- No existing focused test covers `AccountManager` handler completion or adapter pool replacement.
- The HTTP/2 package-level race cannot be completely eliminated from application code; the precise crash predicate remains a defense-in-depth measure after graceful reset removes the known application trigger.
