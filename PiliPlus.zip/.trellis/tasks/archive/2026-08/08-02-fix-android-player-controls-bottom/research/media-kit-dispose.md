# Research: media_kit Android disposal ANR

- Query: Determine the least-risk fix for Android UI-thread ANR in `MediaKitEventLoopHandler::Dispose`, comparing an Android isolate backend, a native C++ patch, and a dependency upgrade; include `NativeMediaService` mitigation and focused CI verification.
- Scope: mixed
- Date: 2026-08-02

## Findings

### Failure evidence

- `D:/Downloads/pili_plus_crash_report_1785555246226.txt:4` reports a 5001 ms input-dispatch timeout on `MainActivity`.
- The captured main thread is blocked in `pthread_join` -> `std::thread::join` -> `MediaKitEventLoopHandler::Dispose` (`...txt:74-84`). This is direct evidence that the native event-loop disposer, not Flutter layout or notification rendering, caused the ANR.
- The same trace records repeated `NativeMediaService` `ACTION_REFRESH` starts at about two-second intervals (`...txt:71`). These starts are not the blocked stack frame, but they add avoidable main-thread/service churn during player teardown.

### Repository dependency and disposal path

- `pubspec.yaml:187-221` overrides all relevant `media_kit` packages to `My-Responsitories/media-kit` at `deac6b62569584b6a5e28e6c60c187a0a7281b3a`; `pubspec.lock:1144-1222` resolves the same revision.
- `.dart_tool/package_config.json:857-906` resolves the packages from the Pub git cache. The pinned `media_kit` version is `1.1.11`; `media_kit_native_event_loop` is `1.0.9`.
- `lib/plugin/pl_player/controller.dart:790-828` creates one `Player` plus `VideoController`. `refreshPlayer` reopens the current media on the same player (`controller.dart:920-930`); it does not create a replacement player.
- `PlPlayerController.dispose()` is synchronous and calls `_videoPlayerController?.dispose()` without awaiting it (`controller.dart:1661-1725`). Making this call explicitly `unawaited`, wrapping it in a microtask, or adding a short delay would not fix the ANR: the later FFI continuation still runs on the UI isolate.
- The pinned dependency's `NativePlayer.dispose()` awaits stop/stream cleanup and then calls synchronous `Initializer.dispose(ctx)` before scheduling `mpv_terminate_destroy` five seconds later (`media_kit/lib/src/player/native/player/real.dart:73-90` in the resolved dependency).
- `InitializerNativeEventLoop.dispose` immediately invokes the C API (`initializer_native_event_loop.dart:104-112`). The native implementation calls `thread->join()` synchronously (`media_kit_native_event_loop/src/media_kit_native_event_loop.cc:105-128`).

### Android native artifact boundary

- Android does not compile the checked-out C++ source as part of this app. `libs/android/media_kit_libs_android_video/android/build.gradle:50-98` downloads prebuilt ABI JARs from `bggRGjQaUbCoE/libmpv-android-video-build/releases/tag/vnext`, pinned by MD5.
- The arm64 JAR contains both `libmedia_kit_native_event_loop.so` and `libmediakitandroidhelper.so`.
- The builder's `bundle_default.sh` checks out `bggRGjQaUbCoE/media-kit` branch `version_1.2.5`, builds `media_kit_native_event_loop`, and packages the resulting `.so`. Therefore, editing only C++ in the Dart dependency fork has no Android effect unless the native JAR is rebuilt, published, and its URL/MD5 updated.

### Upstream fixes

- [`49f38aa6`](https://github.com/media-kit/media-kit/commit/49f38aa637d79cb153186fedbc734c440ad90d46) (2024-05-02, "Fix deadlock disposing event loop") fixes lock-order inversion by releasing the context mutex before re-acquiring the global mutex. The pinned source and the Android builder branch already contain this structure. The captured ANR therefore demonstrates that this fix is necessary but not sufficient for this app/device path.
- [`771b0309`](https://github.com/media-kit/media-kit/commit/771b03095995282a9b6db6839a7e0f7240f01f37) (2024-09-28) removes the standalone `media_kit_native_event_loop` package/dependencies. At that commit, `Initializer` still attempts `InitializerNativeEventLoop` first, and Android native libraries are bundled separately. Cherry-picking this commit alone does not remove Android's `.so` path and risks breaking or changing desktop packaging.
- [`05038c62`](https://github.com/media-kit/media-kit/commit/05038c6253187d68f39a8d995367b258984793d0) (2024-11-08) belongs to a later initializer architecture that no longer has `initializer_native_event_loop.dart`. Its important fallback-isolate disposal changes are still directly relevant: wake `mpv_wait_event` from the disposing isolate, close receive ports, yield on `MPV_EVENT_NONE`, and signal completion when the worker exits. The whole commit is not a clean cherry-pick onto the pinned fork, but these lifecycle changes should be backported.

### Option trade-off and recommendation

1. **Force the isolate event-loop backend on Android — recommended immediate fix.**

   - Patch the existing `media_kit` fork, not app call sites. In `Initializer.create`, select `InitializerIsolate` explicitly for Android before attempting the native backend. In `dispose`, use the same known backend instead of exception-based inference.
   - Backport the lifecycle portions of `05038c62`: pass the caller's `MPV` binding into isolate disposal, call `mpv_wakeup(handle)` immediately after the dispose message, ignore no-event messages safely, close both ports, and retain the delayed kill only as a fallback.
   - Prefer tracking isolate-owned handle addresses in a set/map if the patch keeps automatic fallback on other platforms. This prevents a native disposer that merely returns for an unknown handle from falsely suppressing isolate cleanup.
   - Keep the native event-loop dependency and native JAR unchanged for other platforms in this focused fix. The Android `.so` may remain packaged but must be unused by `Initializer`.
   - This is the smallest change that actually removes `pthread_join` from the Android UI-isolate path without rebuilding native artifacts. Risk is limited to Android event delivery. The app normally uses one shared player, with only bounded detached-player cases, which is materially narrower than a full dependency upgrade.

2. **Patch C++ `Dispose` — not recommended for the immediate repair.**

   - It requires rebuilding and publishing every Android ABI JAR and changing the checked URL/MD5.
   - Simply moving `join` to a detached thread is unsafe: Dart schedules `mpv_terminate_destroy(ctx)` after five seconds, so a still-running event thread can outlive the context. A correct native redesign needs an explicit completion/lifetime protocol across C++ and Dart, not just an asynchronous join.
   - The known upstream lock-order patch is already present, while the observed hang persists. A new native fix would need device-level reproduction and thread-lifetime proof, making it higher risk than bypassing this backend on Android.

3. **Upgrade to a post-`05038c62` upstream architecture — preferred long-term, not this hotfix.**

   - Later upstream uses `NativeCallable.listener` normally and the repaired isolate loop only where executable memory is restricted, eliminating the standalone join-based backend.
   - The pinned fork contains later custom changes (for example `deac6b62` removes `PlayerConfiguration.bufferSize`) on top of the older `1.1.11` architecture. A wholesale upgrade affects Player APIs, native libraries, video output, and custom fork deltas. Treat it as a separate migration with broader playback regression coverage.

### NativeMediaService mitigation

- `NativeMediaService.startOrUpdate` always calls `startForegroundService`/`startService` and then also calls `service?.refreshFromState()` (`NativeMediaService.kt:499-509`). If the service already exists, the queued start later reaches `onStartCommand`, which refreshes again (`NativeMediaService.kt:39-66`).
- Change the policy to: if `service` is non-null, refresh that instance and return; only start the service when no instance exists. This removes repeated service-start records and duplicate notification rebuilds while preserving initial foreground-service startup.
- Keep the existing position throttle (`audio_handler.dart:76-79`, `661-717`) and buffered-position store-only behavior (`audio_handler.dart:319-326`). Do not increase the throttle interval as the primary ANR fix; it cannot remove the synchronous native join.
- On page teardown, `onVideoDetailDispose` already stops the native service when its item list becomes empty (`audio_handler.dart:585-603`) before `PlPlayerController.dispose` is invoked by the video/live views. Preserve that ordering.

### Focused tests and CI-only verification

- Dependency-fork unit/static contract:
  - Android creation selects the isolate backend and never invokes `InitializerNativeEventLoop.create`.
  - Android disposal selects the matching isolate backend, calls `mpv_wakeup(handle)` before the delayed kill, closes the receive ports, and removes handle bookkeeping exactly once.
  - Non-Android backend selection remains unchanged.
- App dependency contract test after dependency resolution: locate `package:media_kit` source and assert the pinned resolved revision contains the Android isolate selection plus the `05038c62` disposal invariants. This guards against a future ref rollback even though the patch lives in the fork.
- `NativeMediaService` static contract test: when a service instance exists, the refresh path returns before any `startForegroundService`/`startService` call; when absent, exactly one start is requested. A source-contract test is acceptable if no JVM test harness exists.
- Existing focused Dart tests for `VideoPlayerServiceHandler.shouldPushNativePosition` remain relevant and should stay green (`test/services/audio_handler_native_position_test.dart`).
- Optional Android CI smoke test: repeatedly create/open/dispose a player while a UI heartbeat/frame callback runs; fail if the main heartbeat stalls near the five-second ANR threshold. This is the only focused runtime check that exercises the original failure class.
- Per repository policy, run no local Flutter, Gradle, analyzer, emulator, or test command. Commit/push the dependency ref, service mitigation, tests, and `WhatsNewData.pages`; use GitHub Actions as build/test authority and inspect all jobs with `gh`.

### Files found

- `.trellis/tasks/08-02-fix-android-player-controls-bottom/prd.md` — task requirements and ANR acceptance criterion.
- `.trellis/spec/frontend/android-media-notification-progress.md` — notification position/throttle and seek contracts.
- `.trellis/spec/frontend/flutter-player-errors.md` — existing media_kit player-boundary conventions.
- `pubspec.yaml` / `pubspec.lock` — pinned media_kit fork and revision.
- `lib/plugin/pl_player/controller.dart` — Player creation, refresh, stream callbacks, and disposal.
- `lib/pages/video/view.dart` / `lib/pages/live_room/view.dart` — notification teardown followed by controller disposal.
- `lib/services/audio_handler.dart` — notification state, throttling, and teardown.
- `lib/services/native_media_notification_service.dart` — Flutter MethodChannel wrapper.
- `android/app/src/main/kotlin/com/chloemlla/piliplus/NativeMediaService.kt` — foreground-service refresh/start behavior.
- Resolved dependency `media_kit/lib/src/player/native/{core,player}/...` — synchronous native event-loop disposal and isolate fallback.
- Resolved dependency `libs/android/media_kit_libs_android_video/android/build.gradle` — prebuilt Android JAR URL/MD5 mechanism.

## Caveats / Not Found

- `python ./.trellis/scripts/task.py current --source` reported no session-active task. The explicit delegated task path was used; no path was inferred.
- The ANR dump does not include the joined event-loop thread's own stack, so the precise reason that thread failed to exit is not proven. The UI-thread blocking mechanism is proven.
- No local build/test was run, per repository policy.
- A source-only C++ edit cannot be validated against Android until the external native JAR pipeline is rebuilt; this is a key reason it is not the immediate recommendation.
