# 持续修复 GitHub Actions

## Goal

持续修复 `Chloemlla/PiliPlus` 当前 `main` 分支及相关开放 PR 的 GitHub Actions，自动提交并推送修复，循环检查最新运行，直到所有当前相关检查通过或出现明确的外部阻塞。

## Requirements

- 使用 `gh` CLI 盘点当前分支、开放 PR 和所有相关失败作业，不因第一个红色作业而停止。
- 只修复当前提交或开放 PR 仍然有效的失败；已被后续提交取代的历史失败仅作背景，不逐个重跑。
- 多个独立根因必须按根因分类并行处理；同一根因的多个 lint 项可作为一个修复批次。
- 禁止在本机运行 Flutter、Gradle、模拟器或完整测试；GitHub Actions 是唯一构建和测试权威。
- 完成代码修改后自动生成提交信息、提交并推送到 `origin/main`。
- 推送后使用 `gh` 检查新运行；若仍失败，重新抓取全部失败日志并继续修复。
- 仅 CI、lint 或测试代码清理且无用户可见行为变化时，不更新 `WhatsNewData.pages`。

## Acceptance Criteria

- [ ] 最新适用的 `main` 分支 Build 工作流全部成功。
- [ ] 所有已盘点失败作业均有明确的根因、修复和最终状态。
- [ ] 未运行任何本地 Flutter、Gradle、模拟器或完整测试命令。
- [ ] 修复已提交并推送到 `origin/main`。
- [ ] 推送后通过 `gh run list` / `gh run view` 完成验证。

## Definition of Done

- GitHub Actions 对最新提交全绿，或无法由仓库代码解决的外部问题被明确标记为阻塞。
- 工作树不混入无法识别的用户改动。
- 任务过程符合 `docs/ci-action-auto-repair.md` 和 Trellis CI 修复规范。

## Technical Approach

1. 显式以 `Chloemlla/PiliPlus` 为目标仓库盘点运行，避免 `gh` 默认解析到上游仓库。
2. 对最新失败运行读取全部 job 状态和 `--log-failed` 日志，按根因分类。
3. 静态修改 Dart、测试或工作流文件；不在本地执行 Flutter/Gradle 验证。
4. 自动提交并推送，通过新触发的 Actions 运行验证；失败则重复该循环。

## Decision (ADR-lite)

**Context**: 本地设备不适合作为 Flutter/Gradle 构建验证环境，且仓库同时配置了 fork 与 upstream，`gh` 默认仓库可能不是实际推送目标。

**Decision**: 所有 CI 查询显式指定 `--repo Chloemlla/PiliPlus`，只以最新适用提交的工作流状态为当前修复对象，并由 GitHub Actions 验证。

**Consequences**: 历史失败不会被无意义地逐次修复或重跑；每次推送会生成新的权威运行，修复过程可能需要多轮远程等待。

## Out of Scope

- 修复已被后续提交取代的历史 Action 运行。
- 强推或修改其他作者无权限维护的分支。
- 本地 Flutter、Gradle、平台打包或模拟器验证。
- 与当前 CI 失败无关的功能开发或重构。

## Technical Notes

- 当前目标仓库：`Chloemlla/PiliPlus`，分支：`main`。
- 首个有效失败运行：`30723243535`，提交：`fbb7011c7570c65dde7e56317bb503582235f590`。
- 失败作业：`Analyze and Test / Analyze`。
- 初始日志显示 1 个 `unused_import` warning 和 11 个非致命 lint info；作为同一 analyzer 根因批次清理。
- 相关规范：`docs/ci-action-auto-repair.md`、`.trellis/spec/frontend/ci-action-auto-repair.md`。
