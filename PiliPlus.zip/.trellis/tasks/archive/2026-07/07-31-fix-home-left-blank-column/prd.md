# 修复返回主页后左侧空白列

## Goal

修复移动端从其它路由返回主页面后，主页面错误保留横屏侧栏或旧安全区、在左侧形成空白竖列并挤压正常内容的问题。主页面应依据重新可见时的当前窗口尺寸立即选择底部导航或侧栏布局。

## Requirements

* 未强制启用“改用侧边栏”时，主页面每次构建都必须按当前 `MediaQuery` 尺寸决定导航布局。
* 从视频、图片预览或其它可能改变方向/系统栏的页面返回竖屏主页面时，不得保留 `NavigationRail` / `NavigationDrawer` 占位。
* 底部导航模式不得把返回前缓存的横向安全区作为正文左右空白。
* 宽屏横屏、平板以及用户明确启用侧边栏时，现有侧栏行为保持不变。
* 路由返回应主动触发主页面外壳复核；不通过任意延时或只针对视频页等待来掩盖问题。
* 不修改导航项目、默认页、未读标记、播放器销毁或页面切换语义。
* 同一变更集更新 `WhatsNewData.pages`，说明本构建修复了返回主页后的左侧空白栏。

## Acceptance Criteria

* [ ] 从会改变方向或系统栏状态的页面返回竖屏主页面后，内容恢复全宽，左侧无异常空白列。
* [ ] 返回后若设备仍处于符合侧栏条件的宽屏横屏，侧栏继续正常显示。
* [ ] 强制侧边栏设置仍然优先，不会被自动切换为底部导航。
* [ ] 底栏模式正文不再继承旧的横向安全区；顶部状态栏安全区保持。
* [ ] “本次更新说明”包含该用户可见修复，构建身份文案仍使用动态 getter。
* [ ] GitHub Actions 中相关静态检查与测试通过；本地不运行 Flutter、Gradle 或构建测试。

## Definition of Done

* 代码改动保持局部，不向现有大文件堆入无关逻辑。
* 通过代码审查确认路由返回、方向变化、底栏安全区和强制侧栏四条路径一致。
* 提交并推送修复；随后通过 `gh` 检查 GitHub Actions，必要时按失败根因循环修复。

## Technical Approach

在 `MainApp.build` 每次使用当前 `MediaQuery` 与强制侧栏设置计算局部导航模式，并同步回 `MainController` 给现有未读/滚动逻辑使用；所有 TabBarView 方向、侧栏和底栏分支统一使用该局部值。`didPopNext` 在安全时机触发一次重建，覆盖底层路由没有及时收到依赖更新的情况。底栏模式只保留顶部安全区，不再把缓存的 `_padding.left` / `_padding.right` 加到正文；侧栏模式仍保留右侧安全区并由侧栏自身处理左侧异形屏空间。

## Decision (ADR-lite)

**Context**: `MainController.useBottomNav` 是普通布尔值，目前只在 `didChangeDependencies` 中赋值；主页面被其它路由覆盖时会移除移动端观察器，返回路径没有主动复核导航模式。视频页关闭时方向恢复未被等待，主路由可能先以旧横屏状态恢复。合并后的 `MainLayout` 会按残留侧栏宽度右移正文，底栏分支又重新应用了缓存的左右安全区。

**Decision**: 让主页面外壳成为响应式布局的最终校验点，保留现有断点和导航组件，不改变各来源页面的返回/销毁时序。

**Consequences**: 修复覆盖所有返回来源且无需等待平台方向 API；每次构建会做一次轻量尺寸判断并同步普通布尔字段。

## Out of Scope

* 重做主页面导航视觉样式或 `MainLayout` 渲染器。
* 修改视频页、图片预览页或系统方向策略。
* 合并其它上游功能。
* 本地执行 Flutter、Gradle、模拟器或完整测试构建。

## Technical Notes

* 主要文件：`lib/pages/main/view.dart`、`lib/common/widgets/main_layout.dart`、`lib/pages/main/controller.dart`。
* 当前侧栏占位来自 `MainApp.build` 在 `useBottomNav == false` 时向 `MainLayout.sideBar` 传入 `_sideBar()`；`MainLayout.performLayout` 会按侧栏宽度设置正文 `bodyOffset.dx`。
* 当前自动模式在 `didChangeDependencies` 中使用 `MediaQuery.sizeOf(context).isPortrait`，但 `didPopNext` 只恢复观察器和刷新未读数据。
* `PlPlayerController.dispose()` 调用异步 `resetScreenRotation()` 后无需等待即可返回首路由，能形成“先回主页、后恢复方向”的时序；主页面应能容错，而不是让所有来源页面串行等待。
* 用户可见提交必须同步更新 `lib/pages/onboarding/whats_new_data.dart`。
* 约束来源：`docs/flutter-build-whats-new.md`、`.trellis/spec/frontend/flutter-build-whats-new.md`、仓库 `AGENTS.md`。
