# Home navigation layout after route return

## Findings

* `MainController.useBottomNav` is a plain `bool` and is only recalculated by `MainApp.didChangeDependencies`.
* `MainApp.didPushNext` removes the mobile `WidgetsBindingObserver`; `didPopNext` restores it but neither recalculates the mode nor rebuilds the shell.
* Video teardown calls `resetScreenRotation()` without awaiting it before the route stack returns to the first route. The main route can therefore become visible while `MediaQuery` still reflects previous landscape/full-screen geometry.
* The merged `MainLayout` treats any non-null sidebar as real layout width and offsets the body by that measured width. A stale `useBottomNav == false` therefore leaves a 72/130dp column that squeezes the home content.
* In bottom-navigation mode, `MainApp.build` also applies cached `_padding.left` and `_padding.right` to the body. A landscape cutout/system-navigation inset can consequently appear as a full-height blank strip even when the sidebar itself is absent.
* `HomePage` does not create the left column. It reads current `MediaQuery` directly for its top bar, which can make the stale outer shell more visible.

## Recommended minimal repair

1. Compute the effective bottom-navigation mode from current `MediaQuery` inside every `MainApp.build`.
2. Store that effective value back into `MainController` for existing consumers, but use the local value consistently throughout the build.
3. Schedule a rebuild from `didPopNext` so the newly revealed route cannot keep the previous shell solely because no inherited dependency notification reached it while covered.
4. In bottom-navigation mode, do not apply horizontal safe-area padding to the body; the navigation widgets/system edge-to-edge handling already own those insets. Keep top padding, and keep the sidebar-mode right inset.

## Testability

There is no existing `MainApp` widget test and directly pumping it requires GetX storage/account services plus desktop plugins on Ubuntu CI. A full widget regression test would require a larger shell extraction. For this focused fix, code review should verify the state flow and GitHub Actions should remain the build/test authority. A later lightweight layout-policy extraction could cover the repository-specific portrait rule (`width < 600 || height >= width`) with a pure unit test.

## Files inspected

* `lib/pages/main/view.dart`
* `lib/pages/main/controller.dart`
* `lib/common/widgets/main_layout.dart`
* `lib/pages/home/view.dart`
* `lib/plugin/pl_player/controller.dart`
* `lib/utils/extension/size_ext.dart`
* `lib/pages/onboarding/whats_new_data.dart`
