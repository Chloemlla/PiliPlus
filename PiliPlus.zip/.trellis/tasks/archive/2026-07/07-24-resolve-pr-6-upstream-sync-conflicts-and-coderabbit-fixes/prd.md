# PRD: Resolve PR #6 upstream sync conflicts and CodeRabbit fixes

## Goal
Merge upstream PR #6 (text selection / emote selection / context menu) into fork main with conflicts resolved, apply CodeRabbit major fixes, update whats-new, merge cleanly.

## Requirements
1. Resolve all merge conflicts with package:pili_plus naming.
2. Keep fork-specific comment date display.
3. Apply CodeRabbit: null-safe selectedText; scroll_position setPixels always + minScrollExtent; document dynamic selectable accessors.
4. Complete emote selection path (EmoteSpan + rawText) for comments.
5. Update WhatsNewData.pages for this user-facing merge.
6. Push and auto-merge; close conflicting PR #6.

## Out of scope
- Local Flutter/Gradle builds
- Upstream package rename PiliPlus
