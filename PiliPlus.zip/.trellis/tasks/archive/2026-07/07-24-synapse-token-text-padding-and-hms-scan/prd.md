# Synapse：令牌文案留白 + HMS 扫码

## Goal

1. 修复各页「令牌可用」类文字控件上下留白过大（去重 + 收紧 padding）
2. 扫码组件对齐华为 Scan Kit（同 PiliPlus 文档）

## Repo

`F:\Repositories\GitHub\Synapse-Client`

## Current state

- Compose：`SynapseMobileApp.kt` 中 `本机令牌可用` / `令牌·可用` / `SML 已保存` 三重展示
- `PanelColumn` 12dp + `SynapseAppHeader` 12dp + `CredentialSummary` 16dp 叠加
- 扫码：CameraX + ML Kit（`QrScannerView.kt`），无 HMS

## Requirements

### Padding

- 统一令牌状态文案，去掉重复 pill/subtitle
- 收紧 header / summary / panel 垂直间距
- 小屏优先紧凑布局

### HMS Scan

- 替换或封装 `PermissionAwareQrScanner` 为 Scan Kit
- 保持 ViewModel 回调契约

## Constraints

- 禁止本地全量构建；CI 验证
