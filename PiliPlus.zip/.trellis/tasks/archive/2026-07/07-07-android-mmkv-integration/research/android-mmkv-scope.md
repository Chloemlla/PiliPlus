# Android MMKV Scope

## Findings

MMKV is already available on Android through `com.tencent:mmkv-static` and a JNI-backed Dart box implementation. The existing bridge persists box entries as encoded strings in MMKV, while the Dart side preserves Hive-like `Box` behavior for callers.

## Suitable storage in this repo

* `setting`: suitable. Values are primitive, lists, sets, and maps used as app preferences.
* `video`: suitable. Values are primitive player preference values and lists.
* `watchProgress`: suitable. Integer values keyed by video/cid-like ids.
* `historyWord`: suitable. Search history is a list of strings under a small dynamic box.
* `localCache`: suitable with a custom value codec. Most entries are primitives/sets; `danmakuFilterRules` stores `RuleFilter`, which needs explicit encoding.
* `reply`: suitable. Values are `Uint8List` protobuf payloads and can be encoded as bytes/base64 through the existing MMKV value format.

## Not migrated

* `account`: keep on Hive. It stores `LoginAccount` objects and is tied to `AccountSecretStore`; moving it would cross the account/security storage boundary.

## Implementation Notes

The current generic MMKV box supports simple JSON-compatible values. To migrate additional boxes safely, add optional value encoder/decoder hooks so model-specific values like `RuleFilter` and `UserInfoData` can be serialized without making the generic MMKV box depend on app models.
