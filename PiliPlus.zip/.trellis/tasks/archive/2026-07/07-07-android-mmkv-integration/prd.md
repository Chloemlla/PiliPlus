# Android MMKV Integration

## Goal

Expand Android MMKV usage from the current hot-storage subset to every suitable app storage surface, while preserving Hive behavior on non-Android platforms and keeping sensitive/account storage on the existing secure path.

## Requirements

* Use MMKV on Android for all suitable `GStorage` boxes: `setting`, `video`, `watchProgress`, `historyWord`, `localCache`, `userInfo`, and optional `reply`.
* Preserve automatic migration from the existing Hive data into MMKV the first time each Android box opens.
* Preserve Hive fallback when Android MMKV is unavailable or a value cannot be safely encoded.
* Keep `Accounts.account` on Hive because it is tied to account model adapters and secret storage.
* Support custom value encoding for app model objects needed by migrated boxes, especially `UserInfoData` and `RuleFilter`.
* Preserve existing export/import, clear, compact, close, watch, key ordering, and optional reply-saving behavior.
* Do not run local Flutter or Gradle build/test commands.

## Acceptance Criteria

* [ ] Android opens the suitable `GStorage` boxes through `openAndroidMmkvBackedBox`.
* [ ] `localCache` can migrate and persist `RuleFilter` values.
* [ ] `userInfo` can migrate and persist `UserInfoData` values.
* [ ] `reply` can migrate and persist `Uint8List` values when enabled.
* [ ] Non-Android platforms continue to open the same boxes through Hive.
* [ ] Account storage remains unchanged.
* [ ] Code is formatted or manually kept consistent without local Flutter/Gradle execution.

## Definition of Done

* Code changes are scoped to storage/MMKV integration.
* Static inspection confirms no unsupported app model boxes are accidentally moved.
* Local Flutter/Gradle commands are not run.
* A commit message is generated and the code changes are committed and pushed after modification.

## Technical Approach

Add optional value codec hooks to `AndroidMmkvBackedBox`, then use them from `GStorage` for boxes that contain app model values. Continue to store account data with Hive and continue using the existing Android MMKV initialization path.

## Decision (ADR-lite)

**Context**: The repo already has a JNI-backed MMKV box, but it currently handles only JSON-compatible values and is applied to a subset of boxes.

**Decision**: Expand the MMKV-backed box usage to all non-sensitive storage boxes that can be encoded deterministically. Keep the generic MMKV layer model-agnostic by passing per-box codecs from `GStorage`.

**Consequences**: Android startup and hot preference/cache access use MMKV more broadly. Model-specific serialization is explicit and localized. Account data remains on the existing secure storage boundary.

## Out of Scope

* Replacing Hive for account storage.
* Running local Flutter or Gradle verification.
* Changing backup/export formats beyond preserving existing setting/video export behavior.

## Research References

* [`research/android-mmkv-scope.md`](research/android-mmkv-scope.md) - scope and suitability notes for each storage box.

## Technical Notes

* Existing Android bridge: `android/app/src/main/java/com/chloemlla/piliplus/AndroidMmkv.java`.
* Existing Dart bridge: `lib/utils/android/android_mmkv_box.dart`.
* Existing storage owner: `lib/utils/storage.dart`.
* `localCache` includes `RuleFilter`, which requires custom encoding.
* `userInfo` uses Hive adapters today but has JSON-shaped fields that can be encoded explicitly.
