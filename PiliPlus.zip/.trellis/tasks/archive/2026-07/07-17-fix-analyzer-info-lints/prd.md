# Fix analyzer info lint warnings

## Goal
Clear the four reported Dart analyzer info diagnostics without behavior changes.

## Scope
1. `lib/pages/about/view.dart`
   - Replace unnecessary lambdas at About page ListTiles with tear-offs for:
     - `FirstLaunchOssNoticeService.openManual`
     - `FirstLaunchImprovementsGuideService.openManual`
2. `lib/services/first_launch_improvements_guide_service.dart`
   - Add `const` to `ImprovementsGuidePage(...)` in first-launch push path.
3. `lib/services/first_launch_oss_notice_service.dart`
   - Add `const` to `OssNoticePage(...)` in first-launch push path.

## Non-goals
- No Flutter/Gradle runs locally
- No feature or UX changes
- No unrelated refactors

## Acceptance
- The four reported `unnecessary_lambdas` / `prefer_const_constructors` infos are fixed.
- First-launch and About entry behavior remains unchanged.
