# Crash History Design Research

## Existing behavior

* `CrashReporter.recordErrorSync` is the shared persistence boundary for Flutter, platform, explicit `Utils.reportError`, and Catcher callbacks.
* `CrashReportStore` writes one `CrashReport` JSON object to `crash_report.json` in three fallback directories and loads the first readable copy.
* `LogsPage` displays one saved report and reuses `CrashReportPage` for details.
* Startup loads the stored report and currently deletes storage when the user continues.
* `Utils.reportError` records directly and then invokes Catcher, whose `CrashReportHandler` records the same error again. History storage therefore needs deduplication.

## Relevant contracts

* `.trellis/spec/frontend/flutter-player-errors.md` classifies recoverable player network-open and interrupted-stream messages as non-crashes.
* Crash report text is already redacted by `CrashReport` and should continue to use the same model/detail/share path.
* Local Flutter and Gradle commands are prohibited for this repository session.

## Options considered

### Separate file per report

Easy individual deletion, but requires directory enumeration, naming rules, migration, and cleanup across all three fallback directories.

### Append-only JSON lines

Crash-safe append behavior is attractive, but marking reports seen, deduplicating, pruning, and migrating the current object complicate the format.

### Versioned bounded JSON envelope (chosen)

Store `version`, `pendingReportId`, and newest-first `reports` in the existing file. This preserves atomic replacement, keeps migration simple, and is appropriate for a small capped history.

## Selected details

* Retain 20 reports.
* Treat a legacy report object as a one-item history and pending startup report.
* Ignore case-insensitive `ssl seek failed` plus existing recoverable HTTP/HTTPS media transport signatures.
* Deduplicate adjacent identical error/stack content so direct + Catcher capture does not create duplicate history rows.
* Use a dedicated history page linked from the existing logs page to keep files focused.
