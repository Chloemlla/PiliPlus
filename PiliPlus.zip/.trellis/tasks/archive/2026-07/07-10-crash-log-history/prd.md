# Crash Log Filtering and History

## Goal

Reduce noise in the crash collection system by retaining actionable Dart/Flutter code failures while ignoring raw player, transport, codec, and media-stream diagnostics, and preserve multiple useful reports so users can revisit previous crashes from inside the app.

## What I already know

* The app currently persists a single crash report in `crash_report.json`.
* The latest saved report is already exposed from the error-log page and can be opened, shared, or cleared.
* Crash capture is centralized in `CrashReporter.recordErrorSync`, which is the appropriate boundary for collection filtering.
* Existing MMKV work in the working tree is unrelated and must not be included in this task's commit.
* Local Flutter and Gradle build/test commands are prohibited; verification must rely on static inspection and GitHub Actions.

## Assumptions

* A bare string reported without a useful Dart stack trace is a player/log diagnostic rather than an actionable application crash.
* Historical reports use the existing crash report detail screen instead of introducing another detail format.
* History is capped at the 20 newest reports to avoid unbounded disk growth.

## Requirements (evolving)

* Do not persist crash reports whose error text matches the benign SSL seek failure pattern.
* Also ignore the recoverable HTTP/HTTPS player transport failures already classified by project specifications as non-crashes.
* Ignore bare string reports without a useful Dart stack trace, including seek, DNS, TCP, TLS, MediaCodec, NAL-unit, and other MPV/FFmpeg diagnostics.
* Keep real Dart/Flutter exceptions with useful stack traces, including framework exceptions whose messages happen to mention networking or media operations unless they match a known player-only signature.
* Preserve multiple past crash reports across app restarts.
* Allow users to open older reports from the in-app error-log area.
* Preserve existing report viewing, sharing, and redaction behavior.
* Preserve compatibility with the existing single-report file when upgrading.
* Dismissing the startup crash prompt marks that report as seen without deleting it from history.

## Acceptance Criteria (evolving)

* [ ] Benign SSL seek failure errors are not written to crash storage.
* [ ] Bare player/log strings with a null or empty stack trace are not written to crash storage or forwarded to Catcher.
* [ ] Seek, DNS, TCP, TLS, MediaCodec, malformed media packet, and similar MPV/FFmpeg examples from the reported crash set are ignored.
* [ ] Other errors continue to be captured.
* [ ] A real Dart/Flutter exception with a useful application/framework stack trace remains reportable.
* [ ] Multiple crash reports survive app restarts within a bounded retention policy.
* [ ] The error-log page lists saved reports and opens any selected report in the existing detail page.
* [ ] Users can clear stored crash history.
* [ ] Existing `crash_report.json` data remains readable after upgrade.
* [ ] Repeated reporting of the same error through both the direct reporter and Catcher handler does not create duplicate history entries.

## Definition of Done

* Code changes follow project crash-service and settings-page conventions.
* Relevant tests are added or updated without executing Flutter or Gradle locally.
* Static inspection confirms filtering occurs before persistence and history remains bounded.
* The task changes are committed and pushed without including unrelated MMKV work.

## Out of Scope (explicit)

* Remote crash upload or third-party crash analytics.
* Collecting network request logs as crash reports.
* Redesigning the crash report detail/share format.

## Technical Notes

* Capture boundary: `lib/services/crash/crash_reporter.dart`.
* Persistence: `lib/services/crash/crash_report_store.dart`.
* History UI: `lib/pages/setting/pages/logs.dart`.
* Existing detail UI: `lib/pages/setting/pages/crash_report.dart`.
* Startup presentation currently accepts one report and needs compatibility consideration.

## Technical Approach

* Add a small pure crash-ignore classifier at the collection boundary that considers both the error object and stack trace.
* Treat unstacked bare strings as non-crash diagnostics and retain explicit known-player signatures as a defense when those diagnostics are wrapped.
* Store a versioned envelope containing a bounded newest-first report list and an optional pending startup report ID.
* Decode the legacy single-report JSON object as a one-item history for in-place migration.
* Add a dedicated history page/widget instead of growing the existing logs page into a super file.
* Reuse `CrashReportPage` for all report details; startup dismissal only clears the pending marker, while explicit history clearing removes stored reports.

## Decision (ADR-lite)

**Context**: A single overwrite-only file cannot support history, and deleting the startup report on continue conflicts with retaining past reports.

**Decision**: Keep one small versioned JSON envelope replicated across the existing fallback directories, retain the 20 newest unique reports, and separate “pending startup display” from history retention.

**Consequences**: Existing installs migrate without a second storage system, users can revisit past reports, duplicate Catcher callbacks are suppressed at persistence, and disk growth remains bounded.

## Research References

* [`research/crash-history-design.md`](research/crash-history-design.md) — repository-specific storage, filtering, startup, and UI findings.
