# Suppress Flutter startup crash page when Lumen already recovered

## Goal

After Lumen SDK finishes handling the previous-session crash report (capture + pending recovery path) and the app is about to enter the main UI, do **not** also open PiliPlus's self-maintained Flutter `CrashReportPage` for that same Lumen report.

## What I already know

* Hybrid architecture (intentional):
  * Android: `lumen-crash-core` via `LumenCrash.installSafely` — capture only, no Compose UI gate in host.
  * Flutter: owns history + product crash UI (`CrashReportStartupGate` → `CrashReportPage`).
* Cold-start path today:
  1. `CrashReporter.ensureInitialized()` only resolves Flutter-persisted pending.
  2. `CrashReportStartupGate` calls `importNativeAndResolvePending()`.
  3. `_importLumenPendingReport()` loads SDK pending, `CrashReportStore.saveSync(..., makePending: true)`, then `clearLumenPendingReport()`.
  4. Gate pushes Flutter `CrashReportPage` for any remaining pending fatal.
* User symptom: when Lumen has already completed "last crash log / ready for main page" recovery, the self-maintained Flutter crash page still appears again.
* Local Flutter/Gradle builds are forbidden; CI is the authority. `apply_patch` is available.
* User-facing commits must update `WhatsNewData.pages` in the same change set.

## Assumptions

* "Lumen SDK 显示完成上次的崩溃日志准备进入主页面" means the Lumen capture/pending recovery path has already been consumed for that crash (import + clear, or host recovery complete), not that PiliPlus should host `LumenCrashGate`.
* Lumen-sourced reports must still be archived into Flutter history for later review/share.
* Non-Lumen native evidence (`android_exit_info` ANR/native/init) may still use the Flutter startup prompt when fatal and unread.
* Pure Dart/Flutter handled reports remain non-startup-pending (existing contract).

## Requirements

1. Importing a Lumen pending report must persist it into Flutter crash history as fatal native evidence.
2. That Lumen-imported report must **not** become (or remain) the cold-start pending prompt that opens `CrashReportPage`.
3. After a successful Lumen import + clear, cold start should proceed into the main app without a second self-maintained crash dialog for the same report.
4. Exit-history / non-Lumen native pending reports keep existing startup presentation rules.
5. History UI still lists Lumen-imported reports; share/copy/redaction unchanged.
6. Clear Lumen SDK pending only after Flutter persistence succeeds (existing safety).
7. Update crash-report unit tests for the new pending policy.
8. Update `.trellis/spec/frontend/flutter-crash-reports.md` contracts.
9. Update `lib/pages/onboarding/whats_new_data.dart` for this user-visible behavior change.
10. Commit + push (no GPG required); do not run local Flutter/Gradle.

## Acceptance Criteria

* [ ] Lumen bridge import saves history with author/capture metadata preserved.
* [ ] Lumen bridge import does not leave `pendingReportId` pointing at that report for startup display.
* [ ] Cold start after only a Lumen pending report does not push `CrashReportPage`.
* [ ] Non-Lumen fatal pending reports can still open the Flutter startup crash page.
* [ ] Spec + tests document/assert the Lumen no-double-UI rule.
* [ ] Whats-new pages mention the fix.
* [ ] Changes committed and pushed.

## Definition of Done

* Code + tests + spec + whats-new updated
* Static inspection only (no local Flutter/Gradle)
* Commit + push for this task only

## Technical Approach

1. In `CrashReporter._importLumenPendingReport`, save with `makePending: false` (history only).
2. Keep exit-history import `makePending: true` for non-Lumen native evidence that still needs a one-shot startup prompt.
3. Optionally, if a Lumen import upgrades/merges into an existing pending entry of the same occurrence, ensure archive merge does not re-promote Lumen-only evidence as startup pending (verify `_isSameOccurrence` + `makePending: false` path).
4. Add/adjust unit coverage around archive/import pending policy where pure-Dart tests can assert it.
5. Spec + whats-new + commit/push.

## Decision (ADR-lite)

**Context**: Hybrid design already chose capture-only Lumen + Flutter product UI, but treating every Lumen import as startup-pending re-creates a second recovery surface after the native recovery path has finished.

**Decision**: Lumen-sourced imports are history-only (not startup-pending). Flutter startup crash UI is reserved for non-Lumen fatal pending evidence.

**Consequences**: JVM crashes captured by Lumen no longer auto-block cold start with Flutter UI; users still find them under 异常报告历史. Exit-info ANR/native/init can still prompt at startup.

## Out of Scope

* Hosting `LumenCrashGate` / Compose crash UI in PiliPlus
* Remote crash upload
* iOS/desktop
* Local Flutter/Gradle verification
* Redesigning crash history UI

## Technical Notes

* Key files:
  * `lib/services/crash/crash_reporter.dart` (`_importLumenPendingReport`)
  * `lib/pages/setting/pages/crash_report.dart` (`CrashReportStartupGate`)
  * `lib/services/crash/crash_report_archive.dart` / store
  * `test/services/crash/*`
  * `.trellis/spec/frontend/flutter-crash-reports.md`
  * `lib/pages/onboarding/whats_new_data.dart`
* Capture marker: `capture: 'lumen_crash'` from `NativeCrashChannel.lumenReportMap`
* Existing contract already says Flutter owns product UI; this task removes double presentation, not capture ownership.
