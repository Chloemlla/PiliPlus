# 首装开源声明与第三方依赖鸣谢页

## Goal
第一次安装打开时展示一页（可滚动）开源声明：源码地址、永久免费/谨防受骗、本项目协议，以及第三方依赖鸣谢（名称、作者、描述、协议）。

## What I already know
* 本项目 LICENSE = GPL-3.0
* 已有首装改进说明引导与 Android 权限引导
* 启动对话框必须用 Get.key navigator

## Requirements
1. 首次安装自动全屏展示 OSS 声明页
2. 展示 source URL、永久免费与防骗提示、GPL-3.0
3. 鸣谢主要第三方依赖：名称 / 作者 / 描述 / 协议（尽量可点开源地址）
4. 完成后写入 seen flag；关于页可再次打开
5. 顺序：OSS 声明 → 改进说明 → Android 权限

## Acceptance Criteria
* [ ] 首次启动弹出 OSS 页
* [ ] 完成后不再自动弹出
* [ ] 依赖列表含名称作者描述协议
* [ ] 关于页可再开
* [ ] 提交推送

## Out of Scope
* 不自动扫描 pub-cache 生成完整传递依赖
* 本地不跑 Flutter

## Technical Notes
* 静态 credits 数据覆盖 pubspec 直接依赖与关键 fork/native 组件
