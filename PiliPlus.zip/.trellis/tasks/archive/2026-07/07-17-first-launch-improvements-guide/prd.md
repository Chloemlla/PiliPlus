# 首装引导页讲解本分支相对上游改进

## Goal
应用**第一次安装打开**时展示全屏引导页，详细解释本分支（Chloemlla/main）相对上游的改进，帮助用户理解差异能力与使用方式。

## What I already know
* README 已有详细「相对上游改进」章节（Seal / Web QR / crash+lumen / MMKV / 密钥隐私 / 媒体 / 剪贴板 / 首启权限 / CI 等）。
* 现有首启只有 Android 权限 gate：`AndroidFirstLaunchPermissionGate`；崩溃有 `CrashReportStartupGate`。
* 启动对话框须用 `Get.key.currentState`，见 `flutter-startup-context` 规格。
* 无现成 onboarding 页面。

## Assumptions
* 全平台首次启动展示（不只 Android）。
* 形式：多页 PageView 详细讲解（欢迎 + 各主题 + 完成），支持跳过。
* 仅首次：`SettingBoxKey.firstLaunchImprovementsGuideSeen`；完成后/跳过写 true。
* 与权限引导顺序：改进说明先于 Android 权限（信息优先）。
* 关于页增加入口，便于再次查看（非 MVP 阻塞，但实现成本低）。

## Open Questions
* （无阻塞项；若用户要改成单页滚动或仅 Android，再调整）

## Requirements
1. 首次安装打开后，在主界面可用前 push 全屏引导页（Navigator 就绪后）。
2. 内容覆盖 README 中本分支核心改进，语气面向用户，含「怎么用 / 哪里找」。
3. 页面结构：欢迎 → 主题页（Seal、Web QR、崩溃历史、MMKV、隐私安全、媒体与剪贴板、工程与更新源）→ 完成页。
4. 支持「跳过」与「下一步 / 开始使用」；完成后标记已读，不再自动弹出。
5. 关于页可再次打开同一引导内容。
6. 不阻断冷启：Navigator 未就绪则 frame 重试，不写完成标记。

## Acceptance Criteria
* [ ] 清空该 setting key 后首次启动会弹出引导
* [ ] 完成后再次启动不再自动弹出
* [ ] 内容覆盖本分支相对上游主要改进
* [ ] 关于页可再次进入
* [ ] 遵守 startup navigator 契约
* [ ] 提交并推送

## Out of Scope
* 不做动画复杂运营式引导
* 不改权限弹窗文案本身
* 不在本地跑 Flutter/Gradle

## Technical Notes
* 新增：`lib/pages/onboarding/*`、`lib/services/first_launch_improvements_guide_service.dart`
* 修改：`main.dart` builder gate、`storage_key.dart`、`about/view.dart`、可选 `app_pages.dart`
* 内容数据：静态 list/model，避免硬编码散落 UI
