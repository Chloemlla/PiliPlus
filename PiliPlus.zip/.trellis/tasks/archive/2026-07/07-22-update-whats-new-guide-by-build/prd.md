# 新构建首次打开展示上游有意变更更新教程

## Goal
用户**第一次打开某个新构建版本**时，用与「开源声明 / 本分支改进说明」同风格的沉浸式全屏教程，讲解该构建里上游有意的 UI 重构与功能增强；用 `BuildConfig.commitHash` + `BuildConfig.buildTime` 判定是否展示。

## What I already know
* 首装链路：crash → OSS notice → improvements guide → Android permissions
* `BuildConfig.commitHash` / `buildTime` 已在 About 展示
* 首装 improvements 讲的是「本分支相对上游」；本次要讲「这次新构建相对上一构建」的有意变更
* 评论日期是误删回归（已修），不应写成“有意增强”

## Requirements
1. 新构建首次冷启：若当前 commitHash/buildTime 与本地已确认的版本不同，弹出全屏「本次更新说明」。
2. 真首装：走现有 OSS + 本分支改进说明；完成后把当前构建记为已确认，避免立刻再弹 whats-new。
3. 老用户升级：不重弹首装 OSS/改进说明，只弹 whats-new。
4. 内容：上游有意 UI 重构 / 功能增强（TranslucentRow、FAB、直播反馈、webview scheme、EDL、弹幕精度等）；可附带“已修复评论日期”说明。
5. About 可手动再开；关闭后写入当前 hash+time。
6. 遵守 startup navigator / overlay 优先级契约。

## Acceptance Criteria
* [ ] 新 commit/buildTime 首次打开会弹 whats-new
* [ ] 同一构建再次打开不弹
* [ ] 真首装不会在改进说明后再强制弹 whats-new
* [ ] About 可手动打开
* [ ] 不本地跑 Flutter/Gradle
* [ ] 提交并推送

## Out of Scope
* 不自动从 GitHub release body 拉取文案
* 不做复杂动画运营页
