# lumen-crash hybrid bridge research

## Choice

Hybrid capture bridge, performance-first.

## Why not full Compose gate

* PiliPlus product crash UX is Flutter (`CrashReportPage` + history).
* Host has no Compose setup today.
* Enabling Compose only for startup crash UI adds complexity without replacing Flutter history.

## Why not keep NativeCrashHandler

* Dual uncaught handlers race and double-persist.
* README warns against host-local crash-core clones after adopting the SDK.

## Process-exit interaction

* Keep `ProcessExitCollector` for ANR / native crash / initialization failure.
* Skip `ApplicationExitInfo.REASON_CRASH` once lumen-crash owns JVM uncaught capture.

## Dependency policy

* CI resolves latest `lumen-crash-v*` via GitHub Releases API.
* Gradle consumes `LUMEN_CRASH_VERSION` / `lumenCrashVersion`.
* Offline fallback: `0.1.0` stable tag.
