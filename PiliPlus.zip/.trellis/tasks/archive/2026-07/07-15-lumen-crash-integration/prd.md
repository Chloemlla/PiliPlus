# Adapt and integrate lumen-crash SDK

## Goal

Integrate Project Lumen `lumen-crash` into PiliPlus Android as a hybrid capture bridge: native uncaught capture and persistence use the SDK, while Flutter continues to own filtering, history, and startup/product UI. Prefer low runtime overhead (no Compose crash screen, no dual uncaught handlers).

## What I already know

* Source guidance: `F:/Repositories/GitHub/Project-Lumen/lumen-crash/README.md`
* SDK package: `com.chloemlla.lumen.crash`
* Maven coordinates: `com.chloemlla.lumen:lumen-crash:<auto-resolved-latest>`
* GitHub Packages: `https://maven.pkg.github.com/Chloemlla/Project-Lumen`
* Local known tags include `lumen-crash-v0.1.0` and newer main auto tags (`0.1.0-<shortSha>`); base `sdk.version` is `0.1.0`
* Project Lumen host installs from `attachBaseContext` and gates Compose UI with `LumenCrashReportScreen`
* PiliPlus already has:
  * Flutter crash stack under `lib/services/crash/*` + settings history UI
  * Android staging via `NativeCrashHandler` / `NativeCrashStore` / `NativeCrashChannel` / `ProcessExitCollector`
  * Spec: `.trellis/spec/frontend/flutter-crash-reports.md`
* Current Android host has no Compose feature flag, no FileProvider, minify disabled, `minSdk = maxOf(flutter.minSdkVersion, 23)`
* Local Flutter/Gradle execution is prohibited

## Decision (ADR-lite)

**Context**: PiliPlus already has a mature Flutter crash UX/history pipeline. lumen-crash is Compose-first and owns Android uncaught capture + external persistence. Dual uncaught handlers and dual product UIs would be wasteful and buggy.

**Decision**: Hybrid / capture bridge (performance-first)
1. Consume published `lumen-crash` via GitHub Packages with CI auto-resolve of latest `lumen-crash-v*` main release.
2. Install `LumenCrash` early in `Application.attachBaseContext`.
3. Remove host-local `NativeCrashHandler` so only the SDK owns the JVM uncaught path.
4. Keep `ProcessExitCollector` for ANR/native-process-exit evidence not covered by the SDK; skip `REASON_CRASH` java exits to avoid duplicates.
5. Bridge pending SDK reports + exit-history staging into Flutter through the existing method channel; Flutter history/startup UI remains canonical.
6. Do **not** enable Compose host UI / `LumenCrashReportScreen` in this task.
7. FileProvider/share-as-file remains out of scope until a Compose/share host path is added.
8. Raise Android `minSdk` floor to 26 for SDK compliance.

**Consequences**:
* Runtime path stays Flutter-owned for UX; native fatal capture becomes SDK-backed.
* Transitive Compose artifacts may still enter the Android dependency graph through the AAR `api` surface even without host Compose UI.
* CI needs Packages credentials + version resolution.

## Requirements

* Android host depends on `com.chloemlla.lumen:lumen-crash` from GitHub Packages.
* Version is injected from `lumenCrashVersion` / `LUMEN_CRASH_VERSION` (CI auto-resolves latest `lumen-crash-v*`); stable `0.1.0` only as offline fallback.
* `LumenCrash.install(...)` runs early with PiliPlus app metadata.
* Pending lumen report is imported into Flutter crash history on next launch as fatal native evidence, then cleared from SDK storage.
* Existing Flutter filter/history/startup-pending contracts remain intact.
* Exit-info import remains available for native crash/ANR/init failure.
* No second uncaught-exception owner remains in app code.
* Host ProGuard keep rules include the SDK exemption block as backup.
* Spec/tests updated for the new bridge mapping.
* No local Flutter/Gradle execution.

## Acceptance Criteria

* [ ] GitHub Packages repository + credential wiring exists in Android Gradle config
* [ ] App module depends on `com.chloemlla.lumen:lumen-crash:$lumenCrashVersion`
* [ ] CI Android job resolves latest `lumen-crash-v*` and injects `LUMEN_CRASH_VERSION`
* [ ] `minSdk` floor is 26
* [ ] `PiliPlusApplication` installs `LumenCrash` from `attachBaseContext` (idempotent onCreate)
* [ ] `NativeCrashHandler` is removed / no longer installed
* [ ] Method channel can load/clear lumen pending report
* [ ] `CrashReporter.ensureInitialized` imports lumen pending report into Flutter store as fatal + acknowledges/clears SDK storage
* [ ] Process-exit collector still stages ANR/native/init failures; java_crash exits are not double-imported
* [ ] Unit tests cover lumen-report mapping
* [ ] Crash history spec documents the hybrid bridge
* [ ] Task changes committed and pushed without unrelated dirty files

## Definition of Done

* PRD confirmed
* Code + tests + spec updated
* Static inspection complete
* Commit + push for this task only

## Out of Scope

* `LumenCrashReportScreen` Compose startup gate
* FileProvider / share-as-file wiring
* Remote crash upload backend
* Replacing Flutter crash history/filter UX
* iOS/desktop changes
* Enabling host release minify solely for this task
* Local full Android builds

## Technical Approach

1. Gradle/repo/dependency + CI version resolve
2. Application install + remove local uncaught handler
3. Channel bridge for lumen pending report
4. Flutter import path + model mapping
5. Process-exit de-dupe with SDK JVM capture
6. ProGuard keep rules + tests + spec

## Technical Notes

* Key files: `android/build.gradle.kts`, `android/settings.gradle.kts`, `android/app/build.gradle.kts`, `PiliPlusApplication.kt`, `NativeCrashChannel.kt`, `NativeCrashHandler.kt`, `ProcessExitCollector.kt`, `native_crash_bridge.dart`, `crash_reporter.dart`, `crash_report.dart`, `.github/workflows/build.yml`, `.trellis/spec/frontend/flutter-crash-reports.md`
* Lumen store path is external app-specific `lumen-crash/crash_report.json`
* Existing native exit staging remains under `noBackupFilesDir/native_crashes`
