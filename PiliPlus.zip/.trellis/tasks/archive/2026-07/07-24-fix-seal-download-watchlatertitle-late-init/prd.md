# fix: Seal 下载 LateInitializationError watchLaterTitle

## Goal

修复用户在普通视频页（`/videoV`）触发 Seal 委托下载时，因读取未初始化的 `late String watchLaterTitle` 导致的崩溃（Report ID: 24c71231d602）。

## Requirements

* 普通 `/videoV` 页触发 Seal 下载不得因 `watchLaterTitle` 崩溃
* 稍后再看 / 收藏夹连播（`isPlayAll`）仍能拿到 `favTitle` / `watchLaterTitle` 作为标题
* 标题解析优先使用 controller 缓存的 `args`，避免被中间路由污染 `Get.arguments`
* 无法解析标题时回退到 `bvid`（保持现状）
* `watchLaterTitle` 改为默认空串，从源头消除该字段的 `LateInitializationError`

## Acceptance Criteria

* [x] 普通视频页（`SourceType.normal`，`watchLaterTitle` 未赋值）调用 `_titleOf` 不抛 `LateError`
* [x] `isPlayAll` 场景仍能返回 `watchLaterTitle` / `favTitle`
* [x] `args['title']` 存在时优先返回该标题
* [x] `VideoDetailController.watchLaterTitle` 不再是裸 `late`，默认 `''`
* [x] 有针对性的单元测试覆盖未初始化（空串）与已赋值两条路径
* [x] `dart analyze` 相关文件无新增问题

## Definition of Done

* Tests added/updated
* Lint / typecheck green for touched files
* No behavior change for successful title paths beyond crash prevention

## Technical Approach

**Approach A + B (chosen)**

1. `lib/pages/video/controller.dart`
   - 将 `late String watchLaterTitle;` 改为 `String watchLaterTitle = '';`
   - `isPlayAll` 路径仍赋值 `args['favTitle']`（保持现有行为）

2. `lib/utils/seal_download_utils.dart` `_titleOf`
   - 优先读 `ctr.args`（Map）中的 `title` / `favTitle`
   - 再读 `ctr.watchLaterTitle`（仅非空时采用；配合默认空串可安全 trim）
   - 兜底 `ctr.bvid`
   - 不再依赖实时 `Get.arguments`（避免中间路由污染）

3. 单元测试
   - 覆盖：空 `watchLaterTitle` + 无 args title → 返回 bvid
   - 覆盖：`args['title']` 优先
   - 覆盖：`watchLaterTitle` 有值时返回该值

## Decision (ADR-lite)

**Context**: 普通视频页从未初始化 `watchLaterTitle`，但 Seal 下载无条件读取导致崩溃；同时 UI 其它路径已用 `isPlayAll` 守卫。

**Decision**: A（harden `_titleOf`）+ B（字段默认空串）。双保险：下载路径防御 + 字段级消除 LateError 类。

**Consequences**:
* 最小行为变化：未赋值时字段从“不可读”变为 `''`，既有 `isPlayAll` 守卫的 UI 无感
* `_titleOf` 更稳：用 `ctr.args` 替代全局 `Get.arguments`

## Out of Scope

* 全量审计 / 改造项目中其它 `late` 字段
* Seal 下载协议 / UI 面板重构
* 修改 `view.dart` 播放列表面板逻辑

## Technical Notes

* Crash: Report ID 24c71231d602, commit 2bd73d089
* Crash site: `lib/utils/seal_download_utils.dart` `_titleOf`
* Field: `lib/pages/video/controller.dart` L107
* Init path: only when `isPlayAll` (L386-389)
