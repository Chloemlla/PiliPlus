# 修复下载视频请求被拒绝（Seal）

## Goal

修复 PiliPlus 委托 Seal 下载时出现 `status=rejected`（含 `unsupported_version` / 静默取消）的问题，使协议 v2（Cookie / keep_sections）与 Activity Result 路径行为一致、可诊断。

## What I already know

* 问题侧在 Seal：`F:\Repositories\GitHub\Seal`（用户明确）。
* Seal 源码 `ExternalDownloadProtocol` 已声明 `PROTOCOL_VERSION=2`、`MAX_SUPPORTED_VERSION=2`（commit `236c035e`）。
* 拒绝错误文案模板：`Unsupported protocol_version=$v (supported $min..$max)` 出自 `ExternalDownloadRequestParser`。
* **漂移**：`AndroidManifest.xml` Application meta-data 仍为：
  * `external_download_protocol_version` = `1`
  * `external_download_max_protocol_version` = `1`
* **漂移**：`docs/third-party-call-guide.md` / `third-party-delegate-integration.md` 仍写 max=`1`、`unsupported_version` 范围 `1..1`。
* PiliPlus 在带 Cookie / strip 时发送 `protocol_version=2`（`SealDownloadChannel`），不读 meta-data；若设备安装的 Seal 仍是 v1-only 会硬拒。
* **静默拒绝**：`QuickDownloadActivity` 在存在 `LumenCrash.loadPendingReport()` 时直接 `finish()` 且 **不 setResult**；PiliPlus `onActivityResult` 无 extras 时将 `RESULT_CANCELED` 映射为 `rejected`。
* 另一静默路径：ShowUi 后 `urls.isEmpty()` 直接 finish，无 result。
* Gate 默认：`EXTERNAL_DELEGATE_ENABLED=true`、白名单关、auto-start 关、`EXTERNAL_ACCEPT_COOKIES=false`；`cookies_required=false` 时会剥离 Cookie 继续（非硬拒）。

## Requirements

* R1：Application meta-data 与协议常量对齐：`protocol_version=2`，`max_protocol_version=2`。
* R2：第三方文档 error_code / Discovery meta-data 与 `1..2` 一致。
* R3：所有会结束 Activity 的委托拒绝/阻断路径必须 `setResult` + 可选广播，带 `status=rejected` 与明确 `error_code` / `error_message`（含 pending crash、urls 空）。
* R4：新增/复用 error_code（如 `app_busy`）表示崩溃报告未处理导致无法进入快捷下载；调用方可展示可行动提示。
* R5：单测或常量断言覆盖 max=2；不扩大协议语义。
* R6：CHANGELOG 记录修复。

## Acceptance Criteria

* [ ] Manifest max 协议版本为 2。
* [ ] 文档不再写 supported `1..1` 或 max meta=`1`。
* [ ] Pending crash 阻断时 PiliPlus 能收到带 error_code 的 rejected，而非空 extras。
* [ ] ShowUi 后空 URL 返回 `invalid_url` rejected。
* [ ] 现有 v1 请求仍可解析；v2 Cookie/sections 仍按 gate 策略工作。
* [ ] 提交并 push 到 Seal remote。

## Definition of Done

* 代码与文档一致；无本地 Flutter/Gradle 全量构建（按 AGENTS.md，CI 权威）。
* Commit + push（可省略 GPG）。

## Out of Scope

* 改 PiliPlus 协议协商 / 面板文案（除非后续需要映射新 error_code）。
* 改变 cookie 默认策略（acceptCookies 仍默认关）。
* 在本机跑 Gradle 构建。

## Technical Approach

1. 更新 `AndroidManifest.xml` meta-data。
2. `ExternalDownloadProtocol` 增加 `ERROR_APP_BUSY`（或 `pending_crash`）。
3. `QuickDownloadActivity`：pending crash 与 empty urls 走 `ExternalDownloadStatusReporter.finishWithResult`。
4. 同步 `docs/third-party-*.md` + CHANGELOG。
5. 扩展 integration test 常量/文档范围说明。

## Decision (ADR-lite)

* **Context**：v2 落地后 meta-data/文档未同步；部分 finish 路径无 Activity Result，导致调用方统一显示「请求被拒绝」。
* **Decision**：以协议常量 1..2 为准修正发现 meta 与文档；阻断路径显式 rejected，避免静默取消。
* **Consequences**：调用方可区分版本不兼容与 app_busy；旧客户端读 max=2 后可发 v2。

## Technical Notes

* 工作区：Seal `main` clean；PiliPlus 另有 Clash WIP 勿混入。
* Trellis 任务目录（记在 PiliPlus）：`.trellis/tasks/07-24-fix-seal-video-download-request-rejected/`
* 关键实现文件：`QuickDownloadActivity.kt`、`ExternalDownloadProtocol.kt`、`AndroidManifest.xml`、docs、CHANGELOG、可选 test。
