# Fix Seal invoke blank delay and multi-P batch download

## Goal

修复两处 Seal 委托下载体验问题：
1. 唤起 Seal 前出现超长空白等待，只有用户点「后台等待」后才真正启动 Seal。
2. 分 P / 合集类视频无法批量下载多 P 或全部下载（含 PiliPlus→Seal 委托路径）。

## Requirements

### R1 — 消除唤起空白阻塞

* 点击「下载视频/音频」后应 **立即** 调用 `delegateDownload` 启动 Seal，不得被状态面板 await 卡住。
* 状态面板仍应立即出现（waitingUi / waitingAuto），与启动并行。
* 「后台等待」仅关闭面板、继续监听状态；不再承担「放行启动」语义。
* 未安装 / 启动失败路径仍正常展示错误/安装面板。

### R2 — 分 P 批量委托 Seal（菜单分流）

多 P（同 bvid，`pages.length > 1`）时，「下载视频 / 下载音频��展开为：

1. **当前 P** — 仅委托当前分 P URL（`?p=N`）
2. **选择分 P…** — 勾选列表（参考离线缓存列表样式），确认后一次委托 `urls[]`
3. **全部** — 委托该稿件全部 `?p=` URL

单 P / 无 pages：保持一键委托，行为与现网一致。

### R3 — 协议与原生通道

* Dart 构造 bilibili 标准 URL：`https://www.bilibili.com/video/{bvid}?p={page}`（page 从 1）
* 原生 `SealDownloadChannel.delegateDownload` 支持 `urls: List<String>`（Seal `EXTRA_URLS`）
* 单 URL 仍可用 `url` 字段（兼容）
* Session / 状态面板展示批量 N 项标题信息
* auto_start 开/关两条路径均可用

### R4 — MVP 合集边界

* **同分 P（同 bvid 多 page）**：必须支持
* **跨 bvid 合集/season**：本 MVP **不做**独立合集选择器；若当前页是 season 内某一集且该集自身多 P，仍按该集 pages 处理
* 番剧 ep：保持现有单 ep URL（`/bangumi/play/ep$epId`）；不做整季批量（Out of Scope）

## Acceptance Criteria

* [ ] 点击下载后，无需点「后台等待」，Seal 即被唤起
* [ ] 状态面板与 Seal 启动并行，无「先空白面板、后才跳转」长阻塞
* [ ] 单 P：行为与现网一致，委托 1 个 URL（可带 `?p=1` 或无 p，语义等价当前稿）
* [ ] 多 P：可选 当前 / 多选 / 全部，委托对应 `urls[]`
* [ ] 选择分 P 面板：至少全选/取消、确认、取消；默认勾选当前 P
* [ ] auto_start 开/关均可启动；面板状态机不回归（accepted/completed/failed 等）
* [ ] 未安装 Seal 仍提示安装
* [ ] `flutter analyze` 无新增 error（本机条件允许时）

## Definition of Done

* Dart + Kotlin 改动完成
* 不破坏 L3 状态广播监听与完成打开/分享
* PRD / 技术笔记记录 URL 约定与交互决策
* implement/check 上下文已配置；task 可归档

## Technical Approach

### Bug 1 修复

`SealDownloadUtils._download` / `_showOrUpdatePanel`：

* `_showOrUpdatePanel` **不再 await** `SmartDialog.show` 的 dismiss Future（`unawaited` 或 fire-and-forget）
* 先展示面板（非阻塞），再立即 `invokeMethod('delegateDownload')`
* 或：先启动 Seal，再 show 面板（需保证错误路径仍能弹面板）— **推荐：非阻塞 show → 立即 delegate**

### Bug 2 修复

1. `pageUrlOf` / 新增 `pageUrlsForParts`：按 `Part.page ?? index+1` 生成 `?p=` URL
2. `header_control` 或多 P 入口：弹出 bottom sheet / dialog 三选一
3. 选择分 P：简单 checkbox 列表 bottom sheet
4. `SealDownloadUtils.downloadVideo/Audio` 增加可选 `urls` / parts 参数；批量共用一个 session + requestId
5. Kotlin：`call.argument<List<String>>("urls")` → `putExtra(EXTRA_URLS, urlsArray)`；兼容单 `url`

## Decision (ADR-lite)

**Context**: 空白期是 await SmartDialog 顺序 bug；批量需产品交互。
**Decision**:
* R1 非阻塞面板 + 立即启动 Seal
* R2 菜单分流（当前 / 选择 / 全部）
* 跨 bvid 合集与番剧整季批量不做
**Consequences**: 多 P UX 与离线缓存入口分离但风格可参考；Seal 一次收多 URL。

## Out of Scope

* 改 Seal 站内 playlist / yt-dlp
* 跨 bvid 合集批量选择器
* 番剧整季批量
* 替换应用内离线缓存 DownloadPanel
* iOS / 非 Android
* 远程控制 Seal

## Technical Notes

| 文件 | 角色 |
|------|------|
| `lib/utils/seal_download_utils.dart` | 阻塞修复；批量 URL；选择 UI 可同文件或邻近 widget |
| `android/.../SealDownloadChannel.kt` | `urls` extra |
| `lib/pages/video/widgets/header_control.dart` | 菜单入口分流 |
| `lib/pages/video/introduction/ugc/controller.dart` | pages 数据 |
| `lib/pages/video/download_panel/view.dart` | 勾选 UI 参考 |
| Seal `EXTRA_URLS` / parser | 已支持，无需改协议 |

### URL 约定

```
https://www.bilibili.com/video/{bvid}?p={page}
```

`page` = `Part.page`��缺省时用列表 index+1。

## What I already know

* 根因：`await SmartDialog.show` 在 dismiss 前不返回 → 推迟 `delegateDownload`
* Seal 协议 `urls: String[]` 已就绪
* 用户确认：全部按推荐方案，直接改代码
