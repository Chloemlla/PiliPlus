# Port mergeable high-value upstream PRs to new branch and auto-merge after CI

## Goal

Review open PRs on upstream `bggRGjQaUbCoE/PiliPlus`, port the ones that are cleanly mergeable (no real logic conflicts, only cosmetic import-path differences) and have meaningful feature value, into a new branch on `Chloemlla/PiliPlus`, then watch GitHub Actions on that branch and merge it into `main` automatically once builds are green.

## What I already know

* Upstream repo: `bggRGjQaUbCoE/PiliPlus` (parent). Fork: `Chloemlla/PiliPlus` (origin, this repo). `gh auth status` confirms push access to `Chloemlla/PiliPlus` as user `Chloemlla`.
* 4 open PRs on upstream as of 2026-07-26:
  * **#2443** `feat: 上报听视频的进度` (audio heartbeat progress reporting) — **already implemented in this repo** and more advanced (commits `13fbb9884`, `a44b2d109` already add heartbeat reset on seek/track-change beyond what #2443 does). **Skip — no action needed.**
  * **#2446** `fix: auto-recover from stream corruption errors` — mergeable/CLEAN. Single file (`lib/plugin/pl_player/controller.dart`, +10 lines): adds `stream-lavf-o=reconnect=1` mpv option + auto `refreshPlayer()` on NAL corruption error strings, 5s throttle. Verified NOT present in current `lib/plugin/pl_player/controller.dart` (`grep` for `reconnect`/`NAL` found nothing). Real bug fix, small blast radius. **High value candidate.**
  * **#2461** `feat(shutdown_timer_service): 定时关闭剩余时间提示` — mergeable but CI `UNSTABLE` on upstream (likely just their CI flakiness, not a merge conflict). 4 files, +141/-15: shows remaining shutdown-timer time in video header control, live room header, and audio page. Current repo only has the "定时关闭" (set shutdown timer) menu entry with no remaining-time display. **Medium-value UX candidate.**
  * **#2460** `feat: 新增 Windows 端 Z/X/C 快捷键快速调节播放倍速` — mergeable but CI `UNSTABLE` on upstream. 3 files, +97: adds Z (reset 1x) / X (slow down) / C (speed up) keyboard shortcuts with on-screen speed toast, Windows/desktop-focused, gated behind existing "enable keyboard control" setting, additive only. **Lower-value, nice-to-have candidate** (desktop-only, narrow audience).
* All 4 PRs' diffs will show as touching the same files/imports due to package name difference: upstream still uses `package:PiliPlus/...` imports, this repo renamed to `package:pili_plus/...` (confirmed via `git diff upstream/main origin/main -- lib/pages/audio/controller.dart`). This is NOT a real logic conflict — every port requires mechanically rewriting the import prefix, same as prior task `07-10-port-upstream-pr-2443` already did.
* No branch protection on `Chloemlla/PiliPlus:main` (`gh api .../branches/main/protection` → 404 "Branch not protected"). Squash/merge/rebase merge all allowed; delete-branch-on-merge is off.
* CI workflows in this repo: `build.yml` (Android etc.), `ios.yml`, `linux_x64.yml`, `mac.yml`, `win_x64.yml`. `build.yml` triggers on any `push` and on PR events. Pushing the new branch will kick off Actions runs automatically; opening a PR against `main` will also trigger PR-scoped runs.
* Prior task `07-10-port-upstream-pr-2443` establishes the porting pattern this task should follow: use `gh pr diff`, hand-adapt the import prefix, do not run local Flutter/Gradle (no Android SDK / full VS locally — see project memory `piliplus-local-toolchain`), verify via GitHub Actions after push.

## Assumptions (temporary)

* "自动合并进主分支" means: once required CI workflows on the new branch (or the PR built from it) report success, merge into `main` without further per-run confirmation from the user — this was explicitly requested, so no extra confirmation gate is needed at merge time itself, only at the "which PRs / how" planning stage (this brainstorm).
* One single new branch carrying all ported changes (not one branch per PR), based on "全部把这些提交到...的新分支" (submit all of these to a new branch, singular).
* Commit granularity: one commit per ported PR (3 commits) for traceability.

## Decisions (confirmed with user)

* **Scope**: Include all 3 portable PRs — #2446 (stream corruption auto-recovery), #2461 (shutdown timer remaining-time display), #2460 (Windows Z/X/C speed shortcuts). Skip #2443 (superseded locally).
* **Merge mechanism**: Push branch → `gh pr create` (branch → `main`) → `gh pr merge --auto --squash`. GitHub auto-merges once required checks pass; keeps a PR audit trail.
* **Required checks**: Only the `Build` workflow's Android path needs to pass. Investigated the other 4 workflow files (`ios.yml`, `linux_x64.yml`, `mac.yml`, `win_x64.yml`) — they are `workflow_call`-only (triggered from a release flow), NOT run automatically on `push`/`pull_request`. Only `build.yml` (jobs: `quality`, `android`) actually runs on push/PR. So gating on "Build (Android)" is both what the user asked for and effectively the only workflow that will run anyway.

## Requirements (evolving)

* Create a new branch off current `origin/main` on `Chloemlla/PiliPlus`.
* Port #2446 (stream corruption auto-recovery) — pending scope confirmation, this is in.
* Port #2461 (shutdown timer remaining-time display) — pending scope confirmation, this is in.
* Port #2460 (Z/X/C speed shortcuts) — pending user decision.
* Skip #2443 — already implemented, more advanced version exists on `main`.
* Adapt `package:PiliPlus` → `package:pili_plus` import prefixes in all ported code (mechanical, not a real conflict).
* Do not run local Flutter/Gradle build or test commands (no local SDK — verification is source review + GitHub Actions only, per `piliplus-local-toolchain` memory).
* Push the branch, open a PR via `gh pr create` targeting `main`.
* Enable auto-merge (`gh pr merge --auto --squash`) gated on the `Build` workflow's `android` job succeeding.
* Monitor GitHub Actions status on the PR (poll, do not busy-wait synchronously).
* Report final CI status and merge result to the user.

## Acceptance Criteria

* [ ] New branch exists on `Chloemlla/PiliPlus` containing the agreed-upon ported PRs, each as a distinct, reviewable commit.
* [ ] Import prefixes adapted to `package:pili_plus` convention; no leftover `package:PiliPlus` references in ported files.
* [ ] No local Flutter/Gradle build/test executed.
* [ ] Branch pushed to `origin` (`Chloemlla/PiliPlus`).
* [ ] CI status monitored via `gh` (Actions runs / PR checks) until required workflows conclude.
* [ ] On green CI, branch is merged into `main` (method per decision above); on red CI, merge is withheld and failure is reported to the user instead of forced.
* [ ] Final report to user: which PRs were ported, which were skipped and why, CI outcome, merge outcome.

## Definition of Done

* Source changes reviewed against each upstream PR's diff (via `gh pr diff`).
* No local Flutter/Gradle build/test command executed.
* Branch pushed; CI triggered and monitored to completion.
* Merge into `main` only happens after required checks pass; if checks fail, task stops short of merge and surfaces the failure.

## Technical Approach

For each included PR: fetch `gh pr diff <n> --repo bggRGjQaUbCoE/PiliPlus`, hand-port the change into the corresponding file(s) in this repo, rewriting `package:PiliPlus` → `package:pili_plus` and reconciling with any local-only code the same file already has (e.g. `pl_player/controller.dart` already has heartbeat/other local changes possibly near the same regions). Commit each ported PR separately for traceability. Push the branch. Use `gh pr create` to open a PR into `main`, then `gh pr merge --auto --squash` to enable auto-merge gated on the `android` job of the `Build` workflow. Poll `gh pr checks`/`gh run watch` until conclusion. On success the PR merges automatically; on failure, stop short of merge and report which check failed with logs/links.

## Decision (ADR-lite)

**Context**: Upstream PRs can't be merged via GitHub's native merge/rebase because the fork has renamed its package (`PiliPlus` → `pili_plus`), so every file touched shows as conflicting at the text level even though the underlying logic is compatible.

**Decision**: Hand-port each selected PR's diff into the current codebase (following the pattern already used in `07-10-port-upstream-pr-2443`), rather than attempting `git cherry-pick`/`git merge` from `upstream`, which would fail or require the same manual conflict resolution anyway.

**Consequences**: Slightly more manual work per PR, but avoids noisy merge-conflict markers and produces clean, review-friendly commits. Requires care to correctly reconcile with any local-only code near the same lines.

## Out of Scope

* Merging unrelated upstream commits beyond the selected PRs.
* Re-implementing or double-porting #2443 (already superseded locally).
* Any local Flutter/Gradle build, test, or emulator run.
* Modifying unrelated in-flight local work (other active Trellis tasks' dirty files, if any exist at execution time).

## Technical Notes

* Upstream PRs considered: [#2443](https://github.com/bggRGjQaUbCoE/PiliPlus/pull/2443) (skip), [#2446](https://github.com/bggRGjQaUbCoE/PiliPlus/pull/2446), [#2461](https://github.com/bggRGjQaUbCoE/PiliPlus/pull/2461), [#2460](https://github.com/bggRGjQaUbCoE/PiliPlus/pull/2460).
* Related prior task: `.trellis/tasks/07-10-port-upstream-pr-2443/` — same porting pattern, same import-prefix caveat.
* Relevant memory: `piliplus-local-toolchain` (no local Android SDK / full VS — analyze+test only, packaging via CI).
* CI workflows: `.github/workflows/{build,ios,linux_x64,mac,win_x64}.yml`.
* No branch protection on `Chloemlla/PiliPlus:main` — merge can be done via `gh pr merge` or direct push once checks pass.
