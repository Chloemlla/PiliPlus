# PRD: Seal 状态面板跳过 launching

## Goal
点击「下载视频/音频」后，不再展示「正在启动/连接 Seal」阶段；面板仅保留：等待确认 → 进行中 → 完成（及失败/未安装等终态）。

## Behavior
- 默认（auto_start=false）：一点击即展示「等待在 Seal 中确认」，同时 startActivity 打开 Seal
- auto_start=true：一点击即展示「正在自动入队」/进行中路径
- 未安装 / 启动失败：仍弹错误/安装面板
- 不改变 L3 协议与后台监听

## Out of scope
- 去掉真正的 startActivity
- 改 Seal 端协议
