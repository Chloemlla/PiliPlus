# PiliPlus：扫码组件换华为 Scan Kit

## Goal

将 Android 扫码实现替换/切换为华为 HMS Scan Kit：  
文档：https://developer.huawei.com/consumer/cn/doc/HMSCore-Guides/android-0000001051075346

## Repo

`F:\Repositories\GitHub\PiliPlus`

## Current state

- Replaced CameraX + ZXing with HMS Scan Kit `scanplus` 2.15.0.301
- Camera: `QrScannerActivity` hosts Scan Kit `RemoteView` (QR only)
- Gallery: `QrBarcodeDecoder` uses `ScanUtil.decodeWithBitmap` + photo mode
- Flutter：`AndroidQrScanner` MethodChannel `pili_plus/android_qr_scanner` unchanged
- 主消费者：B 站网页扫码授权 `WebQrAuthController`
- Spec updated: intentional Scan Kit (not ML Kit / not ZXing)

## Requirements

- R1. Android 使用 HMS Scan Kit 做摄像头扫码与（如支持）图库识别
- R2. 保持 MethodChannel 契约稳定（`scanCamera` / `scanImage` 返回 String?），Flutter 层尽量不改
- R3. 无 GMS 设备可用；不强制 Google 组件
- R4. 权限仍按需申请 CAMERA
- R5. Web QR URL 校验与授权流程不变
- R6. 无本地 Flutter/Gradle 构建；CI 验证
- R7. 若需 Maven 仓库/依赖，声明式写入 gradle；CI 可解析

## Notes

- Scan Kit free/public SDK (`com.huawei.hms:scanplus`) resolves from `https://developer.huawei.com/repo/`
- **No `agconnect-services.json` / AGConnect plugin** required for basic camera + bitmap decode
- Removed CameraX / ZXing Core dependencies and `ZxingQrDecoder` / `QrFrameAnalyzer`
- Optional ZXing fallback not retained (full replace)

## Acceptance

- [ ] 扫码入口可识别 B 站网页登录二维码
- [ ] 图库识别仍可用（Scan Kit decodeWithBitmap）
- [ ] analyzer/CI 通过
