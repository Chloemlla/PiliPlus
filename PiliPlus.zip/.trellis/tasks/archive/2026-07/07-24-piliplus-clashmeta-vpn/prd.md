# PiliPlus ↔ ClashMeta VPN 自动适配

## Goal

用户同时安装 **PiliPlus** 与 **ClashMetaForAndroid**，在 Clash 开启 VPN 后，**无需手动配置访问控制或系统代理**，PiliPlus 网络请求自动由 Clash 处理；双方代码级检测联动，VPN 开/关时自动适配。

## Requirements

* R1. **仅 VPN 路径**：只做 TUN/VpnService 自动适配；不做「无 VPN 仅 mixed-port」自动发现。
* R2. 同时安装且 Clash VPN 运行时，PiliPlus 流量经 Clash，**零手动配置**。
* R3. Clash 访问控制伙伴放行：
  * `AcceptAll`：保持系统默认（已全局接管）。
  * `AcceptSelected`：VPN 建立时自动把已安装的 PiliPlus 包名并入 allow（含 `.debug` / `.dev`）。
  * `DenySelected`：绝不把 PiliPlus 伙伴包加入 disallowed。
* R4. PiliPlus 检测 Clash 安装 + `TRANSPORT_VPN` / 伙伴状态；VPN available/lost 时强制重建 Dio/HttpClient 连接池。
* R5. VPN 活跃时 **不叠加** 手动 `findProxy`（避免双重代理）；手动系统代理仅在无 VPN 或用户关闭自动适配时按原逻辑生效。
* R6. 默认开启自动适配；设置页提供状态展示 + 可选「禁用 Clash 自动适配」opt-out。
* R7. 覆盖本仓库已知包名：
  * PiliPlus: `com.chloemlla.piliplus` / `.debug` / `.dev`
  * Clash: `com.github.metacubex.clash` 及常见 suffix（`.meta` / `.alpha` 等，以 queries 列表为准）

## Acceptance Criteria

* [ ] 双 App 安装 + Clash AcceptAll 启 VPN → PiliPlus 无需任何代理/访问控制设置即可走 Clash
* [ ] Clash AcceptSelected 且用户未勾选 PiliPlus → 启 VPN 后仍自动允许 PiliPlus（已安装的 flavor）
* [ ] Clash DenySelected → PiliPlus 不会被自动排除
* [ ] Clash 停止 VPN → PiliPlus 连接池刷新；若用户开了手动代理则回退手动代理，否则直连
* [ ] 自动适配开启且 VPN 活跃时，忽略手动系统代理 host/port（防双重代理）
* [ ] 设置页可见：Clash 是否安装 / VPN 是否活跃 / 自动适配是否开启
* [ ] 用户关闭「自动适配」后行为与改造前一致（仅手动代理）
* [ ] 用户可见变更写入 `WhatsNewData`

## Definition of Done

* ClashMetaForAndroid 与 PiliPlus 双侧代码完成
* PiliPlus：不本地跑 Flutter/Gradle 全量构建；由 CI 验证
* analyzer/lint 无新增错误
* 提交并 push（两侧仓库）

## Technical Approach

### ClashMetaForAndroid

1. `PartnerApps`（或等价常量）：PiliPlus 包名列表。
2. `TunService` 访问控制分支合并伙伴包逻辑（见 R3）。
3. 扩展/新增可被伙伴调用的只读状态面：
   * 方案：exported ContentProvider 或将 Status 查询对白名单 package 开放；返回 `running`（VPN 是否在跑）。
   * 权限：自定义 permission 或 caller package allowlist，避免任意 App 读取。
4. 不暴露/不依赖随机 `listenHttp()` 端口给 PiliPlus（VPN-only 范围）。

### PiliPlus

1. Android `ClashCompatPlugin`（MethodChannel）：
   * `isClashInstalled`（`<queries>` 包可见性）
   * `isVpnActive`（`NetworkCapabilities.TRANSPORT_VPN`）
   * `queryClashRunning`（可选 Provider call，失败则仅靠 VPN 能力）
   * NetworkCallback：VPN 变化 → 事件到 Dart
2. `lib/http/init.dart`：
   * 自动适配开启且 VPN 活跃 → `enableSystemProxy` 逻辑跳过 findProxy
   * VPN/联动状态变化 → `_resetAdaptersForNetworkChange`
3. Pref：`clashAutoAdapt` 默认 `true`；设置项 + 状态文案。
4. `WhatsNewData` 增加本构建说明。

## Decision (ADR-lite)

**Context**: 需要零手动配置的双 App 联动；仅文档配置不够；StatusProvider 默认不可跨 App。

**Decision**:
1. 范围 = **仅 VPN 自动适配**（用户确认）。
2. 双侧代码改动按推荐架构（用户：全部按推荐）。
3. 优先级：`自动适配开启 + VPN 活跃` > 手动系统代理；关闭自动适配后手动代理恢复原语义。
4. UI：默认开 + 状态展示 + opt-out，无强制向导。

**Consequences**:
* 不支持“只开 Clash 本地端口、不开 VPN”的自动代理。
* 需处理 Android 11+ 包可见性与 ContentProvider 导出安全。
* AcceptSelected 热更新 allowed apps 通常需在建立 TUN 时生效（重启 VPN 或重建会话时保证正确）。

## Out of Scope

* 无 VPN 的 HTTP/mixed-port 自动发现
* 内嵌 Clash 内核到 PiliPlus
* 任意第三方 Clash 包全量兼容
* 订阅/节点/规则策略
* iOS / 桌面

## Technical Notes

* 任务目录: `.trellis/tasks/07-24-piliplus-clashmeta-vpn`
* Clash: `service/.../TunService.kt`, `StatusProvider.kt`, `Intents.kt`
* PiliPlus: `lib/http/init.dart`, `storage_pref.dart`, `extra_settings.dart`, android plugin
* 双仓库提交：PiliPlus + ClashMetaForAndroid

## Implementation Plan

* Step A: Clash 伙伴包访问控制 + 可查询 running 状态
* Step B: PiliPlus Android ClashCompat + NetworkCallback
* Step C: PiliPlus HTTP 层自动适配 + Pref/设置 UI + WhatsNew
* Step D: 提交 push；CI 观察（PiliPlus）
