# SyncClipboard Android：Shizuku 授权后不实时推送剪切板

## Goal

安卓端在 Shizuku 授权完成后，仍应将本机剪切板**实时推送到服务器**；当前不推送。

## Repo

`F:\Repositories\GitHub\SyncClipboard`（android/）

## Requirements

- R1. Shizuku 授权成功后注册/恢复剪贴板监听并 upload
- R2. 授权状态变化时重启相关 Service/监听（避免陈旧权限状态）
- R3. 推送与拉取对称；日志可诊断
- R4. 无本地全量构建；CI 成功

## Acceptance

- [ ] Shizuku 已授权 + 同步开启时，复制文本后服务器可见更新
- [ ] 撤销/重授 Shizuku 后行为正确
