# Android 通知中心视频进度条

## Goal

在 Android 系统通知中心 / 媒体控件中，为正在播放的视频（及共用 `NativeMediaService` 的音频页）显示可拖动的进度条：用户能看到当前进度，并从通知/系统媒体中心拖动 seek 跳转播放位置。

## What I already know

* 本分支已有 Android 原生媒体通知：`NativeMediaService`（`MediaSession` + `Notification.MediaStyle` 前台通知）。
* Flutter 侧桥接：`NativeMediaNotificationService` + `VideoPlayerServiceHandler`（`audio_handler.dart`）。
* 已推送字段：`positionMs`、`durationMs`、`playing`、`speed` 等；`PlaybackState` 已包含 `ACTION_SEEK_TO`，`MediaSession.Callback.onSeekTo` 已回传 Flutter `seek`。
* 位置更新路径：
  * 视频：`PlPlayerController` position stream → `videoPlayerServiceHandler.onPositionChange`
  * 音频页：`lib/pages/audio/controller.dart` position stream → 同上
* 疑似缺口：
  * `PlPlayerController.updateDuration` / 音频页 `stream.duration` **未**回写到 native 通知的 `durationMs`。
  * 若 `MediaItem.duration` 初始为 0 或过时，系统 MediaStyle **不会**画 seek/进度条（duration 必须 > 0）。
  * 直播 `live=true` 时 duration 被设为 `-1`（符合系统约定，无进度条）。
  * 每次 `onPositionChange` 都走完整 `updatePlayback` → 可能频繁 `startForeground` 刷新。

## Requirements

* 非直播媒体（视频优先；共用路径的音频页一并受益）在 Android 系统媒体通知中显示进度。
* 进度随播放位置更新（允许合理节流；播放中可依赖 MediaSession 插值减少刷新频率）。
* duration 已知且 > 0 时才展示 seek/进度；未知或直播不展示虚假进度。
* **必须可拖动 seek**：从通知 / 系统媒体中心拖动进度条触发 `onSeekTo` → Flutter `seek`，播放器跳到对应位置。
* OEM 策略：**标准 MediaSession + MediaStyle 路径**；在常见机型验证。不实现自定义 RemoteViews 进度条兜底。无法拖动的 OEM 保留快进/退按钮。
* 不回归现有通知动作（播放/暂停/快进退/上下项/视频扩展动作等）。

## Acceptance Criteria

* [x] 非直播视频播放且 duration > 0 时，系统媒体通知可见进度条。（代码：duration 回写 + MediaMetadata + ACTION_SEEK_TO 门控；设备 OEM 待手动验证）
* [x] 播放过程中进度随 position 推进（允许节流；暂停时停留）。（3s 节流 + pause 立即推送）
* [x] 从通知/系统媒体中心拖动进度条可 seek 到对应位置。（onSeekTo → Flutter seek + 乐观 position + 陈旧 tick 防护）
* [x] 真实 duration 更新后（初始 0 → 有效时长）进度条能出现/刷新，不一直缺失。
* [x] 直播通知不展示虚假总时长进度，也不提供误导性 seek。
* [x] 既有通知按钮与扩展动作不回归。
* [x] 音频页若走同一 `NativeMediaService` 路径，进度/seek 行为与视频一致（同源修复）。

## Definition of Done

* Dart 侧 duration/position 同步逻辑可测处补单测；native 以代码审查 + 手动验证说明为主
* `flutter analyze` / 相关 test 通过（本机无完整 Android 出包时以 analyze+test 为准）
* 行为变更必要时更新 README / improvements guide 一句说明
* 不引入自定义 RemoteViews 大改

## Technical Approach

**Approach A+B（推荐，已锁定）**：修通 MediaSession 进度/seek 数据管线 + 合理节流

1. **保证 duration > 0 写入 MediaMetadata**  
   在播放器真实 duration 更新时回写 `durationMs`（`PlPlayerController.updateDuration` / 音频页 duration stream → `audio_handler` → native）。
2. **保证 PlaybackState 可 seek**  
   非直播且 duration > 0 时声明 `ACTION_SEEK_TO`；position / speed / updateTime 正确；必要时 `setBufferedPosition`。
3. **Seek 闭环**  
   保持/加固 `MediaSession.Callback.onSeekTo` → Flutter `seek`；本地乐观更新 position，避免拖动后进度条回跳。
4. **节流**  
   播放中减少全量 `startForeground` 刷新频率；依赖 MediaSession 按 speed 插值推进进度条；状态切换/暂停/seek/元数据变更立即刷新。
5. **直播**  
   duration = -1，不声明可 seek 进度。

**不采用**：完整自定义 RemoteViews 进度条（Approach C）作为本任务 MVP。

## Decision (ADR-lite)

**Context**：需要通知栏可见且可拖动的进度；OEM 能力不一。  
**Decision**：走标准 MediaSession + MediaStyle；修 duration/position/seek 管线与节流；视频+共用路径音频一并受益；不做自定义布局兜底。  
**Consequences**：实现面小、与系统媒体中心一致；极少数 OEM 可能仍不显示/不可拖 seek，靠快进退按钮与后续专项兼容。

## Decision log

* **2026-07-24**：用户确认必须可拖动 seek。
* **2026-07-24**：用户确认 OEM 策略为「标准 MediaSession + 常见机型验证」；其余按推荐默认：共用 `NativeMediaService` 的音频页一并覆盖；直播无进度条；Approach A+B。

## Out of Scope

* 非 Android 平台
* 自定义 RemoteViews / 自绘通知进度条兜底
* 高能进度条 / 分段 / SponsorBlock 标记画在系统通知上
* 重做整套媒体通知 UI / 动作布局
* 为每家 OEM 做完整私有媒体中心适配

## Expansion notes (MVP choices)

1. **Future evolution**：后续若有强诉求再加 OEM 专项或自定义布局；本任务预留清晰 duration/position/seek 数据面即可。
2. **Related scenarios**：音频页同源；锁屏/蓝牙/车机媒体控件随 MediaSession 一并受益。
3. **Failure/edge**：duration 未知、直播、seek 竞态、completed、频繁 position 刷新导致耗电/卡顿 → MVP 内处理 duration 回写、直播禁用 seek、seek 乐观更新与节流。

## Open Questions

* （无阻塞项）

## Research References

* [`research/android-media-notification-progress.md`](research/android-media-notification-progress.md) — MediaStyle scrubber 条件、本仓库 duration 回写缺口、Approach B 文件清单

## Technical Notes

* 关键文件：
  * `android/app/src/main/kotlin/com/chloemlla/piliplus/NativeMediaService.kt`
  * `lib/services/native_media_notification_service.dart`
  * `lib/services/audio_handler.dart`
  * `lib/plugin/pl_player/controller.dart`
  * `lib/pages/audio/controller.dart`
* 现有：`ACTION_SEEK_TO`、`onSeekTo`、`METADATA_KEY_DURATION`、position 推送已部分存在。
* 根因优先：player 真实 duration 未回写 native → `duration<=0` 时 SystemUI 不画 scrubber。
* 次要：position 全量刷新可节流；`bufferedMs` 未 `setBufferedPosition`。
