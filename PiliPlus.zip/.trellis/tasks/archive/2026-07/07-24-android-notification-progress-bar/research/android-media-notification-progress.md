# Android Media Notification Progress / Seek Bar

## Summary

System MediaStyle progress/seek bars are driven by **MediaSession** metadata + playback state, not by `Notification.Builder.setProgress`. For this repo, the main MVP fix is ensuring `durationMs > 0` is always written when known, keep `ACTION_SEEK_TO`, and avoid over-refreshing the full foreground notification on every position tick.

## Official / common requirements for seek bar

A MediaStyle notification shows a scrubber when SystemUI can resolve:

1. `Notification.MediaStyle().setMediaSession(sessionToken)` is set
2. `MediaMetadata.METADATA_KEY_DURATION` is a **positive** duration (ms)
3. `PlaybackState` includes `ACTION_SEEK_TO`
4. `PlaybackState` has a valid position + `updateTime` (`SystemClock.elapsedRealtime()`)
5. Session is active; playback state is playing/paused/buffering (not none/error)

Notes:

* Live content conventionally uses duration `-1` → **no scrubber**
* Duration `0` or missing → **no scrubber**
* SystemUI may interpolate position while playing using `speed` and `updateTime`, so apps do **not** need 1Hz full notification rebuilds for a smooth bar
* `setBufferedPosition` improves buffered range UI where supported; not strictly required for seek enablement

## Why it often does NOT show

| Cause | In this repo? |
|-------|----------------|
| `duration <= 0` | **Likely**. `MediaItem.duration` from API may be 0/stale; player `stream.duration` updates are **not** pushed back to native |
| Live (`duration = -1`) | Expected for live rooms |
| Missing `ACTION_SEEK_TO` | Already present for all states in `NativeMediaService` |
| MediaStyle without session token | Already set |
| Using only `Notification.setProgress` without MediaSession | N/A (not used) |
| OEM SystemUI hides scrubber for some media types / compact view | Possible; MVP accepts button fallback |
| Over-frequent notification updates causing OEM throttle | Possible; `onPositionChange` currently full `updatePlayback` every tick |

## `Notification.setProgress` vs MediaStyle

* `setProgress` draws a generic determinate progress line and is **not** a seekable media scrubber
* Media apps should rely on MediaSession duration + PlaybackState; do **not** dual-drive with `setProgress` in MVP

## Position update frequency best practice

* On play/pause/seek/metadata/status change: **immediate** PlaybackState/metadata update
* While playing: either
  * rely on SystemUI interpolation (speed + updateTime), updating position every few seconds or on significant jumps; or
  * throttle to ~1s for session-only updates without rebuilding notification chrome every frame
* Prefer updating **MediaSession only** when only position changed; rebuild notification when title/art/actions/playing chrome changes

## Repo gap analysis

### Already good

* `NativeMediaService` binds MediaStyle to session token
* Writes `METADATA_KEY_DURATION` (live → `-1`)
* `PlaybackState` sets position, speed, `elapsedRealtime`, includes `ACTION_SEEK_TO`
* `onSeekTo` → Flutter `seek` with optimistic local position
* Flutter `onPositionChange` pushes `positionMs`

### Gaps to fix (MVP)

1. **Duration write-back**
   * `PlPlayerController.updateDuration` only updates local Rx; does not notify `videoPlayerServiceHandler`
   * Audio page `stream.duration` same gap
   * If initial `MediaItem.duration` is 0, scrubber never appears until metadata is fixed
2. **Seek enablement gating**
   * Optionally omit `ACTION_SEEK_TO` for live / unknown duration to avoid misleading scrubber
3. **Throttle / split updates**
   * Position-only path should avoid expensive art reload + full `startForeground` every tick when nothing else changed
4. **Buffered position**
   * `bufferedMs` is stored in state but not applied via `PlaybackState.setBufferedPosition`

## Feasible approaches

### Approach A — Fix MediaSession plumbing only

* Push real duration when player reports it
* Keep seek callback path
* Minimal files: `audio_handler.dart`, player/audio controllers, maybe small Kotlin guards

### Approach B — A + throttle / buffered position (Recommended MVP)

* Everything in A
* Throttle position updates or session-only refresh
* `setBufferedPosition` when buffered known
* Gate seek action for live/unknown duration

### Approach C — Custom RemoteViews scrubber

* Heavy OEM fallback; out of scope per PRD

## Recommended MVP (locked by PRD)

**Approach B**, scoped:

1. Dart: add duration change bridge → native `durationMs`
2. Kotlin: ensure metadata/playback refresh when duration becomes valid; set buffered position; avoid useless full rebuilds on pure position ticks if easy
3. Keep seek path; optimistic position on seek
4. Live: no scrubber
5. Manual verify on common OEMs; no custom layout

## Concrete files

* `lib/plugin/pl_player/controller.dart` — duration update → service handler
* `lib/pages/audio/controller.dart` — same for audio page
* `lib/services/audio_handler.dart` — `onDurationChange` / metadata+playback sync; position throttle
* `android/.../NativeMediaService.kt` — buffered position; optional session-only update; seek gating
* tests around handler duration/position mapping if practical

## Edge cases

| Case | Expected |
|------|----------|
| Live | duration -1, no seek bar |
| Duration unknown (0) | no seek bar until known |
| Seek from notification | player jumps; bar follows; no long snap-back |
| Pause | bar frozen at position |
| Completed | stopped/paused at end; no bogus live progress |
| Speed ≠ 1 | PlaybackState speed set so SystemUI interpolates correctly |
| OEM no scrubber | transport buttons still work |

## Verification notes (device)

* Play non-live video with known duration → expanded media notification shows scrubber
* Drag scrubber → playback position changes
* Pause → bar stops
* Switch quality / reload if duration revises → bar remains valid
* Enter live room → no scrubber
