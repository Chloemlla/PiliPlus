# 修复音频控制器 unnecessary_this 警告

## Goal

移除 `lib/pages/audio/controller.dart` 中多余的 `this.` 限定符，消除 Dart analyzer 的 `unnecessary_this` 提示，同时保持现有行为不变。

## Requirements

* 将 `this.position.value` 改为 `position.value`。
* 不修改音频播放、心跳上报或其他业务逻辑。

## Acceptance Criteria

* [ ] `lib/pages/audio/controller.dart:428` 不再包含多余的 `this.` 限定符。
* [ ] 变更仅涉及目标表达式，语义保持不变。
* [ ] 不在本地运行 Flutter、Gradle、构建或测试命令。

## Definition of Done

* 通过代码差异和目标文本检查验证修改。
* 仅提交本任务修改的源文件，不包含工作区现有的其他改动。
* 提交并推送到当前分支。

## Technical Approach

直接移除实例成员访问前不必要的 `this.`，使用 Dart 的隐式成员解析。

## Out of Scope

* 其他 analyzer 提示。
* 音频控制器重构。
* 本地 Flutter、Gradle、构建或测试执行。

## Technical Notes

* 目标文件：`lib/pages/audio/controller.dart`
* Analyzer 规则：`unnecessary_this`
* 用户要求所有实际构建和测试仅在 GitHub workflow 中执行。
