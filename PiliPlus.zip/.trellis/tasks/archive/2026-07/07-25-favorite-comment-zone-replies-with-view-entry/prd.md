# Favorite comment zone replies with view entry

## Goal
在评论区支持收藏评论，并提供明确的收藏查看入口。

## What I already know
* 本地 `GStorage.reply` Hive/MMKV box + `ReplyCacheStore` 已存在
* 设置项 `SettingBoxKey.saveReply` / `Pref.saveReply`（Pref 默认 true；`GStorage.init` 打开 box 时 defaultValue:false — 不一致）
* 评论 morePanel 仅在 `kDebugMode` 下有 save/remove local
* `MyReply` 页面已实现列表/导入导出，路由 `/myReply` 已注册
* 我的页已有 `Get.toNamed('/myReply')` 入口（需确认是否可见/文案）

## Requirements
* 评论 more 菜单提供「收藏评论 / 取消收藏」正式入口（非仅 debug）
* 收藏写入本地 reply store；取消删除
* 提供查看入口：我的页等可达「收藏的评论」/「我的评论」
* 打开 box 与设置默认一致，确保开启后可用
* 禁止本地 flutter build/test；用 gh CI 验证

## Acceptance Criteria
* [ ] 评论区可收藏/取消收藏
* [ ] 有明确查看入口
* [ ] 列表可展示已收藏评论并可跳转源内容
* [ ] CI green via gh

## Out of Scope
* 服务端 bilibili 评论收藏 API（本地收藏）
* 非评论收藏夹
