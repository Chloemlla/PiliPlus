# 修复首装开源声明页审查问题

## Goal
修复首装「开源声明与第三方鸣谢」链路在审查中发现的全部问题：升级误弹、返回拦截失效、启动页竞态、重试脆弱、双重安全区留白、关于页关闭语义不当，并顺带收敛相关 onboarding 稳定性。

## What I already know
* 功能已落地：`OssNoticePage` / `OssNoticeData` / `FirstLaunchOssNoticeService` / About 入口 / 启动顺序 OSS → 改进说明 → Android 权限。
* 最近已修过「开始使用不回首页」：`maybePop` → `pop`，`onFinished` 只 markSeen，下一步在 `push` 返回后串联。
* 自定义 `popScope` 在 `initState` 用 `Get.routing.route as ModalRoute` 注册；OSS/改进页却是 `Navigator.push(MaterialPageRoute)`，不是 Get 路由。
* 三个 first-launch flag 均默认 `false`，无升级迁移：老用户升级会被当成首装。
* `CrashReportStartupGate` 与 OSS/Improvements/Permission gate 同帧抢 `Get.key` navigator，无互斥。
* OSS 页 `SafeArea` + 内部 `viewPadding` 叠加。
* About `openManual` 默认 `markAsSeen: true`，手动再看也走强制引导返回语义。
* 仓库禁止本地跑 Flutter/Gradle；改完需提交并 push。

## Assumptions (validated as recommended decisions)
* 「第一次安装」= 干净安装；升级用户不应自动弹出 OSS/改进说明/权限引导。
* 启动冲突时 **崩溃报告优先**（安全信息不能被 onboarding 压住），onboarding 等崩溃页关闭后再跑。
* 鸣谢清单保持 curated（不扫完整传递依赖）；本任务只修明显错误/误导项，不做全量 pubspec 对齐。
* 不引入重型 onboarding 框架；以最小协调层串行启动对话框即可。

## Open Questions
* （无阻塞项）以上推荐方案按审查结论直接锁定；若用户反对某条，再回改 PRD。

## Requirements

### R1 升级用户不误弹
1. 引入一次性 first-launch flag 迁移（冷启动 / 首次 `maybeShow` 前执行）。
2. 当 `firstLaunchOssNoticeSeen` 未写入，且判定为 **returning user** 时：
   * 写入 `firstLaunchOssNoticeSeen = true`
   * 写入 `firstLaunchImprovementsGuideSeen = true`（避免只跳过 OSS 后仍弹改进说明）
   * 若 `androidFirstLaunchPermissionsRequested` 未写，也写 `true`（避免升级后突然弹权限理由对话框）
3. returning user 判定（任一满足即可）：
   * 已登录账号存在（Accounts / userInfo 有有效缓存）
   * `setting` 中除 first-launch 相关 key 外仍有其他 key
   * `historyWord` / `localCache` / `watchProgress` 任一非空
   * 已有 `firstLaunchImprovementsGuideSeen` 或 `androidFirstLaunchPermissionsRequested` 为 true
4. 真正的新装（存储近空、无账号、无历史）继续自动弹出。
5. 迁移必须幂等，不覆盖用户后续手动重置（若将来提供重置）。

### R2 修复 PopScope / 系统返回
1. onboarding 全屏页（OSS、改进说明）的返回拦截必须绑定 **当前 ModalRoute**，禁止依赖 `Get.routing.route`。
2. 方案（推荐）：onboarding 页改用 Flutter material `PopScope`（这些页本身是 `MaterialPageRoute`）；或把自定义 `PopScope` 改为在 `didChangeDependencies` 用 `ModalRoute.of(context)` 注册并正确 unregister。
3. 首装 `markSeenOnClose=true` 时：系统返回 = 完成并 markSeen + force-pop；不能 no-op，也不能只 pop 不 mark。
4. 关于页手动打开 `markSeenOnClose=false` 时：允许系统返回直接关闭。

### R3 启动对话框串行协调
1. 新增轻量协调（可放在独立 service 或现有 first-launch service）：
   * 保证同一时刻只有一个启动全屏/对话框序列在跑。
   * 优先级：`CrashReportStartupGate` > OSS notice > improvements guide > Android permissions。
2. Crash 页展示期间，OSS/improvements/permissions **不得 push**。
3. Crash 页关闭后，再按 flag 执行后续 first-launch。
4. 保持现有「OSS 完成后才 improvements；improvements 完成后才 permissions」顺序。

### R4 Navigator 重试加强
1. `_scheduleRetry` 不能只赌下一帧一次。
2. 在 navigator 未就绪时：有限次 post-frame 重试（例如最多 30 帧 / 约 0.5–1s 量级），就绪即 show；超限后停止并 debugPrint。
3. 三个 first-launch service + crash gate 中同类逻辑尽量复用同一 helper，避免三份漂移。

### R5 双重安全区
1. OSS 页去掉 `SafeArea` 与 `viewPadding` 双算。
2. 推荐：保留 `SafeArea`，列表/底栏 padding 只用固定间距，不再叠加 `viewPadding`；或反过来不用 `SafeArea` 而统一用 padding。改进页若有同样模式一并修。

### R6 关于页手动打开语义
1. About「开源声明与第三方鸣谢」调用 `openManual(markAsSeen: false)`（或改 `openManual` 默认值为 false，About/调用方明确传参）。
2. 手动打开：按钮文案「关闭」，系统返回可 pop，不强制 markSeen（若此前未见过，也不因手动打开单独改首装策略——保持显式参数）。
3. 改进说明 About 入口同步为手动浏览语义，避免一边松一边紧。

### R7 鸣谢数据小修（有限范围）
1. 修正明显误导项（错误 URL、含糊到无用的协议描述若可快速确认）。
2. 不新增完整直接依赖枚举；不扫 pub-cache。
3. 保留页面说明：这是精选清单，非完整传递依赖树。

### R8 代码结构
1. 尽量抽 `FirstLaunchCoordinator` / `StartupDialogGate` 一类最小 API，减少 OSS/Improvements/Permission 三份复制逻辑（running flag、retry、navigator 获取）。
2. 不改业务 UI 风格；不重做页面视觉。
3. 本地不跑 Flutter/Gradle。

## Acceptance Criteria
* [ ] 干净新装：自动弹出 OSS → 改进说明 →（Android）权限；完成后不再自动弹。
* [ ] 升级老用户（已有账号/设置/历史等）：不自动弹 OSS、改进说明、权限引导。
* [ ] 首装 OSS/改进页：系统返回会完成并关闭，不会卡死在页上。
* [ ] 有待展示崩溃报告时：先崩溃页，关闭后再走 first-launch；不会两页互压。
* [ ] navigator 晚就绪时仍能弹出（有限重试），不会静默永久跳过。
* [ ] OSS/改进页无双重安全区导致的异常留白。
* [ ] About 手动打开可系统返回关闭，不走强制引导语义。
* [ ] 关于页入口仍可打开 OSS 与改进说明。
* [ ] 代码提交并 push。

## Definition of Done
* 审查列出的 High/Medium 项全部落地；Low 中 About 语义与双重 padding、数据小修完成。
* 相关 first-launch 服务行为一致、可追踪。
* 未引入本地 Flutter/Gradle 运行。
* Trellis 任务 PRD 与实现一致；提交信息清晰。

## Technical Approach

### A. Returning-user migration
* 新增 `lib/services/first_launch_migration.dart`（或放 storage 初始化后调用）。
* API: `FirstLaunchMigration.ensureSeenFlagsForReturningUsers()`。
* 在 `GStorage.init()` 之后、`FirstLaunchOssNoticeService.maybeShow()` 之前调用；`maybeShow` 入口也可防御性再调一次（幂等）。

### B. Route-correct PopScope
* Prefer：onboarding 两页改用 `package:flutter/material.dart` 的 `PopScope`（与 `MaterialPageRoute` 匹配）。
* 自定义 `common/widgets/flutter/pop_scope.dart` 留给 Get 页面；不要在 Material 全屏 onboarding 上继续误绑 `Get.routing.route`。

### C. Startup serialization
* 新增 `StartupOverlayCoordinator`：
  * `bool get isBusy`
  * `Future<T?> runExclusive<T>(Future<T?> Function() job, {int priority})`
  * 或更简单：`await CrashReportStartupGate` 完成信号 + first-launch 侧 `waitUntilIdle`。
* 最小实现也可：
  1. crash gate push 前设 `StartupOverlayCoordinator.crashActive = true`，pop 后 false 并 `notify`；
  2. first-launch `maybeShow` 若 crashActive 则挂起/重试。
* 不改 crash 页 UI。

### D. Retry helper
* `NavigatorRetry.run(Future<void> Function(NavigatorState nav) action, {int maxFrames = 30})`
* OSS / improvements / permissions / crash gate 共用。

### E. Padding
* `oss_notice_page.dart`、`improvements_guide_page.dart`：去掉 list/footer 的 `padding.left/right/bottom` viewPadding 叠加。

### F. About
* `lib/pages/about/view.dart`：两处 manual open 传 `markAsSeen: false`。

## Decision (ADR-lite)
**Context**: 审查发现功能主路径可用，但升级误弹、返回绑定、启动竞态属于真实用户必踩问题。  
**Decision**: 以「返回用户迁移 + Material PopScope + 启动串行 + 共享重试」为主修复；鸣谢清单只做有限修正。  
**Consequences**: 老用户升级安静；新装体验完整；后续若再加 onboarding 步骤可挂到同一 coordinator。

## Out of Scope
* 自动生成完整第三方 license 树 / OSS licenses 包扫描
* 重做 onboarding UI 视觉
* 本地 Flutter/Gradle 构建与真机验证（由 CI / 用户侧验证）
* 重置「重新观看引导」设置项（除非实现中顺手极低成本）

## Implementation Plan
1. PRD 锁定（本文件）
2. 迁移 + coordinator + retry helper
3. 修 OSS/Improvements 页 PopScope 与 padding
4. 串接 crash gate 与 first-launch
5. About 手动打开语义
6. 鸣谢数据小修
7. 自检 diff / 提交 push

## Technical Notes
* 关键文件：
  * `lib/services/first_launch_oss_notice_service.dart`
  * `lib/services/first_launch_improvements_guide_service.dart`
  * `lib/services/android_first_launch_permission_service.dart`
  * `lib/pages/onboarding/oss_notice_page.dart`
  * `lib/pages/onboarding/improvements_guide_page.dart`
  * `lib/pages/onboarding/oss_notice_data.dart`
  * `lib/pages/about/view.dart`
  * `lib/pages/setting/pages/crash_report.dart`（StartupGate）
  * `lib/main.dart`（gate 挂载顺序，必要时）
  * `lib/utils/storage_key.dart` / `lib/utils/storage.dart`（若迁移挂 init）
  * `lib/common/widgets/flutter/pop_scope.dart`（参考，尽量不破坏 Get 页）
* 约束：`AGENTS.md` — 不写 super file；本地不跑 Flutter/Gradle；完成后 auto commit + push。
* 相关既有任务：`07-17-first-launch-oss-notice`、`07-17-fix-onboarding-return-home`。
