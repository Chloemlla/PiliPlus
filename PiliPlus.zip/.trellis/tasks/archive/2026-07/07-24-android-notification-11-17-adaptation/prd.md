# Android notification 11–17 adaptation

## Goal

Align PiliPlus media notification / MediaSession FGS path with Project-Lumen Android 11–17 (Vivo) adaptation notes for notification center UX on API 30–37.

## Already present

* `mediaPlayback` FGS type + `FOREGROUND_SERVICE_MEDIA_PLAYBACK`
* `POST_NOTIFICATIONS` + first-launch gate
* Immutable PendingIntents for notification content/actions
* MediaStyle + MediaSession scrubber (duration write-back, SEEK_TO gating)

## Gaps addressed (2026-07-24)

* Android 12+: `FOREGROUND_SERVICE_IMMEDIATE` on media notification
* Channel: silent LOW, no badge/sound/vibration; description notes 11–17 mediaPlayback FGS
* Docs: `docs/android-vivo-adaptation.md` section 7b

## Acceptance

* [x] Media FGS notification not delayed on API 31+ when possible
* [x] Channel remains silent transport channel
* [x] Existing seekable progress / PendingIntent / FGS type contracts preserved
* [x] Adaptation notes updated

## Out of Scope

* Custom RemoteViews scrubber
* OEM-private media center plugins
* Seal download path
