# Beautify app UX — Seal 下载状态面板

## Goal

美化 Android 委托 Seal 下载时的自有状态面板（`lib/utils/seal_download_utils.dart` 内 `_SealStatusPanel`），在不改 L3 协议与状态机语义的前提下，提升视觉层次、阶段可读性与操作清晰度。

## Decision

采用 **工具型收紧（Approach 1）**：
* 去掉 oversized 圆形 hero 与重阴影营销风
* 改为紧凑状态卡：左侧状态图标 + 标题/说明、三步进度（确认 → 下载 → 完成）、主次按钮分区
* 保留轻量进场动画与终态反馈；去掉持续脉冲放大

## Requirements

* 仅改 Seal 面板 UI（`_SealStatusPanel` 及相关私有辅助），不改 MethodChannel / phase 映射 / 协议
* busy：展示步骤轨 + 明确提示；保留「后台等待」
* completed：有 contentUri 时 打开/分享 主次分明；否则提示去 Seal 查看
* notInstalled：安装为主按钮，关闭为次
* failed/rejected/canceled：单一确认动作
* 使用 Material 3 ColorScheme + `Style` 圆角/间距；圆角 ≤ 18（对齐 bottomSheet/dialog）
* 文案业务含义不变（可微调措辞）
* 不本地跑 Flutter/Gradle；改完 commit + push

## Acceptance Criteria

* [ ] 面板信息层级：状态图标 / 标题 / 说明 / meta / 步骤 / 动作 分区清晰
* [ ] busy 阶段有步骤指示（确认 / 下载 / 完成）而非仅 indeterminate bar
* [ ] 终态操作主次分明
* [ ] L3 状态机与按钮回调语义不变
* [ ] commit + push

## Out of Scope

* Seal 协议、Native bridge、autoStart 逻辑
* 其它页面 UX
* 本地 Flutter/Gradle

## Technical Notes

* 主文件：`lib/utils/seal_download_utils.dart`
* 样式：`lib/common/style.dart`
