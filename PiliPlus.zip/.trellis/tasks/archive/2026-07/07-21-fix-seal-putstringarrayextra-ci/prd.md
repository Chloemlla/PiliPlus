# Fix Seal putStringArrayExtra CI compile failure

## Goal

恢复 GitHub Actions `Release Android` → `Generate Baseline Profile`：当前在 `:app:compileNonMinifiedReleaseKotlin` 因 `SealDownloadChannel.kt` 使用不存在的 `Intent.putStringArrayExtra` 编译失败，导致整条 Build workflow 红。

## What I already know

* Failed run: https://github.com/Chloemlla/PiliPlus/actions/runs/29756775170
* Job: `Release Android` / step `Generate Baseline Profile`
* Analyze and Test job **success**（Dart 侧无问题）
* Kotlin error:
  * `e: file://.../SealDownloadChannel.kt:109:13 Unresolved reference 'putStringArrayExtra'.`
* Introduced by `eba7cb857 fix(seal): unblock invoke delay and support multi-P batch URLs`
* Android `Intent` API:
  * **No** `putStringArrayExtra`
  * Correct: `putExtra(String name, String[] value)` 或 `putStringArrayListExtra` for `ArrayList<String>`
* Prior related tasks (`07-16-fix-android-emulator-runner-ci`, `07-16-fix-baseline-profile-launch-crash`) already fixed emulator target / launch; **this failure is pure compile**, before instrumented tests run.

## Assumptions

* Seal multi-URL protocol accepts `String[]` via `Intent.putExtra("urls", String[])` (standard Bundle string-array extra).
* No Dart change required; method channel already sends `urls: List<String>`.

## Requirements

* Replace invalid `putStringArrayExtra` with valid `Intent` API that stores a `String[]` under `EXTRA_URLS`.
* Keep single-URL `EXTRA_URL` compat path.
* Keep multi-URL batch behavior intended by previous seal task.
* Do not change baseline-profile emulator config unless a new failure appears after compile succeeds.

## Acceptance Criteria

* [x] `SealDownloadChannel.kt` compiles: no `putStringArrayExtra` reference
* [x] Multi-URL still put under `EXTRA_URLS`; first URL still under `EXTRA_URL`
* [x] Change committed and pushed so GHA re-runs (`95fc52b52`, run 29758424237)
* [x] CI progresses past `:app:compileNonMinifiedReleaseKotlin` — full Build success on 29758424237 (baseline + APK + release + uploads)

## Definition of Done

* One-line (or minimal) Kotlin fix landed on `main` (or branch then merge as usual).
* No unrelated files modified.
* Task can be archived after CI progress verified.

## Out of Scope

* Re-tuning emulator / BaselineProfileGenerator unless compile fix unmasks a different failure.
* Changing Seal app-side protocol.
* Local Flutter/Gradle Android builds (no full Android SDK on this machine).

## Technical Approach

```kotlin
// before (invalid)
putStringArrayExtra(EXTRA_URLS, urls.toTypedArray())

// after
putExtra(EXTRA_URLS, urls.toTypedArray())
```

## Decision (ADR-lite)

**Context**: CI fails at Kotlin compile with unresolved `putStringArrayExtra`.  
**Decision**: Use `Intent.putExtra(name, String[])` which is the real API for string arrays.  
**Consequences**: Restores multi-P batch extras without changing Dart or Seal package id resolution.

## Technical Notes

* File: `android/app/src/main/kotlin/com/chloemlla/piliplus/SealDownloadChannel.kt:109`
* Related: `.trellis/tasks/07-20-fix-seal-invoke-blank-delay-and-multi-p-batch-download/`
* Verify via GHA only; local analyze/test already green on failed run.
