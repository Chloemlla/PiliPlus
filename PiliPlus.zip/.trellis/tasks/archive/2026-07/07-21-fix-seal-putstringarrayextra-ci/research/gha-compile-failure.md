# GHA compile failure: putStringArrayExtra

## Failed run
- Run: https://github.com/Chloemlla/PiliPlus/actions/runs/29756775170
- Commit: eba7cb857
- Job: Release Android / Generate Baseline Profile
- Duration to fail: ~4m45s of gradle inside emulator-runner

## Error
```
> Task :app:compileNonMinifiedReleaseKotlin FAILED
e: .../SealDownloadChannel.kt:109:13 Unresolved reference 'putStringArrayExtra'.
```

## Root cause
Android `Intent` has no `putStringArrayExtra`. String arrays use:
`putExtra(String name, String[] value)`.

Introduced when multi-P batch added `EXTRA_URLS` in eba7cb857.

## Fix
```kotlin
putExtra(EXTRA_URLS, urls.toTypedArray())
```
Commit: 95fc52b52

## Verify run
https://github.com/Chloemlla/PiliPlus/actions/runs/29758424237
Analyze and Test: success. Generate Baseline Profile still running longer than prior compile-fail window → compile fix likely OK.
