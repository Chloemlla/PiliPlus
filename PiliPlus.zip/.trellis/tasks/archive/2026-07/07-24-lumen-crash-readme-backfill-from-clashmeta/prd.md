# lumen-crash README：反补 ClashMeta 冷启动教训

## Goal

根据 ClashMeta 修复开屏/冷启动闪退的 commit 历史，更新：

- `F:\Repositories\GitHub\Project-Lumen\lumen-crash\README.md`
- `F:\Repositories\GitHub\Project-Lumen\lumen-crash\README.zh-CN.md`

避免接入后直接崩溃/闪一下退出。

## Content to add (from ClashMeta)

1. Application：`attachBaseContext` 中 **install 必须是 super 后第一件宿主工作**
2. Activity：pending report gate 在主题/design/main 之前
3. **不要 finish 唯一 launcher** 再启动崩溃页（部分 ROM 闪退无界面）
4. 已发布 AAR API：`install` 总有；`installSafely`/`LumenCrashGate` 以 AAR 为准
5. 多 Activity 宿主：专用 Report Activity + 所有入口 gate
6. 崩溃页 setContent 也要 fail-soft
7. 与现有 Seal 混淆白屏教训并列（两类根因）

## Acceptance

- [ ] 中英 README 同步
- [ ] 含错误顺序 anti-pattern 与正确顺序
- [ ] CI 文档相关 job 不失败
