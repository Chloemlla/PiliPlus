# Port upstream PR 2443 changes

## Goal

Use GitHub CLI to inspect upstream PR #2443 and port its audio playback progress reporting change into this repository without disturbing unrelated local work.

## Requirements

* Port the single upstream commit `27179631c7491ba93a53586a18175d71b8a904a2` (`feat: report audio progress`).
* Add heartbeat reporting for UGC items played through `AudioController`.
* Report periodic playback progress, status transitions, and completion.
* Reset heartbeat throttling when switching parts or playlist entries.
* Adapt upstream imports and code to the current repository conventions.
* Preserve all pre-existing uncommitted crash-report changes and exclude them from this task's commit.
* Do not run Flutter or Gradle locally; verification is limited to source review and GitHub Actions after push.
* Commit and push the completed port as requested by the repository instructions.

## Acceptance Criteria

* [ ] The upstream PR's intended audio progress reporting behavior exists in the current branch.
* [ ] Only the intended audio controller file and Trellis bookkeeping for this task are changed by this work.
* [ ] Existing unrelated dirty files are unchanged and uncommitted by this task.
* [ ] The resulting commit is pushed to `origin/main`.
* [ ] Available GitHub workflow results are checked after push without running local Flutter/Gradle commands.

## Definition of Done

* Source changes are reviewed against the upstream patch.
* No local Flutter or Gradle build/test command is executed.
* A focused commit is created and pushed.
* CI status is reported to the user.

## Technical Approach

Inspect the PR and patch with `gh pr view` and `gh pr diff`, then apply the equivalent change to the current `AudioController`. Preserve the upstream heartbeat thresholds and event hooks while adapting the package import prefix from the upstream `package:PiliPlus` form to this repository's `package:pili_plus` convention.

## Decision (ADR-lite)

**Context**: The working tree contains unrelated crash-report work, and the upstream commit was authored against a slightly different import-path convention.

**Decision**: Port the one-file patch manually from `gh pr diff` instead of switching branches or applying a broad merge. Commit only the audio controller change.

**Consequences**: This avoids disturbing unrelated work and keeps the commit focused, but requires a direct source comparison with the upstream patch.

## Out of Scope

* Merging other upstream commits or the entire upstream branch.
* Changing heartbeat API behavior beyond PR #2443.
* Modifying or committing the existing crash-report work.
* Running local Flutter, Gradle, or device tests.

## Technical Notes

* Upstream PR: <https://github.com/bggRGjQaUbCoE/PiliPlus/pull/2443>
* Upstream commit: `27179631c7491ba93a53586a18175d71b8a904a2`
* Upstream patch changes only `lib/pages/audio/controller.dart` (+57 lines).
* Existing dirty paths are under `lib/services/crash/`, `lib/utils/utils.dart`, and `test/services/crash/`.
