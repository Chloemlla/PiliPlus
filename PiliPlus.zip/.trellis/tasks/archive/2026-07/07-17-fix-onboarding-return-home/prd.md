# Fix onboarding return to home

## Problem
After tapping 「开始使用」 on the first-launch improvements guide, the app stays on the guide and does not return to the main UI.

## Root cause
1. First-launch pages set `PopScope(canPop: false)` while `markSeenOnClose` is true.
2. `_completeAndClose()` uses `Navigator.maybePop()`, which respects `canPop` and therefore does nothing.
3. First-launch `onFinished` also starts the next startup step before the current route is popped, which can stack routes (OSS under improvements).

## Fix
1. Force-pop the current onboarding route after finish/skip (`pop`, not `maybePop`).
2. Keep `onFinished` limited to mark-seen for first-launch auto show.
3. Run the next startup step only after `navigator.push` returns (route already closed):
   - OSS done -> improvements guide
   - improvements done -> Android permission flow
4. Preserve About manual reopen behavior.

## Acceptance
- 「开始使用」 / skip / continue leave the onboarding page and reveal the main app.
- First-launch order remains: OSS notice -> improvements guide -> Android permissions.
- About manual open still works and still marks seen by default.
- No local Flutter/Gradle runs.
