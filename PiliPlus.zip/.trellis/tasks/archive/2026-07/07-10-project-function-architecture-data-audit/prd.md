# PiliPlus 功能、架构与数据库审查报告

## Goal

基于最新 `main` 静态审查 PiliPlus 的关键功能链路、项目架构和数据库/本地持久化问题，生成一份完整、冷静、证据驱动的中文 Markdown 报告。

## Requirements

- 使用仓库内 `fuck-my-shit-mountain` 审查模板和严重程度/置信度/证据规则。
- 审查深度为 full，但范围严格限定为：关键功能正确性、架构边界、数据库/本地持久化与数据完整性。
- 报告语言为中文，输出格式为 Markdown。
- 每项发现包含精确文件与行号、失败场景、最小修复、长期修复、回归测试建议和工作量。
- 区分 Confirmed 与 Suspected，不修改应用源码、测试、配置或依赖。
- 输出文件为仓库根目录 `audit-report-PiliPlus-2026-07-10.md`。
- 运行审查报告 linter；不得运行本地 Flutter、Dart、Gradle、构建或测试命令。
- 仅提交报告文件，随后推送到 `origin/main`。

## Acceptance Criteria

- [ ] 报告包含 Executive Summary、Project Map、Coverage Matrix、Finding Statistics、Top Risks、Detailed Findings、Recommended Fix Order、Quick Wins。
- [ ] 报告包含 Architecture 与 Data Integrity 对应章节，并覆盖关键功能正确性。
- [ ] 每项发现满足审查模板的全部字段要求。
- [ ] 严重程度统计与详细发现一致。
- [ ] `report_lint.py --modes architecture,data-integrity` 通过。
- [ ] 未运行任何本地 Flutter/Gradle 构建或测试。
- [ ] 只提交并推送审查报告，不混入其他工作区改动。

## Definition of Done

- 报告文件已生成并通过专用报告 linter。
- Git 工作区除报告外无未识别改动。
- 报告已使用符合仓库历史风格的 `docs:` 提交并推送。

## Technical Approach

以 `rg --files` 建立项目地图，静态追踪启动、GetX 页面/控制器、HTTP/gRPC、播放器/音频、Hive/MMKV、账户与设置导入导出、WebDAV 备份、加密 sidecar 文件。使用 PowerShell 构建直接 import 双向依赖图，并对存储写入调用、迁移标记、批量写入、schema 校验和错误传播进行针对性搜索。所有结论以当前 `main` 的精确源码为证据，不运行应用。

## Decision (ADR-lite)

**Context**: 用户写了 `full`，同时明确“只审查项目功能架构数据库问题”。

**Decision**: 将 `full` 解释为审查深度，而不是扩大到所有 25 个模式；正式选择 `architecture + data-integrity`，并把关键功能正确性归入 Stability/功能链路分析。

**Consequences**: 报告不会评价安全、性能、可访问性、供应链或发布流程本身；仅在它们直接影响持久化迁移和功能正确性时作为证据引用。

## Out of Scope

- 修复任何发现。
- 修改 Flutter/Dart/Android/iOS 应用源码、测试、依赖或 CI。
- 本地运行 Flutter、Dart、Gradle、构建、分析或测试。
- 安全、性能、可访问性、供应链等独立维度审计。

## Technical Notes

- 审查基准：`main` / `origin/main`，初始最终复核 HEAD 为 `13fbb9884`。
- 项目约 1565 个非审查工具文件，其中约 1303 个 Dart 文件；详细检查排除了生成 gRPC/序列化文件和复制的 Flutter 框架实现。
- 已检查核心文件：`lib/main.dart`、`lib/router/app_pages.dart`、`lib/http/**`、`lib/pages/common/**`、`lib/pages/audio/controller.dart`、`lib/pages/video/**`、`lib/utils/storage*.dart`、`lib/utils/accounts/**`、`lib/utils/android/android_mmkv*`、`android/app/src/main/java/.../AndroidMmkv.java`、WebDAV 与 crash persistence、相关测试和 GitHub workflow。
- 静态 import 图确认 47 个直接双向依赖对（排除生成代码和复制的 Flutter 源码）。
- `GStorage` 被 61 个文件引用，其中 50 个位于 `lib/pages/**`；直接持久化变更调用分散在大量 UI/控制器路径。
