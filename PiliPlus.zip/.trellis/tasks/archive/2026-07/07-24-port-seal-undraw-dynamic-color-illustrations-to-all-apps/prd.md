# Port Seal undraw 动态色插画到所有当前应用

## Goal

参考 `F:\Repositories\GitHub\Seal` 的 **undraw 动态色插画**实现，为当前所有相关项目接入同类能力：空状态 / 欢迎 / 关于等场景使用 Material 动态色（主题色）填充的 undraw 风格矢量插画。

## Reference (Seal)

| 组件 | 路径 |
|------|------|
| 对象壳 | `app/.../ui/svg/__DrawableVectors.kt` → `object DynamicColorImageVectors` |
| 矢量 | `ui/svg/drawablevectors/{Download,VideoFiles,VideoSteaming,Coder}.kt` |
| 预览 | `ui/svg/VectorPreviews.kt` |
| 固定色角色 | `LocalFixedColorRoles` + `FixedColorRoles`（primaryFixedDim 等） |
| 用法 | 空状态 `Image(imageVector = DynamicColorImageVectors.xxx(), …)` |

**机制要点**

1. Compose `@Composable` 构建 `ImageVector`，路径 `fill = SolidColor(MaterialTheme.colorScheme.*)` 与 `LocalFixedColorRoles.current.*`
2. 人物肤色等中性色可保留硬编码（如 `0xFF9f616a`），主题相关色走 scheme
3. 亮/暗色与动态取色自动适配，无需多套 PNG
4. Credits 注明 undraw 授权

## Target repos

| 仓库 | UI | 策略 |
|------|-----|------|
| **Seal** | Compose | 已有 — 作为权威参考；可小幅 polish / 文档化 |
| **Synapse-Client** | Compose | 复制向量 + FixedColorRoles 简化版；空状态/登录/无令牌 |
| **SyncClipboard** | Compose Android | 同上；空历史/未配置/Shizuku 引导 |
| **Project-Lumen** | Compose | 同上；主页/空列表/设置 |
| **ClashMetaForAndroid** | 以 View 为主 + 少量 Compose | design 模块或 app 中 Compose 岛；开屏/空连接/更新说明 |
| **PiliPlus** | Flutter | 等价：CustomPainter / `flutter_svg` 色槽 + `ColorScheme`；空状态与 onboarding |

## Requirements

### R1 共享模式

- 提供 `DynamicColorImageVectors`（或 Flutter 等价）API
- 至少 2–4 幅 undraw 风格图：download / empty files / streaming or sync / coder 或按产品语义重命名
- 路径色绑定主题；主题切换插画色同步变化

### R2 接入点（每仓至少）

- 1 个主空状态（列表空 / 无任务 / 无连接）
- 可选：关于 Credits 注明 undraw
- 首次启动 / 更新说明页可选用 1 幅

### R3 工程约束

- 禁止本地全量构建；CI 验证
- 用户可见变更同步 **本次更新说明**（Commit Hash + Build Time 门控）
- 提交后 push；开 PR 时 `gh pr merge --auto --squash`（仓库已 allow_auto_merge）
- 直接 main/master 推送则盯 CI 至绿

### R4 版权

- 保留 undraw 署名（Credits / OSS notice）
- 不引入需联网下载的 undraw CDN 运行时依赖

## Acceptance

- [ ] 各仓空状态可见动态色插画
- [ ] 改主题/动态色后插画主色跟随
- [ ] CI 绿；PR 可 auto-merge
- [ ] WhatsNew / update_notes 已写（若有该机制）

## Out of scope

- 全站每个页面铺满插画
- 替换现有图标字体 / Material Icons
