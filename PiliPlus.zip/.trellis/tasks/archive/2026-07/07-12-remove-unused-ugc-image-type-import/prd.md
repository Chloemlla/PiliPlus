# Remove unused UGC image type import

## Goal

Remove the unused `image_type.dart` import reported by static analysis in the UGC video introduction view.

## Requirements

- Remove the unused import from `lib/pages/video/introduction/ugc/view.dart`.
- Do not change runtime behavior.

## Acceptance Criteria

- [ ] `view.dart` no longer imports `models/common/image_type.dart`.
- [ ] No `ImageType` usage exists in the file.
- [ ] The code change is limited to the unused import removal.

## Definition of Done

- Text-level and Git diff checks pass.
- Flutter, Gradle, and local build/test commands are not run per repository policy.
- The fix is committed and pushed to `main`.

## Technical Approach

Delete the single unused import directive.

## Out of Scope

- Refactoring the UGC introduction view.
- Changing image handling behavior.

## Technical Notes

- Static analysis reported `unused_import` at line 15.
- Repository policy requires build and test execution only in GitHub workflows.
