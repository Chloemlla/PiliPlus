# Parallel convergence of active tasks

## Goal

Converge the repository's existing Trellis backlog by auditing all active tasks, immediately implementing already-known local fixes in parallel where file ownership does not overlap, and reconciling stale task state with current code and evidence.

## Requirements

- Treat the 44 tasks that were active at coordination start as the source backlog; reuse each task's existing PRD and research rather than redefining product behavior.
- Continue the running 14-domain audit and classify every task as complete, partial, stale, blocked, non-code, or not started with concrete evidence.
- Start implementation before the full audit finishes when a defect is already confirmed, scoped to this PiliPlus repository, and does not require a physical device, interactive account, external sibling repository, push, or destructive operation.
- Run concurrent implement agents only over disjoint file ownership domains. Serialize work that shares files or architecture contracts.
- Prefer tests and deterministic code fixes before documentation/status reconciliation.
- Preserve user content and existing configuration. Do not overwrite unrelated working-tree changes.
- Do not commit, amend, push, trigger externally visible workflows, archive tasks, or claim runtime/manual validation that was not performed.
- Record blockers precisely for work requiring Android hardware, live Bilibili credentials/services, sibling repositories, or remote CI.
- After each implementation wave, run a Trellis check agent and available local static/test verification. Follow the project constraint that local Flutter/Gradle builds are not valid CI substitutes.

## Acceptance Criteria

- [ ] Every initially active task has an evidence-backed classification.
- [ ] Every locally actionable confirmed defect found by the audit is either fixed and tested or has a concrete blocker.
- [ ] Parallel agents do not edit overlapping files in the same wave.
- [ ] Added or changed behavior has focused tests where practical.
- [ ] Available formatter, analyzer, and test checks pass, with any environment limitations reported exactly.
- [ ] User-visible changes update build-scoped what's-new content when required by frontend spec.
- [ ] No secret, token, cookie, account state, or private runtime data is written to source, logs, task artifacts, or memory.
- [ ] No git commit or push is performed.
- [ ] Final report separates code completed, stale bookkeeping, manual validation, remote CI, and external-repository work.

## Definition of Done

- Audit covers all 44 initial tasks and is reconciled against the final working tree.
- Implement and check passes have completed for each local conflict domain touched.
- Local verification commands appropriate to the changed files have been run.
- Remaining work is an explicit finite list with owner/environment prerequisites.

## Technical Approach

1. Fan out read-only audits by conflict domain.
2. Extract confirmed partial-task defects and construct implementation waves by affected-file overlap.
3. Dispatch one `trellis-implement` agent per disjoint domain, explicitly limiting each agent to named tasks and files.
4. Inspect the combined working tree between waves and stop agents whose assumptions became stale.
5. Dispatch `trellis-check` agents over completed domains, allowing direct fixes.
6. Run repository-level formatter/analyzer/tests available in the local toolchain; defer Android release/build proof to CI.
7. Reconcile stale/complete task metadata only after code convergence and evidence review; do not archive or commit without the user's later authorization.

## Decision (ADR-lite)

**Context:** The backlog contains overlapping historical tasks, tasks already landed in Git, sibling-repository work, and genuine partial implementations. Blindly launching one writer per task would cause duplicate work and file conflicts.

**Decision:** Use audit-first conflict-domain scheduling, but permit speculative early implementation only for already-confirmed local, deterministic, disjoint fixes.

**Consequences:** Useful fixes begin immediately while the broader audit runs. Some tasks remain blocked on hardware, CI, credentials, or sibling repositories and cannot honestly be marked complete in this workspace.

## Out of Scope

- Reintroducing superseded architectures solely to satisfy stale PRD wording.
- Editing unavailable sibling repositories from the PiliPlus workspace.
- Physical-device testing, live authorization approval, SMS/Geetest interaction, or non-Huawei device certification.
- Publishing branches, opening/merging PRs, triggering remote workflows, committing, pushing, or force operations.
- Fabricating completion evidence for manual or remote checks.

## Technical Notes

- Coordination scope at creation: 44 active Trellis tasks (43 `in_progress`, 1 `planning`).
- Initial audit is running as workflow `wf_b20e787e-480`, grouped into 14 conflict domains.
- Local toolchain constraint: Flutter 3.44.5 is required; Android SDK/full Visual Studio are unavailable, so Android artifacts rely on CI while local analysis/tests remain available.
- Relevant specifications include `.trellis/spec/frontend/index.md`, frontend quality and feature-specific guides, backend quality guidelines where applicable, and `.trellis/spec/guides/*` for architecture/reuse/cross-layer review.
- Existing task PRDs and research under `.trellis/tasks/<task>/` remain the authoritative feature requirements.
