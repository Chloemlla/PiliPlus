# seal-cookie-auth-passthrough

## Goal

让 PiliPlus 已登录的多账号 B 站 Cookie 在委托 Seal 下载时安全透传鉴权：用户可手动选择账号、记住选择，无需在 Seal 内再分账号维护 Cookie。

## Background

- PiliPlus：`LoginAccount` + `DefaultCookieJar`（`bilibili.com` `/` name→value map）；`hasRequiredCookies` = DedeUserID + bili_jct；`toJson()` 可导出。
- Seal：yt-dlp `--cookies` + Netscape `cookies.txt`；CookieProfile / WebView DB；L3 协议 v1 **禁止**第三方 cookie。
- 现网 PiliPlus→Seal 只传 URL 批次；需登录/高风控 BV 易失败（与 metadata abort 任务叠加）。

## Requirements (完整版)

### R1 — 协议 v2 入站 Cookie（Seal + PiliPlus）

- `protocol_version` 支持 2；MIN 仍为 1。
- Extras：`cookies_format`, `cookies` | `cookies_uri`, `cookies_mid`, `cookies_domain_hint`, `use_cookies`。
- 主格式 `json_map`（对齐 `cookieJar.toJson()`）；备选 `netscape` 全文 / FileProvider URI。
- 体积上限（建议 256KB string）；超限 `cookie_too_large`。
- **任务级** cookies 文件，不默认覆盖全局 `cookies.txt`。
- 终态删除临时文件；日志/广播永不含 secret。

### R2 — Seal 安全门禁

- 新开关：允许外部应用提供 Cookies（默认 **关**，首次需用户在 Seal 打开；或文档明确要求开启）。
- 与现有 delegate / whitelist / auto-start 组合：cookie 仅在 gate 通过后应用。
- 拒绝码：`cookie_denied`, `cookie_invalid`, `cookie_too_large`。
- **禁止**任何对外导出 Seal Cookie 的反向通道。

### R3 — PiliPlus 账号选择 UX

- 委托下载前（多 P 选择之后）：账号选择表。
- 单账号：预选 main/video；可「匿名委托」。
- 多账号：列表展示 mid + 可得昵称；单选。
- 「记住此账号」：写入 `sealCookieRememberMid`；下次跳过选择直至撤销/账号删除/always-ask。
- 设置项：启用透传、总是询问、清除记住的账号。

### R4 — Channel / Intent

- Dart `delegateDownload` 增加 cookie 字段。
- Kotlin `SealDownloadChannel` 写入 v2 extras；`protocol_version=2` 当有 cookie。
- 未登录或用户选匿名：行为与现网 v1 一致。

### R5 — 与下载稳定性

- 有 cookie 时 Seal 对该任务 `enableCookies` 指向任务文件。
- 与 bilibili metadata 重试修复互补，不互相阻塞。

### R6 — 测试 / 文档 / CI

- 见 `research/06-implementation-file-map.md` 测试表。
- 更新两仓第三方文档与 PiliPlus seal spec。
- 两仓 CI 绿（`gh run watch`）；本机不强制出包。

## Acceptance Criteria

- [ ] Seal 接受 v2 cookie extras 并在任务内 yt-dlp 使用。
- [ ] Seal 关闭「接受外部 Cookies」时拒绝且不影响无 cookie 请求。
- [ ] PiliPlus 多账号可选 + 记住 mid + 撤销。
- [ ] 匿名/未登录路径不变。
- [ ] 日志与 L3 广播无 SESSDATA 等明文。
- [ ] 任务结束后临时 cookie 文件删除。
- [ ] v1 调用方仍可用。
- [ ] 单测覆盖 map→netscape、gate、size。
- [ ] 文档更新；Seal + PiliPlus CI 绿。

## Edge Cases

| Case | Expected |
|------|----------|
| 记住 mid 已登出 | 回落账号选择 |
| Cookie 过期 | 下载失败 + 可行动错误（非崩溃） |
| Seal 未安装 | 现有 notInstalled 面板 |
| 白名单模式且 caller 不在名单 | caller_denied（先于 cookie） |
| 仅心跳号无 main | 列出所有 LoginAccount |
| 超大 payload | cookie_too_large |

## Out of Scope

- 反向读取 Seal 凭据
- 任意 yt-dlp 命令
- iOS
- 永久写入 Seal CookieProfile（除非用户显式「导入为 Profile」未来项）

## Technical Notes

- Research: `research/01`…`06`, `00-ci-status-full.md`
- Design core: `research/04-protocol-v2-full-design.md`, `05-ux-flows-full.md`

## Definition of Done

- 双仓实现 + 测试 + 文档 + CI 绿
- PRD/research 完整（非 MVP  stub）
