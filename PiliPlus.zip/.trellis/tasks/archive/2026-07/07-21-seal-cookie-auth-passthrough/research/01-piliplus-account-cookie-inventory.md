# Research: PiliPlus Account & Cookie Inventory

- **Query**: Full account model, cookie jar serialization, required cookies, multi-account listing, pref/remember patterns for Seal cookie passthrough
- **Scope**: internal (PiliPlus)
- **Date**: 2026-07-21

## Findings

### Files Found

| File Path | Description |
|---|---|
| `lib/utils/accounts/account.dart` | Sealed `Account` hierarchy; `LoginAccount`, `AnonymousAccount`, `NoAccount`; cookie jar extensions |
| `lib/utils/accounts.dart` | `Accounts` Hive box + `accountMode` slots by `AccountType` |
| `lib/models/common/account_type.dart` | `AccountType` enum: main / heartbeat / recommend / video |
| `lib/utils/accounts/account_secret_store.dart` | Encrypted on-disk secret store for cookies + access/refresh |
| `lib/utils/accounts/account_adapter.dart` | Hive adapter for `LoginAccount` |
| `lib/utils/accounts/account_type_adapter.dart` | Hive adapter for `AccountType` |
| `lib/utils/accounts/cookie_jar_adapter.dart` | Hive adapter for cookie jar |
| `lib/utils/accounts/account_manager/account_mgr.dart` | Dio interceptor: attaches cookies/headers per API path |
| `lib/services/account_service.dart` | Runtime login face / isLogin Rx service (main only) |
| `lib/models/user/info.dart` | `UserInfoData` (uname, face, mid, …) for main display |
| `lib/utils/storage_pref.dart` | `Pref.userInfoCache`, `Pref.sealAutoStart` |
| `lib/utils/storage_key.dart` | `SettingBoxKey.sealAutoStart` and other keys |
| `lib/pages/setting/models/extra_settings.dart` | UI toggle for Seal auto-start |
| `lib/pages/setting/view.dart` | Logout multi-select by mid; switch-account entry |
| `lib/pages/login/controller.dart` | Login + `switchAccountDialog`; builds `LoginAccount` from cookies |
| `lib/pages/mine/controller.dart` | Main-account `UserInfoData` display |
| `lib/utils/login_utils.dart` | onLoginMain / onLogoutMain; writes `userInfoCache` |
| `lib/utils/seal_download_utils.dart` | Current Seal delegate (no cookie extras) |
| `android/.../SealDownloadChannel.kt` | Intent builder for Seal L2/L3 (no cookie extras) |
| `test/utils/accounts/account_test.dart` | Required-cookie validation unit tests |
| `test/utils/accounts/account_secret_store_test.dart` | Secret store tests |

### Account Model

#### Sealed hierarchy (`account.dart`)

```text
Account (sealed)
├── LoginAccount     // HiveType(typeId: 9), real credentials
├── AnonymousAccount // singleton, mid=0, isLogin=false
└── NoAccount        // no-op sentinel for interceptor skip
```

**`LoginAccount` fields (Hive):**

| Field | Hive | Type | Role |
|---|---|---|---|
| `cookieJar` | 0 | `DefaultCookieJar` | Session cookies under bilibili.com |
| `accessKey` | 1 | `String?` | App API access_token |
| `refresh` | 2 | `String?` | refresh_token |
| `type` | 3 | `Set<AccountType>` | Which modes this account serves |
| `activated` | runtime | `bool` | buvid activated flag |
| `mid` | derived | `int` | from cookie `DedeUserID` |
| `csrf` | derived | `String` | from cookie `bili_jct` |
| `headers` | derived | map | baseHeaders + `x-bili-mid` + aurora eid |
| `grpcHeaders` | derived | map | from accessKey via `GrpcHeaders` |

**Login gate:**

```dart
bool get isLogin => hasRequiredCookies;
bool get hasRequiredCookies =>
    _midStr.isNotEmpty && csrf.isNotEmpty && mid != 0;
// _midStr from DedeUserID; csrf from bili_jct
```

`SESSDATA` is **not** part of `hasRequiredCookies`, but is typically present in real sessions and required for authenticated media/web access. Tests explicitly accept only `DedeUserID` + `bili_jct` as “required”; a jar with only `SESSDATA` is rejected (`shouldKeep == false`).

#### AccountType (`account_type.dart`)

```dart
enum AccountType {
  main('主账号'),
  heartbeat('记录观看'),
  recommend('推荐'),
  video('视频取流'),
}
```

`Accounts.accountMode` is a fixed-length list (one slot per type). Multiple types may point at the **same** `LoginAccount` instance (shared mid). `Accounts.mainEqVideo` is true when main and video slots share the same account.

#### Persistence: Hive box + secret store

1. **Hive box** `Accounts.account` (`Box<LoginAccount>`, name `'account'`).
   - Key = `secretKey` = mid string (`DedeUserID`).
   - `onChange()` → `persistSecret()` + `_box.put(secretKey, this)`.
   - `refresh()` drops accounts failing `shouldKeep`, rewrites canonical keys, rebinds `accountMode`.

2. **AccountSecretStore** (AES-GCM encrypted file):
   - Files: `account_secrets.key` (32-byte key base64), `account_secrets.json.enc`.
   - Payload per mid: `{ cookies: Map<String,String>, accessKey?, refresh? }`.
   - Written on every `persistSecret()` / import; deleted on account delete/clear.

**Import:** `Accounts.importAccounts` requires every imported account `shouldKeep`; rejects duplicates by mid.

### Cookie Jar Serialization

`BiliCookieJar` extension on `DefaultCookieJar`:

```dart
Map<String, String> toJson() {
  final cookies = domainCookies['bilibili.com']?['/'] ?? const {};
  return {for (final i in cookies.values) i.cookie.name: i.cookie.value};
}
```

- Domain key: **`bilibili.com`** (not `.bilibili.com` as map key; domain on Cookie object is set via `setBiliDomain` to `.bilibili.com`).
- Path: **`/`** only in serialization.
- Shape: **flat `name → value` map** (not Netscape).
- `fromJson` / `fromList` rebuild jar with `ignoreExpires: true` and `setBiliDomain()` on each cookie.
- `setBuvid3()` ensures `buvid3` exists for anonymous/login jars.
- `toList()` returns `List<Cookie>` for HTTP header use.

**LoginAccount.toJson():**

```dart
{
  'cookies': cookieJar.toJson(),  // Map name->value
  'accessKey': accessKey,
  'refresh': refresh,
  'type': type.map((i) => i.index).toList(),
}
```

**Cookie value read path used by mid/csrf:**

```dart
cookieJar.domainCookies['bilibili.com']?['/']?[name]?.cookie.value
```

### Required Cookies for Bilibili Auth

| Cookie | Role in PiliPlus | Required by `hasRequiredCookies` |
|---|---|---|
| `DedeUserID` | mid identity | **Yes** (non-empty, parseable ≠ 0) |
| `bili_jct` | CSRF | **Yes** (non-empty) |
| `SESSDATA` | Web session (media/web) | No (but present in real logins) |
| `buvid3` | Device fingerprint | Auto-injected if missing |
| `DedeUserID__ckMd5` | Common companion | Not checked |
| Others (sid, …) | Site-specific | Not checked |

For **Seal / yt-dlp bilibili extractor**, practical passthrough should include at least **`SESSDATA` + `DedeUserID` + `bili_jct`**, and ideally the full jar map for robustness (membership, quality, subtitle).

### Listing Accounts for UI

**All stored logins:**

```dart
Accounts.account.values          // Iterable<LoginAccount>
Accounts.account.toMap()         // Map key(midStr) -> LoginAccount
// Display label commonly used today: mid.toString()
// Logout dialog:
for (final i in Accounts.account.values) i: i.mid.toString()
```

**Switch-account dialog** (`LoginPageController.switchAccountDialog`):

```dart
final options = {
  AnonymousAccount(): '0',
  ...Accounts.account.toMap().map((k, v) => MapEntry(v, k as String)),
};
// keys are Account instances; labels are mid strings
// Can assign per AccountType slot (详细) or all slots same account (快速)
```

**Main display name / avatar (not multi-account):**

- `Pref.userInfoCache` → `UserInfoData` with `uname`, `face`, `mid`.
- Populated only for **current main** via `LoginUtils.onLoginMain` / mine page `UserHttp.userInfo()`.
- Secondary accounts in Hive **do not** have stored uname/face in this cache; UI can show **mid** for non-main, and uname for main when `account.mid == Pref.userInfoCache?.mid`.

**Recommended account list DTO for Seal picker (derived, not existing):**

| Field | Source |
|---|---|
| `mid` | `LoginAccount.mid` |
| `label` | `userInfoCache.uname` if same mid else `"UID $mid"` |
| `face` | same as above or empty |
| `isMain` | `Accounts.main.mid == mid` |
| `isVideo` | `Accounts.video.mid == mid` |
| `hasRequiredCookies` | `account.hasRequiredCookies` |
| `hasSessdata` | cookie map contains non-empty `SESSDATA` |

### Pref / Remember Patterns

| Key / API | Storage | Default | Use |
|---|---|---|---|
| `SettingBoxKey.sealAutoStart` / `Pref.sealAutoStart` | Hive setting box | `false` | Pass `auto_start` to Seal; settings UI “委托 Seal 时自动开始下载” |
| `Pref.userInfoCache` | `GStorage.userInfo` | null | Main user profile |
| Pattern for new prefs | `SettingBoxKey.xxx` + `Pref.xxx` getter + `SwitchModel` in extra/privacy settings | — | Same as sealAutoStart |

**No existing key** for “remembered Seal download account mid”. New keys (proposed in protocol/UX research, not present yet):

- `SettingBoxKey.sealCookieAccountMid` — remembered mid (int), `0` / absent = none
- `SettingBoxKey.sealCookiePassthroughEnabled` — master enable on PiliPlus side (optional)
- `SettingBoxKey.sealCookieAlwaysAsk` — force picker even when remembered

### Current Seal Download Path (no cookies)

`SealDownloadUtils._download` MethodChannel args:

```dart
{
  'url': primaryUrl,
  'urls': resolvedUrls,
  'extractAudio': extractAudio,
  'autoStart': Pref.sealAutoStart,
  'openUi': true,
  'requestId': requestId,
}
```

Kotlin `SealDownloadChannel.delegateDownload` maps to Intent extras:

- `protocol_version=1`, `url`, `urls`, `extract_audio`, `auto_start`, `open_ui`, `caller_request_id`, `caller_package`
- **No cookie / mid / account fields**

### Code Patterns (cite)

- Cookie map export: `lib/utils/accounts/account.dart:207-211` (`toJson`)
- Required cookies: `lib/utils/accounts/account.dart:80-81`
- mid from DedeUserID: `lib/utils/accounts/account.dart:120`
- Secret persist: `lib/utils/accounts/account.dart:101-109`
- Account list logout: `lib/pages/setting/view.dart:236-244`
- Switch account: `lib/pages/login/controller.dart:637-647`
- sealAutoStart pref: `lib/utils/storage_pref.dart:471-472`, UI `extra_settings.dart:239-245`

## Caveats / Not Found

- No display name store for non-main accounts (only mid + main `UserInfoData`).
- `hasRequiredCookies` does **not** require `SESSDATA`; Seal bilibili downloads may still fail without it even if PiliPlus considers the account “logged in”.
- Cookie values live in memory jar + encrypted store; Hive adapter may store jar separately — both must stay consistent when reading for export.
- No existing “remember mid for Seal” preference.
- Cookie export to other apps is not implemented anywhere in PiliPlus today.