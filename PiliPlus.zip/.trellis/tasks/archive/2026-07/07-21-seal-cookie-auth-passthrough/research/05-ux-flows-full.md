# Research: UX Flows Full — Cookie Auth Passthrough

- **Query**: First use, multi-account picker, remember, revoke, no-login, Seal missing, expired cookie; settings; error matrix
- **Scope**: mixed (design grounded in existing SealDownloadUtils panel + Accounts UI patterns)
- **Date**: 2026-07-21

## Findings

### Existing UX Anchors (no change unless noted)

**PiliPlus download entry**

- Video more menu → `SealDownloadUtils.downloadVideo` / `downloadAudio` → `promptDownload`.
- Multi-P sheet: 当前 P / 选择分 P… / 全部.
- Status panel: waitingUi / waitingAuto / accepted / completed / failed / rejected / canceled / notInstalled.
- Setting: “委托 Seal 时自动开始下载” (`sealAutoStart`).

**PiliPlus account UI**

- Settings: 切换账号 (`switchAccountDialog`), 退出登录 multi-select by mid.
- Labels today: mid strings; main face/uname via `UserInfoData`.

**Seal external settings**

- Settings → Interface → External downloads: delegate, auto-start, whitelist.
- Network → Cookies: WebView profiles, use cookies for yt-dlp.

### New Product Moments (ordered)

#### 1. First use (logged-in, single account)

1. User taps 委托 Seal 下载.
2. If multi-P → existing multi-P sheet first.
3. **Cookie sheet** (new), only when `sealCookiePassthrough` enabled (default ON if ≥1 login):
   - Title: 使用 B 站账号下载
   - Subtitle: 将把所选账号的登录凭证临时交给 Seal，仅用于本次下载
   - Single account preselected (main or video slot preferred: `Accounts.video` if login else `Accounts.main`)
   - Toggle: 记住此账号（默认 checked on first successful use? **default unchecked first time**, checked after user opts in once）
   - Actions: 使用账号下载 | 匿名委托（不传 Cookie）| 取消
4. On 使用账号下载 → build cookie map → channel → Seal.
5. Status panel unchanged phases; no cookie text in panel.

#### 2. Multi-account picker

When `Accounts.account.length > 1` and (no remember **or** always-ask):

```
使用哪个账号下载？
○ 主账号 · 昵称 (UID 123)     [if uname known]
○ UID 456
○ UID 789
☑ 记住选择
[使用所选账号] [不使用 Cookie] [取消]
```

Selection source:

- Default highlight: remembered mid if still in box and `hasRequiredCookies`, else video mode account, else main.
- Show badge “视频取流” / “主账号” from `AccountType` membership.

#### 3. Remember toggle

- Stored: `SettingBoxKey.sealCookieRemember` + `sealCookieAccountMid`.
- Next download: skip picker if remember=true and mid still valid (`Accounts.account` contains mid && hasRequiredCookies && SESSDATA optional soft check).
- Long-press / settings entry to clear (see revoke).

#### 4. Revoke / change account

**PiliPlus settings (Extra or Privacy):**

| Control | Behavior |
|---|---|
| 委托 Seal 时传递登录 Cookie | master passthrough on/off |
| 已记住的下载账号 | shows UID/uname; button 清除 / 更换 |
| 每次询问账号 | forces picker |

**Implicit revoke:**

- Account deleted via 退出登录 → clear remember if mid matches.
- Account loses required cookies on refresh → next time picker / anonymous fallback toast.

#### 5. No login

- `Accounts.account.isEmpty` or no `shouldKeep` accounts:
  - Do **not** show cookie sheet.
  - Proceed as today (anonymous / Seal’s own cookies).
  - Optional one-time tip: “登录后可为大会员/受限内容传 Cookie”.

#### 6. Seal missing

- Unchanged: `not_installed` panel + 前往安装 Seal.
- No cookie sent (no Intent launched).

#### 7. Expired / invalid cookie

| Detection | Where | UX |
|---|---|---|
| Missing DedeUserID / bili_jct | PiliPlus preflight | Toast/panel “账号凭证不完整，请重新登录”; offer 去登录 / 匿名委托 |
| Missing SESSDATA (soft) | PiliPlus preflight warning | “可能无法下载需登录内容” + continue / re-login |
| Seal rejects cookies | status `rejected` + error_code | Map to user message (see matrix) |
| yt-dlp fails auth | `download_failed` | Existing failed panel; optional hint “可尝试重新登录或检查 Seal Cookie 设置” |

#### 8. Seal cookie accept off

- Seal returns ignore (continue) or `cookies_disabled`.
- PiliPlus: if soft-ignore, download proceeds; optional toast “Seal 未开启接受外部 Cookie，将使用 Seal 侧登录状态”.
- Settings deep-link text: open Seal → External downloads → Accept cookies from external apps.

#### 9. Auto-start interaction

- Cookie attach independent of auto_start.
- Auto-start still requires Seal `external_auto_start_enabled`.
- Cookie sheet appears **before** launch (same as multi-P), not after.

#### 10. Multi-P + cookies

Order:

1. Multi-P selection (if needed)
2. Account / cookie sheet (if needed)
3. Launch with all URLs + one cookie set

### Settings — Both Apps

#### PiliPlus

| Setting | Key (proposed) | Default |
|---|---|---|
| 委托 Seal 时自动开始下载 | `sealAutoStart` | false (exists) |
| 委托 Seal 时传递登录 Cookie | `sealCookiePassthrough` | true |
| 记住下载账号 | `sealCookieRemember` | false |
| 记住的账号 mid | `sealCookieAccountMid` | 0 |
| 每次询问账号 | `sealCookieAlwaysAsk` | false |

Placement: Extra settings near existing Seal auto-start switch.

#### Seal

| Setting | Key (proposed) | Default |
|---|---|---|
| Accept cookies from external apps | `external_accept_cookies` | **false** (secure default) |
| Only whitelisted apps may send cookies | `external_accept_cookies_whitelist_only` | true when whitelist mode on |
| Existing external delegate / auto-start / whitelist | unchanged | |

Placement: External downloads section + short security subtitle.

Network → Cookies remains for **Seal-native** WebView login; separate from external inject.

### Error Matrix (user-facing)

| Condition | error_code / Platform code | PiliPlus panel / toast |
|---|---|---|
| Seal not installed | `not_installed` | 未安装 Seal |
| Empty URL | `invalid_url` | 无法构造视频链接 |
| External delegate off | `disabled` | Seal 已关闭外部下载委托 |
| Caller not whitelisted | `caller_denied` | Seal 白名单拒绝了当前应用 |
| Rate limited | `queue_rejected` | Seal 请求过于频繁 |
| Protocol mismatch | `unsupported_version` | Seal 协议版本不兼容 |
| Auto-start denied hard | `auto_start_denied` | Seal 未允许自动开始下载 |
| Cookie accept off (required) | `cookies_disabled` | Seal 未允许外部 Cookie |
| Cookie parse fail | `cookies_invalid` | Cookie 无效，请重新登录后重试 |
| Cookie too large | `cookies_too_large` | Cookie 数据过大 |
| URI grant fail | `cookies_uri_denied` | 无法将 Cookie 交给 Seal |
| User cancels cookie sheet | — | no launch |
| User chooses anonymous | — | launch without cookies |
| Download auth fail | `download_failed` | Seal 下载失败 (+ optional auth hint) |
| User cancel in Seal | `canceled` | 已取消 Seal 下载 |

### Wireframe Notes (compact)

**Cookie sheet** reuses multi-P bottom sheet constraints (`maxWidth` min 640, safe area).

**Status panel** must never show cookie values, mid optional only in debug logs.

### Accessibility / Privacy Copy

- Explicit consent copy on first passthrough: “凭证仅用于本次下载，不会写入 Seal 登录状态，也不会上传网络”.
- Seal settings: “外部应用可在委托下载时提供 Cookie 文件；默认关闭”.

## Caveats / Not Found

- No existing multi-account picker for download; only switch-account for modes and logout multi-select.
- Non-main uname may be missing; plan for mid-only labels.
- Soft-vs-hard reject on `cookies_disabled` needs product consistency between apps.