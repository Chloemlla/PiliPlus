# Research: External Download Protocol v1 (Current)

- **Query**: Full v1 constants, parser, gate, coordinator, status reporter, non-goals, docs
- **Scope**: mixed (Seal code + docs; PiliPlus client mirror)
- **Date**: 2026-07-21

## Findings

### Files Found

| File Path | Description |
|---|---|
| `Seal/.../integration/ExternalDownloadProtocol.kt` | Frozen constants |
| `Seal/.../integration/ExternalDownloadRequestParser.kt` | Intent → request |
| `Seal/.../integration/ExternalDownloadGate.kt` | Policy decisions |
| `Seal/.../integration/ExternalDownloadCoordinator.kt` | Enqueue + watch + content URI |
| `Seal/.../integration/ExternalDownloadStatusReporter` (same file) | Broadcast / Activity result |
| `Seal/.../integration/ExternalDownloadEntry.kt` | Activity shared entry |
| `Seal/.../QuickDownloadActivity.kt` | Primary UI entry (not fully re-read; wired to Entry) |
| `Seal/.../MainActivity.kt` | Cold start / onNewIntent |
| `Seal/docs/third-party-call-guide.md` | Public caller guide |
| `Seal/docs/third-party-delegate-integration.md` | Integration design |
| `Seal/docs/third-party-delegate-integration-TODO.md` | Explicit non-goals including cookie ban |
| `Seal/docs/third-party-ui-path-status-callback.md` | UI path L3 semantics |
| `Seal/app/src/test/.../ExternalDownloadIntegrationTest.kt` | Gate / parser tests |
| `PiliPlus/android/.../SealDownloadChannel.kt` | Client Intent builder (v1) |
| `PiliPlus/android/.../SealDownloadStatusBridge.kt` | Status broadcast receiver |
| `PiliPlus/lib/utils/seal_download_utils.dart` | Flutter orchestration + panel |
| `PiliPlus/.trellis/spec/frontend/flutter-seal-download-delegate.md` | Spec for multi-P + panel |

### Protocol Constants (full)

```kotlin
object ExternalDownloadProtocol {
    const val ACTION_DOWNLOAD = "com.chloemlla.seal.action.DOWNLOAD"
    const val ACTION_DOWNLOAD_STATUS = "com.chloemlla.seal.action.DOWNLOAD_STATUS"

    const val PROTOCOL_VERSION = 1
    const val MIN_SUPPORTED_VERSION = 1
    const val MAX_SUPPORTED_VERSION = 1

    // Request
    const val EXTRA_PROTOCOL_VERSION = "protocol_version"  // Int
    const val EXTRA_URL = "url"                            // String
    const val EXTRA_URLS = "urls"                          // String[]
    const val EXTRA_EXTRACT_AUDIO = "extract_audio"        // Boolean?
    const val EXTRA_DOWNLOAD_SUBTITLE = "download_subtitle"// Boolean?
    const val EXTRA_AUTO_START = "auto_start"              // Boolean (default false)
    const val EXTRA_OPEN_UI = "open_ui"                    // Boolean (default true)
    const val EXTRA_CALLER_REQUEST_ID = "caller_request_id"// String?

    // Response / status
    const val EXTRA_TASK_ID = "task_id"
    const val EXTRA_TASK_IDS = "task_ids"
    const val EXTRA_STATUS = "status"
    const val EXTRA_ERROR_CODE = "error_code"
    const val EXTRA_ERROR_MESSAGE = "error_message"
    const val EXTRA_CONTENT_URI = "content_uri"
    const val EXTRA_DISPLAY_NAME = "display_name"
    const val EXTRA_MIME_TYPE = "mime_type"
    const val EXTRA_CALLER_PACKAGE = "caller_package"

    // Status values
    const val STATUS_ACCEPTED = "accepted"
    const val STATUS_REJECTED = "rejected"
    const val STATUS_NEEDS_UI = "needs_ui"
    const val STATUS_COMPLETED = "completed"
    const val STATUS_FAILED = "failed"
    const val STATUS_CANCELED = "canceled"

    // error_code
    const val ERROR_OK = "ok"
    const val ERROR_DISABLED = "disabled"
    const val ERROR_AUTO_START_DENIED = "auto_start_denied"
    const val ERROR_INVALID_URL = "invalid_url"
    const val ERROR_UNSUPPORTED_VERSION = "unsupported_version"
    const val ERROR_CALLER_DENIED = "caller_denied"
    const val ERROR_QUEUE_REJECTED = "queue_rejected"
    const val ERROR_INTERNAL = "internal_error"
    const val ERROR_DOWNLOAD_FAILED = "download_failed"
    const val ERROR_CANCELED = "canceled"
}
```

### ExternalDownloadRequest (parsed model)

```kotlin
data class ExternalDownloadRequest(
    val protocolVersion: Int,
    val urls: List<String>,
    val extractAudio: Boolean?,      // null = use Seal user pref
    val downloadSubtitle: Boolean?,  // null = use Seal user pref
    val autoStart: Boolean,
    val openUi: Boolean,
    val callerRequestId: String?,
    val sourceAction: String?,
    val isExplicitDelegateAction: Boolean,
)
```

**No cookie / mid / account fields.**

### Parser Behavior

1. Null intent → `invalid_url`.
2. Version: if missing → treat as 1; if outside `[MIN, MAX]` → `unsupported_version`.
3. URLs from: `url`, `urls[]`, `Intent.EXTRA_TEXT` (URL extract), `intent.dataString`.
4. HTTP(S) only; host must contain `.` (`looksLikeHttpUrl`).
5. Empty URL set → `invalid_url`.
6. Boolean extras: presence-checked for extract_audio / download_subtitle (absent → null).

### Gate Policy

Prefs (`PreferenceUtil`):

| Key | Default | Role |
|---|---|---|
| `external_delegate_enabled` | true | Master switch |
| `external_auto_start_enabled` | false | Allow silent enqueue |
| `external_whitelist_mode` | false | Restrict callers |
| `external_caller_whitelist` | "" | Packages split by `\n`, `,`, `;` |

Decision order:

1. `!delegateEnabled` → `disabled`
2. whitelist mode and caller empty/not listed → `caller_denied`
3. empty urls → `invalid_url`
4. `!rateLimitOk` → `queue_rejected` (60s / 20 hits per caller)
5. `autoStart`:
   - policy allows → `AutoStart`
   - else if `openUi` → `NeedsUi` (+ note `auto_start_denied`)
   - else → reject `auto_start_denied`
6. else → `NeedsUi`

### Entry / Coordinator / Status Reporter

**Entry** (`ExternalDownloadEntry.handle`):

- Resolve caller: `activity.callingPackage` then extra `caller_package` then `intent.package`.
- Parse → Gate → Reject / ShowUi / AutoStart enqueue.
- AutoStart: `Coordinator.enqueue` then finish with `accepted` + broadcast.

**Coordinator**:

- `buildPreferences`: only overrides extractAudio / downloadSubtitle; cookies untouched.
- `enqueue`: one Task per URL; watchTask for L3 terminals.
- UI path: `beginExternalSession` / `watchEnqueuedTasksIfExternal` after user confirms.
- Terminal: completed (+ FileProvider content_uri grant), failed, canceled.
- Rate limit helper used by Entry.

**StatusReporter**:

- Directed broadcast `setPackage(targetPackage)`.
- Activity result bundle for immediate statuses.
- Never logs cookie material (none present).

### PiliPlus Client Mirror (v1)

`SealDownloadChannel`:

- `PROTOCOL_VERSION = 1`
- Packages: `com.chloemlla.seal` / `.debug` / `.preview`
- Component: `QuickDownloadActivity`
- Extras: same v1 set; no cookies
- `startActivityForResult` for callingPackage resolution

`SealDownloadStatusBridge`:

- Application-scoped receiver for `DOWNLOAD_STATUS`
- Queues until Dart `readyForStatus`
- Maps status extras to Flutter MethodChannel

### Explicit Non-Goals (docs + code)

From `third-party-delegate-integration-TODO.md` §1.2:

- Arbitrary yt-dlp command injection — **forbidden**
- **Cookie / account credential export or cross-app read — forbidden**
- Arbitrary output path / path traversal — forbidden
- Mutating Seal global settings via protocol — forbidden
- Unlimited silent batch — mitigated by auto-start default off + rate limit
- Remote HTTP control — forbidden
- Returning CDN direct URLs as stable API — forbidden
- Embedding download engine in third-party process — forbidden

From `third-party-call-guide.md` §1 “不能做”:

- 读取 Seal Cookie / 账号
- 注入任意 yt-dlp 命令
- 指定任意输出路径、改 Seal 全局设置
- …

Protocol object KDoc:

> Raw yt-dlp commands, cookie export, and remote control are intentionally unsupported.

**Semantic distinction for this task:**

- Current ban is **export from Seal / cross-app read of Seal secrets**.
- Desired feature is **caller-authorized inject of caller-owned cookies into Seal for a delegated task** (opposite direction).
- Still requires intentional protocol extension + user opt-in on Seal side, because TODO currently freezes “no cookie channel”.

### Version Window

Today: only version `1` (`MIN=MAX=PROTOCOL=1`).

Any new cookie extras without version bump could be ignored by older Seal; older clients sending v1 without cookies continue to work. Bumping to `MAX_SUPPORTED_VERSION=2` while accepting v1 is the documented pattern for additive features.

## Caveats / Not Found

- `caller_package` as Intent extra is fallback only; security decisions use `callingPackage` first.
- No cookie validation, no cookie error codes.
- Package path in TODO still mentions `com.junkfood.seal` in one reference block (stale); runtime package is `com.chloemlla.seal`.
- L4 Binder/ContentProvider not implemented.