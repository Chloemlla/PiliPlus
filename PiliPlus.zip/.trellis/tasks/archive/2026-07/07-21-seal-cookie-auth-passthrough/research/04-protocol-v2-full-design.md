# Research: Protocol v2 Full Design — Cookie Injection

- **Query**: Complete protocol extension for cookie injection (extras, security, transport, task-scoped cookies, remember mid, backward compat)
- **Scope**: mixed (design derived from verified v1 + cookie pipelines)
- **Date**: 2026-07-21

## Findings

### Design Goals

1. PiliPlus (or any authorized caller) may attach **caller-owned** Bilibili cookies to a download delegate request.
2. Seal applies cookies **for that external task only** when policy allows.
3. Secrets never appear in logs, status broadcasts, or UI panels.
4. v1 callers remain fully functional without cookies.
5. Users can disable cookie accept on Seal; callers can skip passthrough.

### Non-Goals (unchanged)

- Reading Seal’s WebView / CookieProfile secrets back to callers.
- Arbitrary yt-dlp command strings.
- Remote cookie fetch.
- Permanently mutating Seal global user preferences (except optional explicit user settings for accept policy).

### Versioning

| Constant | v1 | v2 proposal |
|---|---|---|
| `PROTOCOL_VERSION` (latest) | 1 | **2** |
| `MIN_SUPPORTED_VERSION` | 1 | **1** |
| `MAX_SUPPORTED_VERSION` | 1 | **2** |

Rules:

- Missing `protocol_version` → treat as **1** (existing).
- Version `1` requests **must ignore** unknown cookie extras if present (defensive), or optionally reject cookie extras when version=1 for strictness.
- Recommended: cookie fields processed only when `protocol_version >= 2` **or** when cookie extras present and Seal cookie-accept is on (compat path). Prefer **version >= 2 required to apply cookies** so old docs stay honest.

PiliPlus client: send `protocol_version = 2` when attaching cookies; send `1` when not (or always 2 once both apps ship, since v2 is additive).

### New Request Extras

| Key (exact string) | Type | Required | Description |
|---|---|---|---|
| `cookies_format` | String | if cookies present | `"netscape"` \| `"json_map"` \| `"name_value"` |
| `cookies` | String | one of payload forms | Cookie payload (see transport) |
| `cookies_uri` | String (content URI) | alternative to `cookies` | FileProvider URI to Netscape file |
| `cookies_mid` | Long / String | optional | Account mid for audit / remember correlation (non-secret) |
| `cookies_domain_hint` | String | optional | Default `.bilibili.com` if format is map |
| `use_cookies` | Boolean | optional | Force task `cookies=true` when payload accepted; default true if payload present |

#### Format: `json_map` (primary for PiliPlus)

Payload string is JSON object:

```json
{
  "DedeUserID": "12345",
  "bili_jct": "...",
  "SESSDATA": "...",
  "buvid3": "..."
}
```

Matches `LoginAccount.cookieJar.toJson()` / `AccountSecret.cookies`.

Seal converts to Netscape lines:

```text
# Netscape HTTP Cookie File
# Injected by external delegate (task-scoped)
.bilibili.com	TRUE	/	TRUE	0	DedeUserID	12345
...
```

- Domain: `cookies_domain_hint` or `.bilibili.com`
- includeSubdomains TRUE, path `/`, secure TRUE, expiry `0` (session) unless extended later

#### Format: `netscape` (fallback / advanced)

Full Netscape body (may include header). Written as-is (or header normalized) to task file.

#### Format: `name_value`

Semicolon-separated `a=b; c=d` (browser cookie header style). Parsed then converted like json_map.

### Size Limits & Validation

| Constraint | Limit | On violation |
|---|---|---|
| Max raw payload chars (`cookies` string) | **48 KiB** (49152) | `cookies_too_large` |
| Max cookies count after parse | **200** | `cookies_invalid` |
| Max single cookie value length | **8 KiB** | `cookies_invalid` |
| Max `cookies_uri` open size | **64 KiB** | `cookies_too_large` |
| Allowed URI schemes | `content://` only | `cookies_invalid` |
| Allowed URI authorities | caller package FileProvider / grant | `cookies_invalid` / security reject |
| Cookie names charset | printable ASCII, no `\t\n\r` | drop or reject |
| Cookie values | no `\t\n\r` in netscape field | reject / escape |
| Empty payload when use_cookies true | — | `cookies_invalid` |
| Required for bilibili success (soft) | prefer SESSDATA present | not hard-fail protocol; may fail later as download_failed |

**Intent transaction limit:** Android binder ~1MB; stay far below with 48 KiB.

### Error Codes (new)

| code | When |
|---|---|
| `cookies_disabled` | Seal opt-in off; payload present |
| `cookies_invalid` | Parse/validate failure |
| `cookies_too_large` | Size limit |
| `cookies_uri_denied` | Cannot open URI / no grant / wrong package |
| `cookies_unsupported` | Format unknown or protocol_version too old for cookies |

Existing codes still apply (`disabled`, `caller_denied`, …).

Behavior options when cookies rejected:

- **Hard reject entire request** if cookies were mandatory (not recommended for UX).
- **Soft ignore** cookies + continue download with Seal global cookies / anonymous (`error_code` note in needs_ui? better: optional status field).

**Product decision (recommended):** if Seal cookie accept is **off** and payload present → reject with `cookies_disabled` only when caller set `use_cookies=true` **and** a new flag `cookies_required=true`; else **ignore payload** and continue as v1 (log once at info without values). PiliPlus default: `cookies_required=false` so missing Seal opt-in still downloads anonymously / with Seal’s own cookies.

### Security Model

#### Seal opt-in preferences (new)

| Key | Default | Meaning |
|---|---|---|
| `external_accept_cookies` | **false** | Master: accept cookie extras from external callers |
| `external_accept_cookies_whitelist_only` | true if whitelist mode else false | Optional: only whitelisted packages may inject |
| (reuse) `external_whitelist_mode` + `external_caller_whitelist` | existing | Caller package gate remains first |

Decision order extension after URL validation:

1. Existing gates…
2. If cookie payload present:
   - If `!external_accept_cookies` → ignore or `cookies_disabled` per product rule
   - If whitelist-only for cookies and caller not allowed → `caller_denied` / `cookies_uri_denied`
   - Validate payload
   - Materialize task-scoped file

#### Caller authentication

- Prefer `Activity.callingPackage` (already required for L3).
- Do **not** trust `caller_package` extra for cookie accept.
- Optional future: signature allowlist for PiliPlus package names.

#### Secret handling

- Never put cookies in `DOWNLOAD_STATUS` extras.
- Never log cookie values; log only `cookiesPresent=true`, `mid=…`, `byteLength=…`, `format=…`.
- Temp files: `cacheDir/external_cookies/{requestId or uuid}.txt`, mode private.
- Delete temp file on: task terminal (completed/failed/canceled), timeout (e.g. 24h scavenger), process start cleanup of stale `external_cookies/*`.
- Do not write injected cookies into WebView CookieManager or CookieProfile by default (avoids polluting user’s Seal login state).

#### UI path

When `NeedsUi` / configure dialog opens, cookies already materialised for the pending session; enqueue uses session-bound path. If user cancels without enqueue, delete temp file in `endExternalSession`.

### Transport Comparison

| Transport | Pros | Cons | Recommendation |
|---|---|---|---|
| **A. Intent String extra** (`cookies` + `json_map`) | Simple; matches current L2; no FileProvider | Binder size risk if map huge; visible to Activity dumpsys if not careful | **Primary** for bilibili map (~1–4 KB typical) |
| **B. FileProvider URI** (`cookies_uri` → Netscape file) | Scales; reuses grant pattern; avoids large binder | More code; grant lifecycle; package visibility | **Fallback** when payload > 24 KiB or format netscape large |
| **C. ContentProvider query** | Clean IPC | L4 scope; not built | Out of scope |

**Primary:** Intent `cookies_format=json_map` + `cookies=<json string>` + `cookies_mid=<mid>`.

**Fallback:** PiliPlus writes Netscape to app cache, grants Seal read via FileProvider, puts `cookies_uri`, empty `cookies`.

PiliPlus package visibility: Seal already resolved via package list; reverse grant uses Seal package name from resolution.

### Task-Scoped vs Global cookies.txt

| Approach | Detail | Verdict |
|---|---|---|
| Overwrite global `cookies.txt` | Simple enableCookies path; races, pollutes concurrent downloads, startup regen may overwrite mid-flight | **Avoid** |
| Task-scoped temp + per-request `--cookies` path | Extend `DownloadPreferences` with `cookiesFilePath: String?` and `cookies: Boolean` force true | **Prefer** |
| CookieProfile insert | Leaves user data dirty; still need path wiring | Avoid as primary |

**Required Seal code path:**

```kotlin
// DownloadPreferences
val cookies: Boolean
val cookiesFilePath: String? = null // null → context.getCookiesFile()

// enableCookies:
val path = preferences.cookiesFilePath ?: context.getCookiesFile().absolutePath
addOption("--cookies", path)
```

External `buildPreferences(request)`:

```kotlin
base.copy(
    extractAudio = ...,
    downloadSubtitle = ...,
    cookies = request.cookiesAccepted || base.cookies,
    cookiesFilePath = request.taskCookiesPath, // null if none
)
```

### Remembered Account Binding (mid)

Remembering is **PiliPlus-side only** (caller UX):

| Pref | Type | Meaning |
|---|---|---|
| `sealCookieAccountMid` | int | Last chosen mid; 0 = clear |
| `sealCookieRemember` | bool | User checked “记住账号” |
| `sealCookiePassthrough` | bool | Master enable on PiliPlus (default true when logged in) |

Protocol only carries `cookies_mid` for optional Seal-side diagnostics / future “last external mid” display (non-secret).

Seal **must not** store injected cookie values long-term keyed by mid unless user explicitly saves a CookieProfile (out of scope).

### Request Model Extension

```kotlin
data class ExternalDownloadRequest(
    // v1 fields...
    val cookiesFormat: String? = null,
    val cookiesPayload: String? = null,
    val cookiesUri: String? = null,
    val cookiesMid: Long? = null,
    val cookiesDomainHint: String? = null,
    val useCookies: Boolean? = null,
    val cookiesRequired: Boolean = false,
    // after accept:
    // taskCookiesPath set by coordinator after materialize
)
```

### Status / Response

No cookie echo. Optional non-secret:

| Key | Type | When |
|---|---|---|
| `cookies_applied` | Boolean | accepted / needs_ui soft notice |
| `cookies_mid` | String | echo non-secret mid |

Prefer minimal: only apply silently; failures surface via error_code.

### Backward Compatibility Matrix

| Caller | Seal | Result |
|---|---|---|
| v1 no cookies | v1 | unchanged |
| v1 no cookies | v2 | unchanged |
| v2 + cookies | v1 (MAX=1) | `unsupported_version` if version=2 forced; **or** if client sends version=1 with extras, Seal v1 ignores extras |
| v2 + cookies | v2 accept off | ignore or `cookies_disabled` |
| v2 + cookies | v2 accept on | task-scoped cookies applied |
| v2 cookies too large | v2 | `cookies_too_large` |

**Client strategy:** After both ship, PiliPlus always sends `protocol_version=2`. Cookie extras only when user enables passthrough and account selected.

### Gate Pseudocode

```
parse(intent) → request (incl. cookie fields if version allows)
decide(policy, request, caller):
  existing gates...
  if request.hasCookiePayload:
    if !policy.acceptCookies:
      if request.cookiesRequired: return Reject(cookies_disabled)
      else clear cookie fields and continue
    if policy.cookieWhitelistOnly && caller not in whitelist:
      return Reject(caller_denied)
    val materialize = CookieMaterializer.materialize(request, caller)
    if materialize is Failure:
      if cookiesRequired: return Reject(code)
      else clear and continue
    attach path to request
  existing autoStart / NeedsUi...
```

### Constants Block (proposed)

```kotlin
const val PROTOCOL_VERSION = 2
const val MIN_SUPPORTED_VERSION = 1
const val MAX_SUPPORTED_VERSION = 2

const val EXTRA_COOKIES_FORMAT = "cookies_format"
const val EXTRA_COOKIES = "cookies"
const val EXTRA_COOKIES_URI = "cookies_uri"
const val EXTRA_COOKIES_MID = "cookies_mid"
const val EXTRA_COOKIES_DOMAIN_HINT = "cookies_domain_hint"
const val EXTRA_USE_COOKIES = "use_cookies"
const val EXTRA_COOKIES_REQUIRED = "cookies_required"

const val COOKIES_FORMAT_JSON_MAP = "json_map"
const val COOKIES_FORMAT_NETSCAPE = "netscape"
const val COOKIES_FORMAT_NAME_VALUE = "name_value"

const val ERROR_COOKIES_DISABLED = "cookies_disabled"
const val ERROR_COOKIES_INVALID = "cookies_invalid"
const val ERROR_COOKIES_TOO_LARGE = "cookies_too_large"
const val ERROR_COOKIES_URI_DENIED = "cookies_uri_denied"
const val ERROR_COOKIES_UNSUPPORTED = "cookies_unsupported"

const val MAX_COOKIES_PAYLOAD_CHARS = 48 * 1024
```

## Caveats / Not Found

- `DownloadPreferences` currently has no `cookiesFilePath`; design requires a real code change.
- TransactionTooLargeException still possible with pathological Intent dumps; enforce size before putExtra.
- Multi-URL batch: one cookie set applies to **all** URLs in the same request (same account) — acceptable for PiliPlus multi-P.
- Concurrent external sessions: temp files isolated by requestId/uuid.