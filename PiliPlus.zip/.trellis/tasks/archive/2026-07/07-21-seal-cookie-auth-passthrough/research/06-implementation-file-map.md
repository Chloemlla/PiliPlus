# Research: Implementation File Map — Cookie Auth Passthrough

- **Date**: 2026-07-21
- **Repos**: PiliPlus + Seal (dual-repo)

## Seal files

| File | Change |
|------|--------|
| `integration/ExternalDownloadProtocol.kt` | PROTOCOL_VERSION=2, MAX=2; new extras keys; new error codes (`cookie_denied`, `cookie_invalid`, `cookie_too_large`) |
| `integration/ExternalDownloadRequestParser.kt` | Parse cookies_format/cookies/cookies_uri/cookies_mid/use_cookies; size caps |
| `integration/ExternalDownloadRequest.kt` (data class in parser file) | Add cookie fields on request |
| `integration/ExternalDownloadGate.kt` | Policy: EXTERNAL_ACCEPT_COOKIES pref; reject if cookies present but accept off |
| `integration/ExternalDownloadCoordinator.kt` | Session holds task cookie file path; pass to enqueue; delete on terminal |
| `integration/ExternalDownloadEntry.kt` / QuickDownloadActivity / MainActivity | Wire request cookies into session |
| `util/DownloadUtil.kt` | Task-scoped `--cookies` path override (not only global cookies.txt) |
| `util/FileUtil.kt` | `getExternalTaskCookiesFile(taskId)` under cache; delete helper |
| `util/PreferenceUtil.kt` | EXTERNAL_ACCEPT_COOKIES (default OFF for safety **or** ON for fork — product: default OFF until user enables once; PiliPlus docs say enable) |
| `ui/page/settings/interaction/InteractionPreferencePage.kt` | Toggle “允许外部应用提供 Cookies” |
| `res/values/strings.xml` + zh | Strings for toggle + errors |
| `docs/third-party-call-guide.md` | Document v2 cookie extras |
| `docs/third-party-delegate-integration.md` | Same |
| `docs/third-party-delegate-integration-TODO.md` | Update non-goal: **inbound** cookie allowed with gate; outbound still forbidden |
| Unit tests under `app/src/test/.../integration/` | Parser cookie formats; gate deny; size limit |

## PiliPlus files

| File | Change |
|------|--------|
| `lib/utils/accounts/account.dart` | Helper `toNetscapeOrJsonMap()` if needed (toJson already) |
| `lib/utils/seal_download_utils.dart` | Account picker sheet; attach cookie payload; prefs for remember mid |
| `android/.../SealDownloadChannel.kt` | Intent extras for cookies; protocol_version 2; optional FileProvider URI path |
| `android/.../AndroidManifest.xml` | FileProvider paths if using cookies_uri |
| `lib/utils/storage_key.dart` | sealCookiePassthrough, sealCookieRememberMid, sealCookieAlwaysAsk |
| `lib/utils/storage_pref.dart` | Pref getters/setters |
| `lib/pages/setting/models/extra_settings.dart` | Settings UI entries |
| `.trellis/spec/frontend/flutter-seal-download-delegate.md` | Spec update for cookie contract |
| `test/utils/seal_cookie_export_test.dart` | Map → netscape / required keys / redaction |

## Transport recommendation (from 04)

| Priority | Mechanism | Use |
|----------|-----------|-----|
| **Primary** | `cookies` String extra + `cookies_format=json_map` | Normal bilibili map from `cookieJar.toJson()` (small) |
| **Fallback** | `cookies_uri` via FileProvider Netscape file | If payload > ~200KB or future multi-domain |
| Avoid | Permanent write into Seal CookieProfile DB | Pollutes user profiles |

## Task-scoped cookie application

1. Parse payload → write `cache/external_cookies/<taskId>.txt`
2. For that task’s info + download YoutubeDLRequest: `--cookies <that path>` regardless of global COOKIES **when** accept policy allows
3. Do **not** overwrite global `cookies.txt` by default
4. On completed/failed/canceled: delete task file
5. Never put cookie values in Log / DOWNLOAD_STATUS extras

## Remember binding

- Pref key: `sealCookieRememberMid` → int mid
- Pref: `sealCookiePassthrough` bool (master)
- Pref: `sealCookieAlwaysAsk` bool
- On download: if remember mid still in Accounts.account and !alwaysAsk → skip picker
- Revoke: settings “清除记住的 Seal 下载账号”

## Test plan (complete)

1. Unit: json_map → netscape lines domain `.bilibili.com`
2. Unit: missing SESSDATA still sends if DedeUserID+bili_jct present (hasRequiredCookies) — document optional SESSDATA
3. Unit: parser rejects > max size
4. Unit: gate rejects cookies when EXTERNAL_ACCEPT_COOKIES=false
5. Unit: v1 request ignores cookie fields
6. Android instrumented (CI if exists): Intent extras round-trip
7. Manual: single account, multi account remember, anonymous, Seal not installed, accept off on Seal

## Docs

- PiliPlus: flutter-seal-download-delegate.md
- Seal: third-party-call-guide.md, integration.md, TODO non-goals update

## CI

- Push Seal → `gh run watch` Build Pre-Release
- Push PiliPlus → `gh run watch` Build (Analyze + Release Android)
- No local Android APK required
