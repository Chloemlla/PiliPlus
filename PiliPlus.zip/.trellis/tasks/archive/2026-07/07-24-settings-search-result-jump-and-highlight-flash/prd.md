# 设置搜索：结果一键定位 + 荧光闪烁

## Goal

设置页搜索结果支持一键跳转到对应设置分区页，并在目标项上荧光闪烁一次，便于定位。

## Repo

`F:\Repositories\GitHub\PiliPlus`

## Current state

- `SettingsSearchPage` 扁平展示 `SettingsModel.widget`，点击在搜索页内直接交互
- **无** 跳转到 `CommonSetting` 分区、无高亮

## Requirements

- R1. 每个可搜索项带稳定 id（或 SettingType + key）
- R2. 点击搜索结果 → 打开对应设置分类页并滚动到该项
- R3. 目标项短暂荧光/高亮闪烁（动画一次后恢复）
- R4. 开关类项仍可在定位后操作；或搜索结果行提供「定位」主操作
- R5. 无本地构建；CI 验证

## Acceptance

- [ ] 搜索「xxx」点结果后进入正确分区且可见闪烁
- [ ] 返回/再搜不崩溃
