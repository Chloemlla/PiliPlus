# PiliPlus-side Seal L3 hardening

## Changes
- Application-scoped `SealDownloadStatusBridge` receives `DOWNLOAD_STATUS` even when Activity/engine is not foreground-bound.
- Status events queue until Dart calls `readyForStatus`.
- Intent includes `caller_package` fallback + always uses Activity Result.
- Dart early `ensureListening` in main; completion toast + success card.

## Remaining dependency
Seal UI path must still `watchTask` after user confirms download (see Seal docs/third-party-ui-path-status-callback.md). Without that, completed never arrives; PiliPlus can only show launched/needs_ui.
