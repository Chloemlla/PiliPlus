# 完善 PiliPlus Seal 下载状态对接

## Goal

在 PiliPlus 侧把 Seal L3 状态回传做稳：进程内可靠接收 `DOWNLOAD_STATUS`，并在 Dart 层给出可感知的入队/完成/失败反馈（不依赖 Seal 是否已修 UI 路径 watch；修好后即可直接生效）。

## Requirements

* Application 级注册 `DOWNLOAD_STATUS` 接收器（不随 Activity/FlutterEngine dispose 丢失）
* FlutterEngine 重连后能冲刷缓存的状态事件
* Intent 携带 `caller_package` 兜底（优先系统 callingPackage）
* Dart 尽早 `ensureListening`；委托后给出明确「等待 Seal 完成」提示
* 状态映射：launched/needs_ui/accepted/rejected/completed/failed/canceled
* completed：居中成功卡片（打开/分享）；无 content_uri 仍提示完成
* 未安装：Toast + 打开 Releases（保持）
* 「离线缓存」不变；非 Android 走 MediaExportUtils

## Acceptance Criteria

* [ ] Seal 发来 completed/failed/canceled 时，即使视频页已退到后台，PiliPlus 仍能 Toast/弹卡片
* [ ] 重新进入前台后缓存事件不丢（引擎短暂 detach 再 attach）
* [ ] 下载视频/音频仍正确传 url / extract_audio / auto_start / request_id
* [ ] 代码风格与现有 MethodChannel 一致

## Technical Approach

1. `SealDownloadStatusBridge`（Application）：注册 receiver、缓存事件、绑定 MethodChannel
2. `SealDownloadChannel`：只负责启动 Intent / 打开分享；状态走 Bridge
3. Dart：启动时 ensureListening；pending 请求文案；完成卡片保持

## Out of Scope

* 修改 Seal 源码 watchTask（文档已说明，属 Seal 侧）
* 内嵌 yt-dlp / 文件入库
