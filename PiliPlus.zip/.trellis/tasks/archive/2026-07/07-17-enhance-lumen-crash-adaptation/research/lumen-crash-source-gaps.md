# Research: lumen-crash source vs PiliPlus host

Date: 2026-07-17

## SDK install APIs
- LumenCrash.install(Application, LumenCrashConfig)
- LumenCrash.install(Application, configure: LumenCrashConfigBuilder.() -> Unit)
- LumenCrash.installSafely(...) returns Boolean
- loadPendingReportSafely() preferred for hosts

## Capture-only
README recommends `com.chloemlla.lumen:lumen-crash-core` when Compose crash UI is unused.
PiliPlus Flutter owns product crash UI => core is correct.

## Host gaps
1. Manual install + commitHash unknown
2. loadPendingReport not safely
3. full AAR + Compose BOM
4. breadcrumbs not forwarded
5. proguard template lagging

## Keep
- ProcessExitCollector for ANR/native/init
- Flutter CrashReportStore history
- No dual uncaught handlers
