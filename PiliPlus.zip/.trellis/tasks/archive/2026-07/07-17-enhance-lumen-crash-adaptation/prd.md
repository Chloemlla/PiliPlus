# 根据 lumen-crash 源码增强崩溃适配

## Goal
对照 Project-Lumen `lumen-crash` / `lumen-crash-core` 当前源码与 README，优化 PiliPlus 的 hybrid 崩溃桥：安装路径、安全 API、采集-only 依赖、ProGuard、面包屑贯通与元数据，保持 Flutter 历史/启动 UI 为唯一产品面。

## What I already know

### SDK 源码要点（2026-07-17 阅读）
* 模块：`lumen-crash-core`（采集）+ `lumen-crash`（core + Compose UI）
* 包：`com.chloemlla.lumen.crash`
* 推荐最短接入：
  1. `implementation("com.chloemlla.lumen:lumen-crash[-core]:<ver>")`
  2. `LumenCrash.installSafely(app) { ... }` 在 `attachBaseContext`
  3. Compose 宿主用 `LumenCrashGate`（PiliPlus **不用**）
* 公开 API：
  * `install` / `installSafely`（config 或 builder）
  * `isInstalled` / `configOrNull`
  * `record` / `recordBreadcrumb`
  * `loadPendingReport` / **`loadPendingReportSafely`**
  * `clearPendingReport` / `clearStartupCrashReport`
* `LumenCrashConfigBuilder` 自动填充 app 名/版本；`fileProviderAuthority` 默认 `${pkg}.lumen.crash.fileprovider`
* Store 写应用专属外部目录（externalFiles/externalCache），可读 legacy 私有路径
* Author integrity fail-closed；ProGuard 模板已扩展（ConfigBuilder/Defaults/FileProvider/PasteUploader 等）
* Capture-only 宿主应依赖 `lumen-crash-core`，避免 Compose UI 依赖

### PiliPlus 现状
* Hybrid 已落地：SDK 管 JVM uncaught + 外部 pending；Flutter 管 filter/history/startup UI
* `PiliPlusApplication`：`LumenCrash.install(app, LumenCrashConfig(...))` + `runCatching`，`commitHash="unknown"`
* Channel：`getLumenPendingReport` 调 `loadPendingReport()`（非 Safely）
* 依赖：`com.chloemlla.lumen:lumen-crash` + Compose BOM（仅为 SDK api 面）
* ProGuard keep 块较旧，缺新类/属性规则
* Flutter `CrashBreadcrumbs` 与 native `CrashBreadcrumbs` **未贯通**
* ProcessExitCollector 仍采 ANR/native/init failure，跳过 REASON_CRASH（正确）
* 本地不跑 Flutter/Gradle；改完 commit + push

## Assumptions
* 继续 hybrid：不启用 `LumenCrashReportScreen` / `LumenCrashGate`
* 优先 capture-only 依赖 `lumen-crash-core`；若 CI/Packages 仅有 full artifact 再回退 full
* Flutter 产品 UI 与过滤策略不变

## Requirements

### R1 安装路径对齐 SDK
1. `attachBaseContext` 使用 `LumenCrash.installSafely(this) { ... }`
2. Builder 配置：
   * `appDisplayName`（可选覆盖为 `@string/app_name`）
   * `commitHash` 尽量从宿主 Build 元数据注入；没有则 `"unknown"`
   * 不强制 FileProvider（capture-only 不需要 share UI）
   * 不设置 killProcess 特殊值（保持默认 true）
3. `onCreate` 仍可幂等 `installSafely`（`isInstalled` 短路）
4. 安装失败不得阻断冷启动（installSafely 语义）

### R2 安全 load / clear API
1. `NativeCrashChannel.getLumenPendingReport` 使用 `LumenCrash.loadPendingReportSafely()`
2. clear 保持 best-effort；必要时包装 `runCatching`
3. 映射字段保持：recordId/timestamp/source/severity/module/reason/exceptionType/message/stack/systemInfo/recentEvents/author*/capture=lumen_crash
4. 导入后仍 clear SDK pending，再写 Flutter history

### R3 Capture-only 依赖（源码推荐）
1. 将 app 依赖改为 `com.chloemlla.lumen:lumen-crash-core:$lumenCrashVersion`（若 Packages 坐标一致）
2. 若确认 full AAR 才有发布而 core 未发，则保留 full 并在笔记写明；默认按 README 用 core
3. 若切到 core：去掉仅为 lumen-crash UI 引入的 Compose BOM **仅当**无其他 Compose 依赖需要
4. CI 版本解析逻辑兼容 core artifact 版本号（通常与 full 同 tag/version）

### R4 ProGuard 模板同步
1. 用 `lumen-crash/host-proguard-template.pro` 刷新 `android/app/proguard-rules.pro` 中 Lumen 段
2. 覆盖 ConfigBuilder / Defaults / FileProvider / PasteUploader / Author 属性 keep
3. 不开启 minify（仍只是预置规则）

### R5 面包屑贯通（native 报告质量）
1. Method channel 增加 `recordBreadcrumb(String event)`
2. Dart `CrashBreadcrumbs.record` 在 Android 上 best-effort 转发到 native `LumenCrash.recordBreadcrumb`
3. 失败静默；不阻塞 UI
4. 路由 observer 产生的 breadcrumb 自动进入 JVM crash 报告 `recentEvents`

### R6 元数据 / 文档 / Spec
1. Application install 日志 breadcrumb：`LumenCrash installed (piliplus host)`
2. 更新 `.trellis/spec/frontend/flutter-crash-reports.md`：
   * installSafely + core 依赖
   * loadPendingReportSafely
   * breadcrumb bridge
3. 可选：`docs/` 或 task research 记录与源码 diff
4. 不改 Flutter 启动崩溃页产品交互（除既有 CrashReportStartupGate）

## Acceptance Criteria
* [ ] `PiliPlusApplication` 使用 `installSafely` + builder
* [ ] Channel 使用 `loadPendingReportSafely`
* [ ] 依赖按 capture-only 策略调整（core 或有文档回退）
* [ ] ProGuard Lumen 段与 SDK host 模板对齐
* [ ] Flutter breadcrumb 可进入 native lumen report recentEvents
* [ ] ProcessExitCollector 去重策略不变
* [ ] Spec 更新
* [ ] commit + push；不跑本地 Flutter/Gradle

## Definition of Done
* 与 lumen-crash-core 公开 API 对齐的关键缺口清零
* hybrid 架构不被破坏
* 变更可静态审查

## Technical Approach
1. PRD（本文件）
2. Application installSafely
3. Channel safely load + breadcrumb method
4. Dart breadcrumb bridge
5. Gradle dependency core + proguard
6. Spec + commit/push

## Decision (ADR-lite)
**Context**: 初版 hybrid 已可用，但安装/加载 API 与 SDK 推荐路径不一致，且 full UI AAR 对 Flutter 宿主过重。  
**Decision**: 按 core 源码做 capture-only 加固：installSafely、safe load、breadcrumb 桥、ProGuard 同步；产品 UI 仍只走 Flutter。  
**Consequences**: 原生 fatal 报告更稳、更轻；CI 需能解析 core 坐标（与 full 同版本发布时无额外负担）。

## Out of Scope
* 启用 Compose `LumenCrashGate` / 替换 Flutter 启动崩溃页
* 远程上报后端
* iOS/desktop
* 本地构建验证
* 重写 Flutter CrashReportStore 格式

## Gap Matrix

| 源码能力 | PiliPlus | 动作 |
|---|---|---|
| installSafely + builder | 手写 Config + runCatching | **改** |
| loadPendingReportSafely | loadPendingReport | **改** |
| lumen-crash-core capture-only | full lumen-crash + Compose BOM | **改/评估** |
| recordBreadcrumb | 未桥接 | **改** |
| host-proguard-template 完整 | 旧 keep 块 | **改** |
| Author fields map | 已有 | 保持 |
| Exit-info ANR/native | 已有且去重 | 保持 |
| Flutter history UX | 已有 | 保持 |

## Technical Notes
* 源码：
  * `F:/Repositories/GitHub/Project-Lumen/lumen-crash-core/src/main/java/com/chloemlla/lumen/crash/*.kt`
  * `F:/Repositories/GitHub/Project-Lumen/lumen-crash/host-proguard-template.pro`
  * README 最短接入与 capture-only 说明
* 宿主：
  * `android/app/src/main/kotlin/.../PiliPlusApplication.kt`
  * `NativeCrashChannel.kt`
  * `lib/services/crash/crash_breadcrumbs.dart`
  * `lib/services/crash/native_crash_bridge.dart`
  * `android/app/build.gradle.kts`
  * `android/app/proguard-rules.pro`
  * `.trellis/spec/frontend/flutter-crash-reports.md`
