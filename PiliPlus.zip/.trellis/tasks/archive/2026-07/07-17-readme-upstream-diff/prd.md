# 详细更新 README 相对上游改进说明

## Goal
完整、准确地更新 `README.md` 中「本分支（Chloemlla/main）相对上游的改进」章节，反映相对 `upstream/main`（`bggRGjQaUbCoE/PiliPlus` @ `c1aeaca09` Release 2.1.0）到当前 `main`（`84ba7cdac`）的主要增量。

## What I already know
* 当前 `main` 相对 `upstream/main` 约 97 个提交、0 个落后。
* README 已有该章节，但未覆盖 lumen-crash、密钥旁路存储、NativeMediaService、包名变更、MMKV lazy/LRU、Baseline Profile 近期 CI 硬化等。
* 用户要求「详细更新」，不是新建 changelog。

## Assumptions
* 保留现有章节结构与中文风格，按主题扩展，不改成完整 commit 列表。
* 同步补齐 `feat` 清单中与本分支强相关、但未列出的关键能力（若合适）。
* 不修改无关 README 段（功能清单主体、声明、致谢等仅做必要对齐）。

## Requirements
* 以主题分组详细描述本分支改进：Seal、Web QR、崩溃/lumen-crash、MMKV、密钥与隐私、媒体导出/播放、剪贴板、首启权限、Android 包名/更新源、CI/Baseline Profile、工程协作。
* 写清实现入口/关键类名、用户可见行为、平台范围（尤其 Android）。
* 标明对比基线：上游 `upstream/main`，仓库 `Chloemlla/PiliPlus`。
* 保留 Seal 使用提示，并据最新行为校正。
* 明确“非完整 changelog”。

## Acceptance Criteria
* [ ] README 改进章节覆盖 `upstream/main..main` 的主要功能与工程增量
* [ ] 包含 lumen-crash、SecretStore、NativeMediaService、包名 `com.chloemlla.piliplus` 等此前缺失点
* [ ] Seal / 崩溃 / MMKV 描述与当前代码行为一致
* [ ] 提交并推送文档更新

## Out of Scope
* 不重写整份 README 功能清单
* 不改应用代码
* 不在本地跑 Flutter/Gradle

## Technical Notes
* 对比：`git log upstream/main..main`（97 commits）
* 关键路径：`lib/utils/seal_download_utils.dart`、`lib/services/crash/*`、`lib/utils/android/android_mmkv_box.dart`、`lib/utils/clipboard_video_link_handler.dart`、`android/.../NativeMediaService.kt`、`PiliPlusApplication.kt`
