# ClashMeta：活跃连接重命名 + 连接管理

## Goal

1. 主页与所有相关中文文案将「查看使用」统一改为「活跃连接」（含标题、更新说明等）。
2. 连接列表页支持管理：关闭单条连接、关闭全部连接（不仅查看/复制）。

## Repo

`F:\Repositories\GitHub\ClashMetaForAndroid`（禁止本地 Gradle/全量构建；改完 push，用 `gh` 修 CI 至成功）

## Current state

- 文案 key：`connections` / `format_connections_title` / `connections_empty`（zh 为「查看使用」）
- UI：`ConnectionsActivity` + `ConnectionsDesign` + `ConnectionAdapter`（仅长按复制）
- Go 已有 `tunnel.CloseAllConnections()` 与 `Tracker.Close()`，但未暴露到 JNI/IClashManager/UI
- 无字面量「查看使用功能」；实际是「查看使用」

## Requirements

### R1 文案

- zh / zh-rTW / zh-rHK：`connections` → `活跃连接`；`format_connections_title` → `活跃连接 · %d`
- EN 可选：`Active connections` / `Active connections · %d`（与语义对齐）
- `update_notes.json` 中 connections-viewer 标题/正文同步
- 不改 key 名（仍用 `connections`），只改字符串值

### R2 关闭连接 API 全链路

```
Go export → JNI Bridge → Clash.kt → IClashManager/ClashManager → ConnectionsActivity/Design
```

- `closeConnection(id: String)`
- `closeAllConnections()`
- 复用 `statistic.DefaultManager` / `tunnel.CloseAllConnections` / `Tracker.Close` by id

### R3 UI

- 工具栏/菜单：「关闭全部」
- 列表项：点击或操作可关闭单条（可确认或直接关闭；关闭后依赖订阅刷新列表）
- 保留长按复制
- 空列表时禁用关闭全部

## Acceptance

- [ ] 主页入口显示「活跃连接」
- [ ] 连接页标题/空状态/更新说明无「查看使用」
- [ ] 可关闭单条与全部
- [ ] CI Build Release 成功

## Constraints

- 禁止本地构建；声明式依赖即可
- 用 `gh run` 观察并修 Actions 直到成功
