# Finish remaining verifiable fixes

## Goal

Complete the concrete repository-local issue left by the previous convergence
session without treating agent service availability as a blocker: restore the
`model/utils -> pages` import boundary while preserving Seal download behavior.

## Requirements

- Resolve the reproducible `tool/check_import_boundaries.py` failure for
  `lib/utils/seal_download_utils.dart`.
- Preserve the current `SealDownloadUtils` public API and existing call sites'
  behavior.
- Do not add `seal_download_utils.dart` to the boundary allowlist; remove the
  wrong layer ownership instead.
- Do not expand or edit the existing oversized implementation body. Prefer a
  file move plus narrow import/spec updates.
- Do not revive the reverted account, playback-seek, or mismatched Seal API
  agent patches without a current reproducible defect.
- Do not run Flutter, Gradle, emulator, or local full builds.
- Commit and push the verified change automatically.

## Acceptance Criteria

- [x] `python tool/check_import_boundaries.py` passes.
- [x] All imports of `SealDownloadUtils` point to its feature-owned location.
- [x] The old `lib/utils/seal_download_utils.dart` path no longer exists.
- [x] The Seal download spec references the new canonical source path.
- [x] `git diff --check` passes.
- [x] Changed import files were formatted with the standalone Dart SDK; the
  moved implementation remains byte-for-byte identical to the original Blob.
- [x] No Flutter or Gradle command is run.
- [x] Commit `f661425fa` is pushed to `origin/main`.

## Definition of Done

- The known boundary failure is removed without behavioral changes.
- Static checks allowed by repository policy pass.
- Task/session bookkeeping is completed after the code commit.

## Technical Approach

Move the feature-specific Seal orchestration/UI implementation from the
repository-wide `lib/utils/` layer into the video feature, update its two
imports, and update the owning Trellis spec's source path. Keep the file content
unchanged to avoid modifying a super file.

## Decision (ADR-lite)

**Context:** `SealDownloadUtils` imports video page controllers and UI classes,
so keeping it under `lib/utils/` violates the enforced dependency direction.

**Decision:** Relocate it to `lib/pages/video/seal_download_utils.dart` rather
than weakening the allowlist or introducing a broad refactor during closeout.

**Consequences:** The boundary check becomes green and ownership matches the
implementation. The oversized implementation remains existing debt, but this
task does not add to or rewrite that file.

## Out of Scope

- Functional changes to Seal download, cookies, strip logic, or status UI.
- Splitting the existing Seal implementation into multiple files.
- Local runtime/device/build verification.
- Speculative fixes from unsuccessful or reverted agent work.

## Technical Notes

- Prior work commits: `f7c5e16f6`, `13889f69c`.
- Relevant specs: `.trellis/spec/frontend/flutter-seal-download-delegate.md`,
  `.trellis/spec/frontend/quality-guidelines.md`.
- Pure architecture/spec movement is not user-visible, so the build-scoped
  what's-new content does not require another entry.
- Verification: import boundary check passed; old/new implementation Blob hash
  was `f8e80fa1d2d5cc8b5f27efd8ee39a078bacad67c` before commit.
