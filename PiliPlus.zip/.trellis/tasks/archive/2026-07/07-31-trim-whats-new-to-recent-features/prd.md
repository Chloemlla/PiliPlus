# 精简本次更新说明为近期功能

## Goal

删除 `WhatsNewData.pages` 中长期累积的历史功能页面，让“本次更新说明”只展示最近一批已合入、用户当前最需要知道的功能与修复。

## Requirements

* 保留欢迎页，并继续使用 `versionLabel`、`buildTimeLabel`、`commitLabel` 动态展示构建身份。
* 欢迎页明确说明这里只列近期变更，不再汇总分支历史功能。
* 保留近期的主页返回/Android 状态栏修复。
* 保留近期的本地评论收藏功能。
* 新增或整理近期上游 UI/交互更新页面，覆盖主界面、加载骨架、动态投票与文本选择等最近同步内容。
* 删除空状态动态色插画、设置搜索定位、HMS Scan Kit、Clash VPN、Seal 下载等较早的历史遗留页面。
* 保留结束页以及“本分支改进说明”“开源声明”入口提示。
* 总体保持欢迎页 + 3 个近期主题页 + 结束页，避免继续无限累积。

## Acceptance Criteria

* [ ] `WhatsNewData.pages` 不再包含旧的插画、设置搜索、Scan Kit、Clash、Seal 页面。
* [ ] 页面只描述 2026-07-29 至 2026-07-31 最近一批用户可见变更。
* [ ] 构建版本、时间和 Commit Hash 仍由动态 getter 提供，没有硬编码。
* [ ] 结束页仍能引导用户手动查看本次说明、分支改进和开源鸣谢。
* [ ] GitHub Actions 通过；本地不运行 Flutter、Gradle 或构建测试。

## Definition of Done

* 只修改本任务相关的更新说明文件，不混入当前工作区其它并行修改。
* 自动提交并推送。
* 用 `gh` 验证本提交对应的完整 Build workflow。

## Technical Approach

直接重写 `WhatsNewData.pages` 的发布叙事：保留动态欢迎页、主页/状态栏修复页、近期 UI 交互页、评论收藏页和结束页；删除其它历史主题页。不改变显示/确认服务或构建身份逻辑。

## Decision (ADR-lite)

**Context**: 当前“本次更新说明”已混入多周前的分支能力，逐次追加导致它更像历史功能汇总，与构建级说明定位冲突。

**Decision**: 以最近一次发布窗口为边界，只保留最近 2–3 天的用户可见变化；更长期能力继续由“本分支改进说明”承载。

**Consequences**: 更新说明更短、更易扫读；旧功能不会在每个新构建中反复展示。

## Out of Scope

* 修改 `ImprovementsGuideData` 的分支长期改进内容。
* 修改更新说明的展示、确认和存储逻辑。
* 改动当前工作区其它并行任务文件。

## Technical Notes

* 目标文件：`lib/pages/onboarding/whats_new_data.dart`。
* 规范：`docs/flutter-build-whats-new.md`、`.trellis/spec/frontend/flutter-build-whats-new.md`。
* 最近用户可见提交包括本地评论收藏、上游 UI 同步、Android 状态栏映射及主页左侧空白栏修复。
