# Recent Whats-New scope

## Release window

Use the user-visible changes merged from 2026-07-29 through 2026-07-31 as the current build narrative.

## Keep

1. Home return and Android status-bar fixes (`94c7b2035` plus the 2026-07-30 status-bar fixes).
2. Local comment favorites (`13889f69c`).
3. Recent upstream UI/interaction sync (`16e240f88`, carrying `e89241109`, `133f45945`, and `557585334`).

## Remove as historical carry-over

* Dynamic-color empty-state illustrations.
* Settings search jump/highlight.
* HMS Scan Kit QR scanning.
* Clash VPN auto adaptation.
* Seal cookie/ad-segment download features.

These remain branch-long capabilities and belong in `ImprovementsGuideData`, not every new build's `WhatsNewData`.

## Exclude

* CI/analyzer/import-casing commits.
* Merge ancestry bookkeeping.
* Docs-only changes.
* Internal file-move refactors with no new behavior.

## Final shape

Welcome + three recent topic slides + the existing finish slide. Keep all welcome build-identity labels dynamic.
