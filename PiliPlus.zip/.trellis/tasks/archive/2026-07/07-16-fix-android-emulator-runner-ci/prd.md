# Fix android-emulator-runner CI failure

## Goal

Restore Android baseline-profile generation in GitHub Actions after the `Generate Baseline Profile` step dies during emulator SDK install (~17s).

## What I already know

* Failure signature:
  * `Run reactivecircus/android-emulator-runner@...`
  * `Configure emulator`
  * `Install Android SDK`
  * `Terminate Emulator`
  * `Error: The process '/usr/bin/sh' failed with exit code 1`
  * duration ~17s (too fast for boot timeout; this is package install)
* Current workflow uses:
  * `api-level: 34`
  * `target: aosp`
  * `arch: x86_64`
  * `profile: pixel_6`
* Commit `209efdd41` switched `target` from `aosp_atd` to `aosp`.
* `reactivecircus/android-emulator-runner` accepted targets include `default`, `google_apis`, `google_apis_playstore`, `aosp_atd`, `google_atd`, etc. There is no `aosp` target, so SDK Manager cannot resolve the system image package and fails during install.

## Assumptions

* Root cause is the invalid `target: aosp` package id, not hardware acceleration / boot timeout.
* Intent of the previous change was a plain AOSP image that is more graphics-capable than `aosp_atd`. That maps to `target: default` (`system-images;android-34;default;x86_64`).

## Requirements

* Fix `Generate Baseline Profile` emulator setup so Android SDK install succeeds.
* Keep API 34 + x86_64 + pixel_6 + current emulator options / boot timeout unless a further change is required for package availability.
* Prefer plain AOSP (`default`) over invalid `aosp`, preserving the previous commit's intent vs ATD.

## Acceptance Criteria

* [ ] `.github/workflows/build.yml` uses a valid emulator `target` accepted by android-emulator-runner.
* [ ] Target maps to a real system-image package for API 34 x86_64.
* [ ] Comments in the workflow accurately describe the chosen image.
* [ ] Change is committed and pushed.

## Definition of Done

* Workflow target fixed and documented.
* Commit + push completed (no local Flutter/Gradle).
* No unrelated files modified.

## Out of Scope

* Re-tuning BaselineProfileGenerator launch retries unless the invalid target is not the cause.
* Changing baseline profile Gradle/Kotlin logic.
* Running Flutter/Gradle/emulator locally.

## Technical Approach

1. Replace `target: aosp` with `target: default` (plain AOSP system image).
2. Update the adjacent comment to name the real package/target.
3. Leave boot timeout and emulator options intact.

## Decision (ADR-lite)

**Context**: CI fails immediately during SDK install after target was renamed to `aosp`.
**Decision**: Use `default` (AOSP) instead of invalid `aosp`.
**Consequences**: Restores installability; if first-frame flakiness remains, handle in generator/timeout, not by inventing package names.

## Technical Notes

* File: `.github/workflows/build.yml` (`Generate Baseline Profile` step)
* Recent related commits: `f91bbbaf2`, `209efdd41`
* Do not run Flutter/Gradle locally per AGENTS.md; rely on GHA for verification.
