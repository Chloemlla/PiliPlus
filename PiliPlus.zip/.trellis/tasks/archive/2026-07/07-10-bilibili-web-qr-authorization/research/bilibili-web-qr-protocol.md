# Bilibili web QR authorization protocol research

## QR payload

The official web QR generator currently returns a URL shaped like:

```text
https://account.bilibili.com/h5/account-h5/auth/scan-web?navhide=1&callback=close&qrcode_key=<key>&from=
```

The PC polling endpoint reports code `86101` and message `未扫码` before the scan flow begins.

## Current official H5 flow

The currently served `scan-web` H5 JavaScript performs:

1. `GET https://passport.bilibili.com/x/passport-login/web/qrcode/check`
2. `GET https://passport.bilibili.com/x/passport-login/web/qrcode/scene`
3. `POST https://passport.bilibili.com/x/passport-login/web/qrcode/confirm`

The final confirmation body contains:

- `qrcode_key`
- `transient`
- `env_key`
- `verify_type`
- `verify_code`
- `verify_key`

## Scene fields observed in the official client

- `app`: target application information, including title when available.
- `transient`: whether normal versus 24-hour short-term login can be selected.
- `obtain_env`: whether an environment choice is required.
- `env_show_list`: entries containing `env_key` and `env_desc`.
- `location_diff`: whether the scan location differs.
- `qrcode_location`: location text shown to the user.
- `verify_tel`: whether phone verification is required.

## Phone verification branch

The official H5 uses:

- `GET /x/safecenter/user/info` to obtain the masked phone number.
- `POST /x/safecenter/captcha/pre` for Geetest/recaptcha parameters.
- `POST /x/safecenter/common/sms/send` with `sms_type=loginTelCheck`.
- `GET /x/safecenter/common/sms/check` with the captcha key and SMS code.
- The verified captcha key/code are passed into `qrcode/confirm`.

## Environment restriction

- The H5 checks the user agent for `BiliApp`, `BiliComic`, `hikari`, or `MissEvan`.
- Outside the official app it attempts to open `bilibili://browser?...`.
- In the official app it uses the app-native HTTP bridge, which supplies device/authentication context.
- Direct anonymous browser requests to `check` and `scene` returned an HTML 404, so a normal cookie-synced WebView is not a sufficient implementation.

## Security requirements

- Validate the exact HTTPS origin and path before extracting a key.
- Never authorize immediately after scanning.
- Display target, environment, location difference, and short-term login implications.
- Do not persist or log the QR key, Cookie, CSRF, access key, or verification code.
- Treat code `86038` as expired and allow a clean rescan.

