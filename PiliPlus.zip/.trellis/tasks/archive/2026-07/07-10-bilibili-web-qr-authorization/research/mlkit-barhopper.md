# ML Kit Barcode Scanning / BarHopper research

## Official constraints

- Google ML Kit Barcode Scanning on Android requires API level 23 or newer.
- Bundled model dependency: `com.google.mlkit:barcode-scanning:17.3.0`.
- Google Play Services model dependency: `com.google.android.gms:play-services-mlkit-barcode-scanning:18.3.1`.
- The bundled model adds roughly 2.4 MB and is immediately available.
- The Play Services model adds roughly 200 KB but may require a first-use download; requests before download completes can return no results.
- For a custom scanner UI, Google recommends the Barcode Scanning API rather than the permission-less Google Code Scanner API.

Source: https://developers.google.com/ml-kit/vision/barcode-scanning/android

## Camera integration

- Use CameraX `PreviewView` for preview and `ImageAnalysis` for frames.
- Configure the scanner for `Barcode.FORMAT_QR_CODE` only to reduce work.
- Use `ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST` so the analyzer does not queue stale frames.
- Always close `ImageProxy` in the ML Kit task completion callback.
- Guard successful delivery with an atomic flag to avoid multiple Activity results.
- Close the `BarcodeScanner` and unbind CameraX in Activity destruction.

## Version choice

- Current stable CameraX release found in Google Maven metadata: 1.6.1.
- Recommended for this login feature: bundled ML Kit model. Login authorization should work on first launch and on devices without a functioning Play Services model download path.

## Repository mapping

- Add dependencies only to `android/app/build.gradle.kts`.
- Raise/effectively clamp Android minSdk to 23 because the ML Kit API requires it.
- Add `android.permission.CAMERA` and an unexported native scanner Activity.
- Use the existing `MainActivity` MethodChannel pattern, but keep scanning code in separate Kotlin files.

