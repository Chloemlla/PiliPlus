# 实现 B 站官方网页二维码扫描授权

## Goal

在 Android 版 PiliPlus 中使用当前主账号扫描 B 站官方网页登录二维码，展示授权目标与风险信息，并在用户明确确认后完成网页登录授权；扫码能力使用 CameraX 与本地 ZXing Core，不依赖 Flutter 二维码扫描插件或 Google 组件初始化。

## What I already know

- 用户明确要求实现原生摄像头扫码、严格 URL 校验、`check`、`scene`、确认页面和 `confirm` 完整流程。
- 只接受 `https://account.bilibili.com/h5/account-h5/auth/scan-web`，从查询参数提取非空 `qrcode_key`。
- B 站当前官方 H5 使用 `check`、`scene`、`confirm` 三个接口，并包含短期登录、登录环境选择、异地提示和手机号验证分支。
- PiliPlus 的主账号已有 Cookie、`bili_jct`/CSRF、AppSign 与按账号发送请求的能力；网页扫码授权使用 Passport Cookie 会话，不混入可能绑定于其他客户端身份的 `accessKey`。
- 当前二维码登录方向相反：PiliPlus 展示 TV 登录二维码供官方 App 扫描。
- 当前项目没有扫码依赖，Android Manifest 也没有 CAMERA 权限。
- Android 原生能力通过 `MainActivity` 与 MethodChannel 接入，适合增加独立扫码 Activity 和 Dart 封装。
- 本地禁止运行 Flutter、Gradle、实际构建和测试；这些命令必须由 GitHub Workflow 执行。

## Assumptions (temporary)

- 首版在 Android 提供摄像头扫码和相册识别；手动粘贴 URL 在所有平台可用。
- 入口放在设置页账号操作区域，登录账号存在时显示“扫描网页登录二维码”。
- CameraX 使用稳定版 1.6.1，分析策略为 KEEP_ONLY_LATEST；识别结构参考 Synapse 的 CameraX 帧分析方式，解码器使用 ZXing Core 并仅接受 QR_CODE。
- 对 Cookie-only 账号发送 Cookie + CSRF，并使用与 `android_hd` 身份匹配的 App 签名参数；不把账号 `accessKey` 加入网页扫码授权签名。

## Requirements

- 新增 Android 原生全屏扫码 Activity，包含取景预览、扫描框、关闭、手电筒和错误提示。
- 使用 CameraX 提供相机帧，使用 `com.google.zxing:core:3.5.3` 解码 Y 平面，仅配置 QR_CODE。
- 解码完全本地可用，不依赖 Google Play 服务、模型下载、ML Kit Provider 或组件注册器。
- 通过独立 MethodChannel 将摄像头扫码或相册图片识别结果返回 Flutter；同一时间只允许一个原生识别请求。
- 在使用时申请 CAMERA 权限，不在首次启动时提前索取。
- Android 相册识别使用系统文档/图片选择器，不申请广泛媒体读取权限；选中图片由同一 ML Kit/BarHopper 解码器识别。
- 提供手动粘贴二维码 URL 的输入对话框，复用与扫码完全相同的严格解析和授权流程。
- Dart 层严格校验 HTTPS、精确主机、精确路径和唯一非空 `qrcode_key`，拒绝用户信息、端口、片段及非预期 URL。
- 使用当前 `Accounts.main` 执行扫码检查和场景获取。
- 场景页展示当前授权账号 UID、目标应用/设备、登录位置、异地风险、可选登录环境和短期登录说明。
- 环境选择为服务端要求时必须选择；短期登录仅在服务端允许时展示。
- 用户必须主动点击确认，禁止扫码后自动授权。
- `confirm` 成功后展示成功状态并关闭页面；二维码过期、已消费、网络错误可重新扫描。
- 若要求手机号验证，支持获取隐藏手机号、申请人机验证、发送短信、校验验证码，并把验证字段带入最终确认。
- `qrcode_key`、短信验证码、CSRF、Cookie、accessKey 不进入日志或持久化存储。
- 不修改现有反向 TV 二维码登录流程。

## Acceptance Criteria

- [ ] Android 设备可从设置页进入扫码页并按需申请相机权限。
- [ ] CameraX + ML Kit 能识别电脑屏幕上的 B 站官方网页登录二维码。
- [ ] Android 可从系统图片选择器选择二维码图片并通过 ML Kit/BarHopper 识别。
- [ ] 所有平台均可手动粘贴官方二维码 URL 并进入同一授权流程。
- [ ] 非官方域名、相似域名、错误路径、HTTP、重复/缺失 `qrcode_key` 均被拒绝。
- [ ] 合法二维码触发 `check`，再加载 `scene` 并显示服务端返回的授权信息。
- [ ] 用户选择环境/登录时长并明确确认后调用 `confirm`。
- [ ] 需要手机验证时可完成验证码分支后继续确认。
- [ ] 过期、取消、权限拒绝、接口失败均有可恢复提示，不泄露敏感字段。
- [ ] 非 Android 平台不会调用原生通道，并给出明确提示。
- [ ] URL 校验、场景解析和关键状态分支有单元测试。
- [ ] GitHub Workflow 中 analyze、test 与 Android build 成功。

## Definition of Done

- 代码按 Android 原生桥接、HTTP、模型、控制器、页面拆分，不新增 super file。
- 静态审查覆盖资源释放、CameraX 生命周期、ImageProxy 关闭、并发请求和页面销毁。
- GitHub Workflow 完成实际构建与测试验证。
- 自动生成符合仓库历史风格的提交，提交并推送；GPG 签名可临时省略。

## Technical Approach

- Android：独立 `QrScannerActivity` + `PreviewView` + `ImageAnalysis`；参考 Synapse 的 CameraX 生命周期与帧分析结构，使用 ZXing 解码相机 Y 平面和相册 Bitmap。
- Flutter 桥：独立 `AndroidQrScanner` MethodChannel 封装，负责摄像头、相册、平台判断、权限请求和异常映射。
- 协议：独立 `WebQrAuthHttp`，对 `check`/`scene`/`confirm` 与安全中心接口统一附加当前账号 Cookie、CSRF 和 App 签名参数；省略未使用的空可选字段，保证签名原文与实际表单一致。
- 领域模型：独立 QR URL 值对象与场景模型，采用容错 JSON 解析，未知字段不导致崩溃。
- UI：独立 GetX controller/view；设置页只增加轻量入口，避免把流程写入设置或登录 super file。

## Decision (ADR-lite)

**Context**: 官方 H5 强制 BiliApp 环境并依赖原生请求桥，普通 PiliPlus WebView 无法稳定复用。

**Decision**: 实现 PiliPlus 原生扫码、原生确认 UI 和直接协议调用；仅在手机号人机验证环节复用项目已有 Geetest WebView 组件。CameraX 结构参考 Synapse，二维码解码改用本地 ZXing，以规避 ML Kit 组件运行时在部分发布设备上的内部空指针。

**Consequences**: 用户体验与现有 Flutter UI 一致、敏感操作可控，但非公开接口和 App 风控可能变化，需要通过真机与 GitHub Android Workflow 验证并保持接口解析容错。

## Out of Scope

- iOS、Windows、Linux、macOS 摄像头扫码与相册识别实现。
- 扫描任意条形码或非 B 站登录二维码。
- 自动授权或后台静默授权。
- 模拟完整 BiliApp JS Bridge 或复用官方 scan-web H5 页面。

## Research References

- [`research/mlkit-barhopper.md`](research/mlkit-barhopper.md) — CameraX 与 ML Kit/BarHopper 接入约束及模型选择。
- [`research/bilibili-web-qr-protocol.md`](research/bilibili-web-qr-protocol.md) — 当前官方网页二维码授权流程和风险字段。

## Technical Notes

- Android 原生入口：`android/app/src/main/kotlin/com/chloemlla/piliplus/MainActivity.kt`
- Android 依赖：`android/app/build.gradle.kts`
- Manifest：`android/app/src/main/AndroidManifest.xml`
- 账号模型：`lib/utils/accounts/account.dart`
- Cookie 请求拦截：`lib/utils/accounts/account_manager/account_mgr.dart`
- App 签名：`lib/utils/app_sign.dart`
- 路由：`lib/router/app_pages.dart`
- 设置入口：`lib/pages/setting/view.dart`
- 官方 ML Kit 文档：https://developers.google.com/ml-kit/vision/barcode-scanning/android
