# 视频三点菜单下载交由 Seal 处理

## Goal

将视频详情页三点菜单中的「下载视频 / 下载音频」从 PiliPlus 内置直链导出，改为委托给 Seal（第三方下载器）处理队列与文件落地，并按 L3 协议接收即时结果与终态状态；完成时用居中成功卡片 + 精美动画反馈，并可打开/分享文件。

## Requirements

* 视频三点菜单「下载视频」「下载音频」都委托 Seal 处理（Android）
* 「下载视频」：传 bilibili 页面 URL，`extract_audio=false`（或不传）
* 「下载音频」：传同一页面 URL，且 `extract_audio=true`
* 「离线缓存」保持应用内逻辑不变
* 使用 Seal 协议 v1：`com.chloemlla.seal.action.DOWNLOAD`
* **L3 集成**：
  * 使用 Activity Result 启动，确保 `callingPackage` 可解析
  * 处理即时结果 `accepted` / `rejected` / `needs_ui`
  * 注册 `DOWNLOAD_STATUS` 接收 `completed` / `failed` / `canceled`
  * 传递 `caller_request_id` 便于关联
* 调用方 `setPackage` 指向 Seal（优先 `com.chloemlla.seal`，安装检测兼容 debug/preview）
* UGC URL：`${HttpString.baseUrl}/video/$bvid`
* PGC URL：`${HttpString.baseUrl}/bangumi/play/ep$epId`
* 未安装 Seal：Toast「请先安装 Seal」，**不降级**；并打开 `https://github.com/Chloemlla/Seal/releases`
* **auto_start**：
  * 默认 `false`（打开 Seal 配置 UI）
  * 设置中新增开关（建议「委托 Seal 时自动开始下载」），开启后传 `auto_start=true` 且 `open_ui=true`（未允许自动开始时降级 UI）
* **终态反馈**：
  * 即时/终态均有用户可见反馈
  * `completed` 展示居中成功卡片（缩放/淡入 + 成功图标动画），显示文件名，按钮：「打开」「分享」「关闭」
  * 基于 `content_uri` / `display_name` / `mime_type`；无 URI 时仅显示成功文案
  * `failed` / `canceled` 有对应反馈
  * 不复制文件进 PiliPlus 下载库
  * 动画优先 Flutter 内置 + SmartDialog，不引入 lottie/rive
* 非 Android：继续走原 `MediaExportUtils`，不崩溃

## Acceptance Criteria

* [ ] Android 点击「下载视频」可启动 Seal，并带上页面 URL
* [ ] Android 点击「下载音频」可启动 Seal，并带上页面 URL + `extract_audio=true`
* [ ] Activity Result 可区分 accepted / needs_ui / rejected
* [ ] 注册 `DOWNLOAD_STATUS` 后可收到 completed / failed / canceled 并给用户反馈
* [ ] completed 时展示居中成功卡片动画，并可打开/分享文件（有 content_uri 时）
* [ ] 设置中存在 Seal 自动开始开关，默认关；开启后 Intent 带 `auto_start=true`
* [ ] 未安装 Seal 时 Toast「请先安装 Seal」，并打开 GitHub Releases，且不走内置下载
* [ ] 「离线缓存」行为不变
* [ ] 非 Android 仍可用原 MediaExportUtils，不崩溃

## Definition of Done

* 代码改动完成，风格与现有 MainActivity MethodChannel / 设置 SwitchModel 一致
* 动画反馈不引入重型第三方动画依赖
* 无本地 Flutter/Gradle 构建
* 提交并推送

## Technical Approach

1. **Native (MainActivity / 新 Seal 渠道)**  
   - MethodChannel：`delegateDownload(url, extractAudio, autoStart, requestId)`  
   - `PackageManager` 检测 Seal 是否安装（release/debug/preview）  
   - `startActivityForResult` 发送 `DOWNLOAD` Intent（`setPackage` + `type=text/plain` + extras）  
   - 动态或清单注册 `DOWNLOAD_STATUS` Receiver，事件回传到 Dart  
   - 打开/分享 content_uri 的 native helper（或 Dart + Intent）  
   - Manifest `queries` 声明 Seal package 可见性

2. **Dart**  
   - `SealDownloadUtils`：构造 bilibili URL、读 `Pref.sealAutoStart`、调 channel、订阅状态流  
   - `header_control.dart`：Android 走 Seal；其它平台走 `MediaExportUtils`  
   - 完成态 SmartDialog 居中成功卡片 + 动画  
   - 设置：`SettingBoxKey.sealAutoStart` + `SwitchModel`（放在 extra/video 设置区）

3. **Settings**  
   - key 默认 `false`  
   - title 建议：`委托 Seal 时自动开始下载`  
   - subtitle：说明需在 Seal 中开启「Allow external auto-start」

## Decision (ADR-lite)

**Context**: 需要把应用内直链下载改为委托 Seal，并保证可感知入队/完成状态。  
**Decision**: L3 完整协议 + 默认 auto_start=false + 设置开关可开 auto_start + 完成居中成功卡片（打开/分享）+ 未安装提示并打开 Releases。  
**Consequences**: 实现量大于 fire-and-forget；依赖 Seal 安装与用户设置；不维护内嵌下载与文件入库。

## Out of Scope

* 在 PiliPlus 内嵌 yt-dlp
* 修改 Seal 全局设置 / 指定输出路径 / 清晰度协议扩展
* 重写「离线缓存」
* 未安装时降级到 `MediaExportUtils`
* 将 Seal 完成文件复制进 PiliPlus 下载/媒体库

## Technical Notes

* 参考：`F:\Repositories\GitHub\Seal\docs\third-party-call-guide.md`、`ExternalDownloadProtocol.kt`
* UI 入口：`lib/pages/video/widgets/header_control.dart`
* 设置模式：`SwitchModel` + `SettingBoxKey` + `Pref`
* 现有 Result 模式：`MainActivity.onActivityResult`
* 打开链接：`PageUtils.launchURL`
* Seal releases：`https://github.com/Chloemlla/Seal/releases`

## Implementation Plan

* PR1: Native Seal channel（检测安装 + DOWNLOAD Intent + Activity Result + status Receiver）
* PR2: Dart 委托工具 + header_control 接入 + 设置开关
* PR3: 完成态居中成功卡片动画 + 打开/分享 + 错误反馈
