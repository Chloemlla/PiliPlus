# Seal：所有下载渠道广告片段剔除

## Goal

PiliPlus 检测/发送的广告/标记片段剔除在 Seal 侧**所有下载渠道**生效；当前仅部分路径生效。

## Repos

- 实现：`F:\Repositories\GitHub\Seal`
- 协议参考：`F:\Repositories\GitHub\PiliPlus`（strip_segments / keep_sections / sections）

## Requirements

- R1. 外部协议 v2 的 sections / strip / keep 在所有下载入口生效（单 URL、批量、deep link、Activity Result、命令行式 intent 等）
- R2. 映射到 yt-dlp `--download-sections` / videoClips 或等价后处理
- R3. 与 cookie 透传、多 P 兼容
- R4. 无本地完整构建；CI Build Pre-Release 成功
- R5. 若有 upstream 相关 issue，一并修（fork issues 已关闭则查 parent remote）

## Acceptance

- [ ] 从 PiliPlus 任意委托路径带 strip 参数时 Seal 均剔除
- [ ] 无参数路径行为不变
