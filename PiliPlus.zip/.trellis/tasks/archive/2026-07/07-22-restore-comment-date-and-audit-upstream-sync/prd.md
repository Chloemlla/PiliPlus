# 恢复评论日期并排查上游同步误删

## 背景
最近一次上游同步 `b1c619957 chore(sync): merge upstream (resolve PR #1 conflicts) (#2)` 引入了上游 `7617bb692 opt ui` 的评论区 UI 重构。用户反馈评论没有日期。

## 目标
1. 恢复评论区日期显示（主评 + 子评）
2. 审计同一次同步是否还有其他“功能误删/回退”，形成结论
3. 仅修复确认的回归；不回退上游有意的 UI 重构

## 已确认回归
### 评论日期消失（必修复）
- 文件：`lib/pages/video/reply/widgets/reply_item_grpc.dart`
- 旧逻辑：
  - 主评（`replyLevel == 0`）：`DateFormatUtils.format(ctime, longFormatDs)`
  - 子评：`DateFormatUtils.dateFormat(ctime)`
  - 有 IP 时追加 ` • location`，并用 `hasLocation()` 保护
- 新逻辑：只渲染 ` • ${location}`，并删除 `date_utils` import
- 数据未丢：`replyItem.ctime` 仍在 gRPC `ReplyInfo`

### 连带回归
- `hasLocation()` 条件被去掉：无 IP 时也可能显示孤立的 ` • `

## 审计范围（b1c619957 / 上游 opt ui）
已核对该同步 31 个文件变更，结论：
1. **确认功能回退**：评论日期 + location 条件渲染
2. **结构性重构（非误删）**：
   - `ExtraHitTestWidget` → `TranslucentRow`
   - FAB 滚动显隐抽到 `fabAnimWrapper`
   - 动态作者面板结构重写，但 `pubTs` 日期仍保留
3. **功能增强/替换（非误删）**：
   - live feedback、webview scheme 守卫、edl 多段播放、macOS 窗口背景等
4. **后续同步 876a0cc85**：主要是 Flutter 3.44.7 / UI / Seal 相关，未再删除评论日期

## 验收标准
- [ ] 主评论显示完整日期时间
- [ ] 子评论显示相对/短日期
- [ ] 有 location 时显示 `日期 • 地点`
- [ ] 无 location 时只显示日期，不出现孤立 ` • `
- [ ] 保留当前 `TranslucentRow` 结构，不回退整个 UI 重构
- [ ] 产出审计结论（写入 research）

## 非目标
- 不回退上游 TranslucentRow / FAB mixin 等有意重构
- 不在本地跑 Flutter/Gradle（按 AGENTS.md）
