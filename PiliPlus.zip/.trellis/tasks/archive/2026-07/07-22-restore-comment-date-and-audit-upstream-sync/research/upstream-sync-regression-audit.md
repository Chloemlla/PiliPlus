# Upstream sync audit: b1c619957 / 7617bb692

## Scope
Compared pre-sync tree `8efeedd20` vs sync commit `b1c619957` (and reviewed later merge `876a0cc85`).

## Confirmed regressions
| Item | File | Before | After | Verdict |
|---|---|---|---|---|
| Comment date | `lib/pages/video/reply/widgets/reply_item_grpc.dart` | render ctime via DateFormatUtils | only location text | **restored** |
| Location guard | same | `if (hasLocation())` | always ` • ${location}` | **restored** |

## Intentional upstream UI refactors (keep)
- `ExtraHitTestWidget` removed; replaced by `TranslucentRow`
- FAB scroll hide/show extracted into `BaseFabMixin.fabAnimWrapper`
- Author panel rewritten around `TranslucentRow`, but still shows `pubTs`
- Multiple list pages switched to shared fab wrapper
- `CommonDynPageMixin` keeps axis-down-only FAB notification via override

## Feature adds/changes (not accidental deletes)
- Live room feedback API + UI (`live_item_app.dart`, `LiveHttp.liveFeedback`)
- Webview in-app scheme handling tightened (intentional #2454)
- Multi-durl edl playback path
- Player pointer scroll / macOS opaque title bar
- Danmaku opacity/fontsize divisions 10x finer

## Suspicious but not feature-loss
1. **Author panel onTap set-literal**
   ```dart
   onTap: () => {
     feedBack(),
     Get.toNamed('/member?mid=${moduleAuthor.mid}'),
   },
   ```
   Looks wrong at first glance (Dart set literal), but same pattern already exists in-repo (`menu_row.dart`) and still executes side effects. Not a silent removal.

2. **Seek init rewrite**
   `if (seek == null || seek == Duration.zero)` → `if (seek == .zero) seek = null; seek ??= getFirstSegment();`
   Equivalent for null/zero entry; keep as upstream behavior.

3. **Webview `_inApp` path**
   Previously short-circuited ALLOW for in-app mode; now still filters non-http(s). This is the intentional fix for `ERR_UNKNOWN_URL_SCHEME`, not a regression.

## Later sync 876a0cc85
Conflict resolution notes claim fork-specific Seal/MediaExport preserved. No additional comment-date removal found.

## Recommendation / action taken
Restore only the date/location rendering in reply header; leave the rest of upstream opt-ui intact.
