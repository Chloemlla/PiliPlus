# Android Vivo 11-17 适配对齐

## Goal
对照 Project-Lumen 已整理的 vivo Android 11–17 适配决策，对 PiliPlus 做**可落地的宿主侧适配**：修 Manifest / 返回手势 / 分享 URI 授权 / 网络安全配置 / 组件 exported 等真实缺口；不相关项明确 N/A。

## What I already know

### 参考文档（Project-Lumen）
* `docs/VIVO_ADAPTATION_DOC_WORKFLOW.md` — 文档拉取与对照流程
* `docs/ANDROID_11_VIVO_ADAPTATION.md` … `ANDROID_17_VIVO_ADAPTATION.md`

### PiliPlus 现状（已扫代码）
* `compileSdk/targetSdk = 37`，`minSdk = max(flutter.minSdk, 26)`
* MainActivity: `resizeableActivity=true`，`configChanges` 含 orientation/screenSize/screenLayout/smallestScreenSize
* 前台服务：`AudioService` / `NativeMediaService` 声明 `foregroundServiceType=mediaPlayback`
* 权限已含：`POST_NOTIFICATIONS`、`FOREGROUND_SERVICE(_MEDIA_PLAYBACK)`、`READ_MEDIA_*`、存储（maxSdk 限制）、`CAMERA`
* Flutter 冷启动已 `SystemChrome.setEnabledSystemUIMode(edgeToEdge)`，cutout 用 `shortEdges`
* `NativeMediaService` PendingIntent 使用 `FLAG_IMMUTABLE`
* Seal 打开/分享 content URI 已加 `FLAG_GRANT_READ_URI_PERMISSION`，但 **ACTION_SEND 未挂 ClipData**
* **缺口**：
  1. `android:enableOnBackInvokedCallback="false"`（预测返回被关闭）
  2. `QrScannerActivity.onBackPressed()` 仍走废弃 API
  3. `UCropActivity` 未显式 `android:exported`
  4. 无 `networkSecurityConfig` / 无明确 cleartext 策略（A17 要求以 config 为准）
  5. 无 `intentMatchingFlags=enforceIntentFilter`（A16 加固）
  6. Seal `ACTION_SEND` 缺 `ClipData` 显式 URI 授权（A17 预留）
  7. Theme 系统栏不透明配置不完整（edge-to-edge 体验可再收紧）

### 产品差异（不可照搬 Lumen）
* PiliPlus 是视频客户端：需要 `mediaPlayback` FGS、媒体读写权限、DLNA/网络、WebView 等
* Lumen 的 exact alarm / 定时器 FGS specialUse / 相机距离采样 / Shizuku / QUERY_ALL_PACKAGES 等 **N/A 或不同**
* 不扫完整 vivo 文档站、不重写播放器；本地不跑 Flutter/Gradle

## Assumptions
* 本任务只改 PiliPlus 宿主 Android 配置与少量 Kotlin/Dart 路径，不改 lumen-crash SDK 源码
* 以 Lumen 决策笔记为“检查清单”，按 PiliPlus 产品语义重新判定 N/A / 已对齐 / 需改
* 高优先级先做；可选增强可放同一 PRD 的 Phase 2

## Requirements

### R0 产出物
1. Trellis PRD（本文件）
2. 仓库内适配笔记：`docs/android-vivo-adaptation.md`（或 `.trellis` 不可入库则放 `docs/`）
3. 代码改动 + commit + push

### R1 Predictive Back / 返回链路（A13/A16 高优）
1. Application：`android:enableOnBackInvokedCallback="true"`
2. `QrScannerActivity`：移除 `onBackPressed()`，改 `OnBackPressedDispatcher` / `onBackPressedDispatcher.addCallback`
3. 保持 Flutter 侧现有 `PopScope` / Get 返回拦截行为不回归

### R2 Component exported 完整性（A12）
1. 所有有 intent-filter 的组件必须显式 `android:exported`
2. 为 `UCropActivity` 补 `android:exported="false"`（无 filter 的内部页）
3. 复核 AudioService / MediaButtonReceiver / MainActivity / QrScanner 的 exported 语义

### R3 分享 / URI 显式授权（A17 预留 + 通用安全）
1. Seal `ACTION_SEND` / 打开 content URI 路径：除 `FLAG_GRANT_READ_URI_PERMISSION` 外，**附加 ClipData.newUri(...)**
2. 对 package 定向 intent（如 Seal）在可行处 `grantUriPermission` 或 clipdata 双保险
3. 不改纯文本 Share（无 URI）

### R4 Network security config（A17）
1. 新增 `android/app/src/main/res/xml/network_security_config.xml`
2. 默认 `cleartextTrafficPermitted=false`（HTTPS-first）
3. 若产品确实需要明文（本地调试 / 特殊域），用 domain-config 白名单，而不是 Manifest `usesCleartextTraffic=true`
4. Application 挂 `android:networkSecurityConfig`
5. 文档记录与现有 `NetworkSecurityPolicy` / 用户“坏证书放行”设置的关系：证书校验旁路仍是运行时 Dio 策略，不等于 cleartext

### R5 Intent matching hardening（A16）
1. Application：`android:intentMatchingFlags="enforceIntentFilter"`（API 属性 tools:targetApi）
2. 确认 launcher / bilibili deeplink / media button / Seal queries 仍用显式组件或正确 filter

### R6 Edge-to-edge / 大屏（A15/A16/A17）
1. 保持 `resizeableActivity=true`，不强制竖屏
2. Theme：系统栏透明（Launch/Normal 在合理范围内），与 Flutter edgeToEdge 一致
3. 不引入 `PROPERTY_COMPAT_ALLOW_RESTRICTED_RESIZABILITY`

### R7 权限与存储（A11/A13）— 文档化 + 必要修正
1. 保留 `READ_MEDIA_*` / 旧存储 maxSdk（产品需要相册/本地媒体）——在笔记中标为 **产品必要，非遗留全盘存储**
2. 不添加 `MANAGE_EXTERNAL_STORAGE` / `requestLegacyExternalStorage`
3. 首装权限引导已有通知/图片/视频/音频分项：确认与 Manifest 一致（已对齐则只记笔记）

### R8 FGS / 后台音频（A12/A14/A17）
1. 确认媒体 FGS 已 typed `mediaPlayback`（已对齐）
2. 确认持续播放路径走 audio_service / NativeMediaService，而不是无类型 FGS
3. 笔记写明：短提示音若有，应为 notification sonification；长播放必须 mediaPlayback FGS

### R9 PendingIntent mutability（A12）
1. 审计宿主代码 PendingIntent：
   * `NativeMediaService` IMMUTABLE — 保持
   * `MediaHelper` media button MUTABLE — **若媒体会话需要**则笔记说明合法；否则改为 IMMUTABLE
2. 不为第三方插件大范围改代码；只修本仓库可掌控路径

### R10 适配笔记
`docs/android-vivo-adaptation.md` 按 API 级别列出：
* 来源（Lumen 对应笔记）
* PiliPlus 决策：已对齐 / 本次修改 / N/A
* 验证清单

## Acceptance Criteria
* [ ] PRD 与适配笔记完整
* [ ] `enableOnBackInvokedCallback=true` + QrScanner 预测返回迁移
* [ ] UCrop exported 明确
* [ ] network_security_config 落地并挂到 Application
* [ ] intentMatchingFlags 加固
* [ ] Seal 分享 URI 带 ClipData + grant flags
* [ ] Theme / 大屏相关不回退
* [ ] 笔记覆盖 11–17 高优先级项与 N/A
* [ ] commit + push（不跑本地 Flutter/Gradle）

## Definition of Done
* 高优先级 Manifest/Kotlin 缺口全部处理或有文档理由
* 不引入无关重构
* 与 Lumen 决策可对照，但不机械复制 Lumen 产品特性

## Technical Approach

### Phase A — 文档与差距矩阵（本 PRD + research）
对照 Lumen A11–A17 检查清单 → PiliPlus 决策表。

### Phase B — Manifest / resources
* `AndroidManifest.xml`
* `res/xml/network_security_config.xml`
* `styles.xml`（系统栏透明，谨慎）

### Phase C — Kotlin 路径
* `QrScannerActivity.kt` back callback
* `SealDownloadChannel.kt` ClipData
* PendingIntent 审计（`MediaHelper` / `AndroidHelper` / `NativeMediaService`）

### Phase D — 笔记 + commit
* `docs/android-vivo-adaptation.md`
* commit / push

## Decision (ADR-lite)
**Context**: PiliPlus 已 targetSdk 37，但若干 A13–A17 默认行为仍显式关闭或未加固。  
**Decision**: 按 Lumen 检查清单做宿主侧对齐；媒体/相册等产品必要权限保留并文档化；不引入 Lumen 特有业务能力。  
**Consequences**: 更安全的返回/分享/网络安全默认值；需回归 deeplink、扫码、Seal 分享、后台播放。

## Out of Scope
* 修改 Project-Lumen / lumen-crash 上游源码
* 完整 vivo 开放平台文档站二次抓取（可用 Lumen 已抓材料）
* 播放器协议/弹幕/业务功能改造
* 本地 Flutter/Gradle 构建
* 健康传感器 / NPU / LAN mDNS / exact alarm 定时器产品化（N/A）

## Gap Matrix (initial)

| 项 | Lumen | PiliPlus 现状 | 动作 |
|---|---|---|---|
| targetSdk 37 | 是 | 是 | 已对齐 |
| Predictive back | true + BackHandler | **false** + Qr onBackPressed | **改** |
| FGS type mediaPlayback | N/A(specialUse/camera) | 已声明 | 已对齐 |
| POST_NOTIFICATIONS | 有 | 有 | 已对齐 |
| exported 全声明 | 有 | UCrop 缺 | **改** |
| networkSecurityConfig | 有 | **无** | **改** |
| intentMatchingFlags | enforce | **无** | **改** |
| Share ClipData+grant | SecureShareIntents | Seal 仅 flag | **改** |
| 大屏 resizeable | 是 | 是 | 已对齐 |
| edge-to-edge | 是 | Flutter 是 / Theme 半套 | 小改+笔记 |
| READ_MEDIA_* | 不用 | 产品需要 | 保留+说明 |
| ACCESS_LOCAL_NETWORK | 不用 | 不用 | N/A |
| exact alarm | 核心 | 非产品核心 | N/A |
| scheduleAtFixedRate | 无 | 待确认无 | 扫描确认 |
| QUERY_ALL_PACKAGES | 有(Shizuku) | 无，用 queries | 已对齐 |

## Implementation Plan
1. 写本 PRD → `task.py start`
2. Manifest + network_security_config + styles
3. QrScanner / Seal / PendingIntent
4. `docs/android-vivo-adaptation.md`
5. commit + push

## Technical Notes
* 关键路径：
  * `android/app/src/main/AndroidManifest.xml`
  * `android/app/src/main/res/xml/network_security_config.xml`（新建）
  * `android/app/src/main/res/values/styles.xml`（及 night 若需要）
  * `android/app/src/main/kotlin/.../QrScannerActivity.kt`
  * `android/app/src/main/kotlin/.../SealDownloadChannel.kt`
  * `android/app/src/main/java/.../MediaHelper.java`（审计）
  * `docs/android-vivo-adaptation.md`
* 约束：AGENTS.md — 不写 super file；本地不跑 Flutter/Gradle；完成后 auto commit + push
* 参考：`F:/Repositories/GitHub/Project-Lumen/docs/ANDROID_*_VIVO_ADAPTATION.md`
