# Research: Lumen Vivo notes → PiliPlus mapping

## Sources
- F:/Repositories/GitHub/Project-Lumen/docs/VIVO_ADAPTATION_DOC_WORKFLOW.md
- ANDROID_11..17_VIVO_ADAPTATION.md (same docs dir)

## PiliPlus scan (2026-07-17)
- targetAndroidSdk=37 in android/build.gradle.kts
- Manifest enableOnBackInvokedCallback=false
- mediaPlayback FGS present
- SealDownloadChannel grants FLAG_GRANT_READ_URI_PERMISSION without ClipData
- QrScannerActivity.onBackPressed deprecated path
- No res/xml/network_security_config.xml
- No intentMatchingFlags

## Product N/A for PiliPlus
- exact alarms / timer reconciliation
- camera FGS proximity
- QUERY_ALL_PACKAGES full install list
- Shizuku
- Health / NPU / LAN mDNS

## Implement first
1. predictive back
2. network security config
3. intentMatchingFlags
4. exported UCrop
5. Seal ClipData
6. docs
