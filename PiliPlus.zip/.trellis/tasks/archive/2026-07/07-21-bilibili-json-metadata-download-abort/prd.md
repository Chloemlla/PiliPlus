# bilibili-json-metadata-download-abort

## Goal

Eliminate or drastically reduce Seal/yt-dlp failures of the form:

`[BiliBili] <bvid>: Unable to download JSON metadata: [Errno 103] Software caused connection abort (TransportError)`

by fixing info-fetch brittleness, improving cookie-related guidance, and surfacing actionable errors — without waiting on cookie passthrough as a hard dependency.

## Background

- Symptom occurs at **JSON metadata** stage (info extraction), not media fragment download.
- Seal `DownloadUtil.getPlaylistOrVideoInfo` / `fetchVideoInfoFromUrl` hardcode **`-R 1`** and **`--socket-timeout 5`**.
- Cookies optional via Seal `COOKIES` + `cookies.txt`; PiliPlus L3 protocol v1 cannot inject cookies yet.
- PiliPlus constructs valid bilibili URLs (`https://www.bilibili.com/video/BVxxx`); root cause is Seal/network/auth layer.

## Requirements (complete)

### R1 — Info fetch resilience (Seal, must)

- Increase metadata request retries from 1 to **≥10**.
- Increase socket timeout from 5s to **≥30s**.
- Apply to **both** `getPlaylistOrVideoInfo` and `fetchVideoInfoFromUrl`.
- Prefer named constants for maintainability.

### R2 — Retry spacing (Seal, should)

- If embedded yt-dlp supports it, add retry sleep between attempts for info fetch.

### R3 — Error UX (Seal + PiliPlus, must)

- Map TransportError / errno 103 / “Unable to download JSON metadata” to localized, actionable copy (ZH + EN).
- External L3 `error_message` uses sanitized human text (no secrets, no raw stack).
- PiliPlus Seal panel shows that message on `failed`.

### R4 — Cookie guidance (Seal, must)

- Failure copy for bilibili-related metadata errors must mention enabling Cookies / logging in within Seal.
- Do not silently override user’s COOKIES=off without documentation; optional soft-prompt is OK.

### R5 — Independence (must)

- Fix must improve success rate **without** PiliPlus cookie passthrough landed.
- Must not break non-bilibili extractors (YouTube control path remains green).

### R6 — Optional synergy with task 1 (should)

- When cookie passthrough exists, documented as further mitigation for auth-gated content.

### R7 — Tests & CI (must)

- Unit test for error message mapping helper.
- Seal Build Pre-Release CI green via `gh`.
- No flaky live bilibili CI calls.

### R8 — Docs (must)

- CHANGELOG + brief note in troubleshooting / third-party guide if external callers see new message class.

## Acceptance Criteria

- [ ] Info paths no longer use `-R 1` / 5s timeout; use ≥10 retries / ≥30s timeout.
- [ ] Transient connection abort on metadata is retried automatically.
- [ ] User-visible error for unrecoverable metadata TransportError is localized and mentions cookies/network.
- [ ] YouTube (or non-bili) download still succeeds under normal conditions.
- [ ] External failed status carries humanized `error_message`.
- [ ] Seal CI green on main after merge.
- [ ] Manual matrix: cookie on/off × stable/flaky network documented in research or task notes.

## Edge Cases

| Case | Expected |
|------|----------|
| Permanent 404 / invalid URL | Fail after retries with clear invalid/unavailable message |
| COOKIES off + members-only | Fail with login/cookie guidance |
| Proxy wrong | Fail with network/proxy guidance |
| Multi-URL external batch | Per-task failure messages; one URL fail should not crash process |
| SponsorBlock API fail | Existing separate handling unchanged |

## Out of Scope

- Bypassing bilibili anti-bot / captcha
- Replacing yt-dlp
- Implementing full cookie passthrough (separate task)
- Local Android full builds as merge gate

## Technical Notes

- See `research/01-request-construction-full.md` … `04-implementation-plan.md`
- Key file: `Seal/.../DownloadUtil.kt` L80–179 (info), L659+ (download)
- CI: both mains green as of 2026-07-21 (`research/00-ci-status-full.md`)

## Definition of Done

- Code + strings + tests landed in Seal
- CI green
- Research + PRD complete
- Optional PiliPlus panel tweak only if message not already shown
