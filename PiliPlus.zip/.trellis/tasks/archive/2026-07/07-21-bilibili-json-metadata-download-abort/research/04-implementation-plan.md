# Implementation Plan: BiliBili JSON Metadata Abort Fix

- **Date**: 2026-07-21
- **Repo primary**: Seal (`F:\Repositories\GitHub\Seal`)
- **Repo secondary**: PiliPlus (error copy only, optional)

## Ordered steps

### Step 1 — De-brittle info fetch (Seal)

**Files:**
- `app/src/main/java/com/chloemlla/seal/util/DownloadUtil.kt`

**Changes:**
1. In `getPlaylistOrVideoInfo`: replace `-R 1` → `-R 10`; `--socket-timeout 5` → `--socket-timeout 30`.
2. In `fetchVideoInfoFromUrl`: same.
3. Add `--retry-sleep` if supported by embedded yt-dlp (verify with `YoutubeDL` version); else skip.
4. Optionally extract constants:

```kotlin
private const val INFO_RETRIES = 10
private const val INFO_SOCKET_TIMEOUT_SEC = 30
```

### Step 2 — Error humanization (Seal)

**Files:**
- `DownloadUtil.kt` (map Throwable message)
- `res/values/strings.xml` + `values-zh-rCN/strings.xml`

Map messages containing `Unable to download JSON metadata`, `TransportError`, `Errno 103`, `connection abort` to a localized string:

> 获取视频信息失败：网络连接中断。请重试；若为 B 站视频，请在「网络 → Cookies」启用并登录，或从 PiliPlus 透传账号。

Ensure external `error_message` uses the same sanitized string (no cookie secrets).

### Step 3 — Status path (Seal → PiliPlus)

**Files:**
- `integration/ExternalDownloadStatusReporter.kt` (if truncation)
- PiliPlus `lib/utils/seal_download_utils.dart` panel display (already shows message)

Verify failed terminal broadcast includes humanized message.

### Step 4 — Tests

**Files:**
- Unit test: pure function mapping Throwable → user message (extract helper for testability)
- Existing ExternalDownload integration tests remain green
- No network-dependent CI test for bilibili (flaky)

### Step 5 — Docs

- `docs/third-party-call-guide.md` — note possible `download_failed` network class
- CHANGELOG entry

### Step 6 — CI (gh)

```bash
# after push to Seal
gh run list --repo Chloemlla/Seal --limit 3
gh run watch --repo Chloemlla/Seal <id>
```

No local Android full build required.

## Manual verification matrix

| Case | Cookies | Network | Expected |
|------|---------|---------|----------|
| Public BV | off | stable Wi‑Fi | Success more often with retries |
| Public BV | off | flaky | Succeeds after retry |
| Members-only / restricted | on (valid) | stable | Success |
| Members-only | off | stable | Clear cookie/login error if auth required |
| Multi-P batch from PiliPlus | on | stable | All parts metadata OK |
| Proxy misconfigured | * | * | Humanized fail, not raw errno only |
| YouTube control | off | stable | No regression |

## Dependency on cookie-passthrough task

| Item | Blocked? |
|------|----------|
| F1–F3 retries/timeouts | **No** |
| Error copy mentioning passthrough | **No** (can say “enable Seal cookies”) |
| Automatic PiliPlus SESSDATA inject | **Yes — task 1** |

Ship Step 1–5 independently; enhance with task 1 later.

## Rollback

Revert constants to previous values if any site shows pathological hang (unlikely at R=10 / 30s).
