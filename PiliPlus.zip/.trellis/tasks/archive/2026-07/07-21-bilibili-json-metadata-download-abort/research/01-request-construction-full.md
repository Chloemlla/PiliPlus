# Research: Seal YoutubeDLRequest Construction (Full Trace)

- **Query**: Every info/download request path for bilibili JSON metadata failures
- **Scope**: Seal `DownloadUtil.kt`, related prefs, DownloaderV2 enqueue
- **Date**: 2026-07-21

## Findings

### Primary files

| Path | Role |
|------|------|
| `Seal/app/.../util/DownloadUtil.kt` | Builds all yt-dlp requests |
| `Seal/app/.../util/PreferenceUtil.kt` | COOKIES, FORCE_IPV4, PROXY, SPONSORBLOCK, USER_AGENT |
| `Seal/app/.../download/DownloaderV2.kt` | Queue execution |
| `Seal/app/.../download/TaskFactory.kt` | Task → preferences |
| `Seal/app/.../App.kt` | Init engines; regenerate cookies.txt from WebView DB |

---

## 1. Info path A: `getPlaylistOrVideoInfo`

**Location:** `DownloadUtil.kt` ~L80–119

```kotlin
fun getPlaylistOrVideoInfo(playlistURL, downloadPreferences): Result<YoutubeDLInfo>
  YoutubeDLRequest(playlistURL).apply {
    --flat-playlist
    --dump-single-json
    -o BASENAME
    -R 1                    // ONLY ONE RETRY
    --socket-timeout 5      // 5 SECOND SOCKET TIMEOUT
    if extractAudio: -x
    applyFormatSorter
    if proxy: --proxy
    if forceIpv4: -4
    if cookies: enableCookies(userAgentString)  // --cookies cookies.txt [+ UA header]
    if restrictFilenames: --restrict-filenames
  }
  execute → decode PlaylistResult | VideoInfo
```

**Hardcoded aggression (not from prefs):**
- `-R 1` — single retry only
- `--socket-timeout 5` — 5s socket timeout

**Conditional (from `DownloadPreferences`):**
- cookies / proxy / forceIpv4 / extractAudio / format sorter / restrictFilenames

---

## 2. Info path B: `fetchVideoInfoFromUrl`

**Location:** `DownloadUtil.kt` ~L133–179

```kotlin
fun fetchVideoInfoFromUrl(url, playlistIndex?, taskKey?, preferences): Result<VideoInfo>
  YoutubeDLRequest(url).apply {
    -o BASENAME
    if restrictFilenames
    if extractAudio: -x
    applyFormatSorter
    if cookies: enableCookies
    if proxy: enableProxy
    if forceIpv4: -4
    if autoSubtitle: --write-auto-subs [+ extractor-args youtube:skip=translated_subs]
    if playlistIndex != null: --playlist-items + --dump-json
    else: --dump-single-json
    -R 1                    // SAME HARDCODE
    --no-playlist
    --socket-timeout 5      // SAME HARDCODE
  }
  → getVideoInfo(request, taskKey)
```

Same `-R 1` / `--socket-timeout 5` as path A.

---

## 3. Cookie enable helper

**Location:** `DownloadUtil.kt` ~L359–364

```kotlin
private fun YoutubeDLRequest.enableCookies(userAgentString: String): YoutubeDLRequest =
  this.addOption("--cookies", context.getCookiesFile().absolutePath).apply {
    if (userAgentString.isNotEmpty()) {
      addOption("--add-header", "User-Agent:$userAgentString")
    }
  }
```

- File: `FileUtil.getCookiesFile()` → config dir `cookies.txt`
- Netscape format; App startup may rewrite from WebView Cookie DB (`App.kt` ~L109–111)
- Only applied when `downloadPreferences.cookies == true` (`COOKIES` pref)

---

## 4. Download path: `downloadVideo`

**Location:** `DownloadUtil.kt` ~L659–820

```kotlin
fun downloadVideo(videoInfo, playlistUrl, playlistItem, taskId, downloadPreferences, progressCallback)
  requires non-null videoInfo (else fetch_info_error_msg)
  url = playlistUrl ?: videoInfo.originalUrl ?: webpageUrl
  YoutubeDLRequest(url).apply {
    --no-mtime
    if cookies: enableCookies
    if restrictFilenames
    if proxy: enableProxy
    if forceIpv4: -4
    if debug: -v
    if useDownloadArchive: archive check + --download-archive
    if rateLimit: -r N K
    playlist vs --no-playlist
    if aria2c: --downloader libaria2c.so
    else if concurrentFragments > 1: --concurrent-fragments N
    audio vs video format options
    if sponsorBlock: --sponsorblock-remove <categories>
    if createThumbnail: --write-thumbnail --convert-thumbnails png
    if subdirectoryExtractor: path += extractorKey
    -P output path (or sdcard temp)
    for each videoClip: --download-sections *start-end
    if newTitle: --replace-in-metadata title
    if API>23 && !sdcard: -P temp:externalTemp
    if splitByChapter: --split-chapters + chapter template
    -o output template
  }
  YoutubeDL.execute(request, processId=taskId, callback)
  Special case: sponsorBlock + "Unable to communicate with SponsorBlock API" → failure with message
```

**Note:** Download path does **not** hardcode `-R 1` / 5s timeout the same way info paths do — the fragility is concentrated in **metadata/info fetch**, which matches the user error (`Unable to download JSON metadata`).

---

## 5. Preferences materialization

`DownloadPreferences.buildFromPreferenceStore()` (~L297–354):
- `cookies = COOKIES.getBoolean()`
- `forceIpv4 = FORCE_IPV4.getBoolean()`
- `proxy = PROXY.getBoolean()` + `PROXY_URL`
- `sponsorBlock = SPONSORBLOCK.getBoolean()` + categories string
- `userAgentString` only if `USER_AGENT` enabled
- `videoClips = emptyList()` by default (clips set per-task UI)

---

## 6. External delegate path relevance

PiliPlus → Seal L3 only passes URL(s), extract_audio, auto_start, open_ui, request_id.  
No cookie, no retry override. External downloads inherit **Seal global** prefs for cookies/ipv4/proxy.  
If user never configured Seal cookies for bilibili, metadata fetch runs **without** `--cookies` and with `-R 1` / 5s timeout → high fail rate for Bilibili.

---

## 7. Summary of request hardness

| Stage | Retries | Socket timeout | Cookies | IPv4 | Proxy |
|-------|---------|----------------|---------|------|-------|
| getPlaylistOrVideoInfo | **1 (hard)** | **5s (hard)** | pref | pref | pref |
| fetchVideoInfoFromUrl | **1 (hard)** | **5s (hard)** | pref | pref | pref |
| downloadVideo | yt-dlp default / not same hardcode | not same hardcode | pref | pref | pref |

**Primary code smell for Errno 103 / TransportError on BiliBili metadata:** info extraction is intentionally brittle.
