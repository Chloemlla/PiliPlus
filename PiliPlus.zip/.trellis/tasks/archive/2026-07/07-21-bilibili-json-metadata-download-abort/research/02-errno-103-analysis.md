# Research: Errno 103 / BiliBili JSON Metadata Abort

- **Error**: `[BiliBili] BV1azhwzpErn: Unable to download JSON metadata: [Errno 103] Software caused connection abort (caused by TransportError(...))`
- **Date**: 2026-07-21

## What Errno 103 means

On Linux/Android, `ECONNABORTED` (103 on some Android/Bionic mappings; platform-dependent) / connection abort means the TCP connection was aborted by software — typically:

1. Peer closed/reset during handshake or mid-request
2. Local stack aborted after stall / policy
3. Middlebox (Wi‑Fi portal, carrier NAT, VPN, Great Firewall behavior) reset connection
4. HTTP/2 or TLS layer abort surfaced as TransportError in yt-dlp's urllib/httpx stack

yt-dlp wraps this as `TransportError` → "Unable to download JSON metadata".

## Bilibili extractor context

- Extractor key shown as `[BiliBili]` / bilibili
- Metadata step hits Bilibili web/API endpoints (page HTML / playinfo / related APIs depending on yt-dlp version)
- **Login cookies** (`SESSDATA`, `DedeUserID`, `bili_jct`, often `buvid3`) strongly affect availability for many BV, higher quality, and anti-bot leniency
- Without cookies, more 412/403/empty/reset behaviors under load

## Interaction with Seal defaults

| Factor | Seal behavior | Effect |
|--------|---------------|--------|
| `-R 1` | Info paths only | One network glitch → hard fail |
| `--socket-timeout 5` | Info paths only | Slow mobile/DNS/TLS → timeout/abort |
| `COOKIES` off | Default often off for new installs | No SESSDATA for bilibili |
| No cookie passthrough from PiliPlus | Protocol v1 forbids cookie | Logged-in PiliPlus users still anonymous in Seal |
| IPv6 / dual-stack | Unless FORCE_IPV4 | Some networks reset v6 paths |
| Proxy | Optional | Misconfigured proxy → abort |
| aria2 / concurrent fragments | Download stage only | Less relevant to **metadata** JSON step |

## Ranked repro hypotheses

1. **(Primary) Info fetch too aggressive** — `-R 1` + 5s timeout on `getPlaylistOrVideoInfo` / `fetchVideoInfoFromUrl` converts transient aborts into user-visible failures.
2. **(High) No cookies for bilibili** — Seal COOKIES off and no PiliPlus cookie inject → extractor hits unauthenticated path; WAF/reset more common.
3. **(Medium) Network path** — cellular NAT, IPv6 broken path, flaky Wi‑Fi; single retry insufficient.
4. **(Medium) User-Agent / headers** — default yt-dlp UA may be filtered; Seal only adds UA when USER_AGENT pref + cookies enable path.
5. **(Lower) yt-dlp bilibili extractor regression** — version-specific; still mitigated by retries/cookies.
6. **(Lower) Concurrent external auto-start storm** — rate limit is on gate, not yt-dlp; less likely for single BV.

## Why this matches the user report

- Error is specifically **JSON metadata**, not fragment download → info path, not `downloadVideo` media transfer.
- BV id present → URL construction from PiliPlus is fine; failure is Seal/yt-dlp network stage.
- TransportError + connection abort is classic under short timeout + no retry + optional missing auth.

## Independence from cookie-passthrough

Cookie passthrough (task 1) **helps** hypothesis 2 but is **not required** for fix:
- Raise retries/timeouts alone improves hypothesis 1 & 3
- Prompt user to enable Seal cookies / use existing CookieProfile is interim UX
- Full fix package = retries + timeouts + better errors + optional cookie path
