# Research: Full Fix Matrix — BiliBili Metadata Abort

- **Date**: 2026-07-21
- **Target**: Seal primarily; PiliPlus error surfacing secondary

## Fix matrix

| ID | Change | Where | Scope | Benefit | Risk |
|----|--------|-------|-------|---------|------|
| F1 | Raise info retries: `-R 1` → `-R 10` (or 5–10) | `getPlaylistOrVideoInfo`, `fetchVideoInfoFromUrl` | All sites | Transient abort recovery | Slightly longer hang on permanent fail |
| F2 | Raise socket timeout: `5` → `30` (or 20–30) | same | All sites | Slow TLS/mobile | Slightly longer hang |
| F3 | Add `--retry-sleep` linear/exp (e.g. `http:1:5:2`) | info paths | All sites | Avoid thundering retry | Minimal |
| F4 | Prefer force IPv4 default for bilibili host **or** document FORCE_IPV4 | prefs / extractor-args | Bilibili-focused option | Broken IPv6 nets | Break pure-IPv6 (rare on Android) |
| F5 | Ensure cookies when available: auto-enable cookies for bilibili if cookies.txt non-empty | DownloadUtil info+download | Bilibili | Auth path | Unexpected use of WebView cookies |
| F6 | Cookie passthrough from PiliPlus (task 1) | Protocol v2 | Bilibili via PiliPlus | Uses already-logged account | Security design required |
| F7 | User-Agent: always set browser-like UA on bilibili info fetch | DownloadUtil | Bilibili | WAF friendliness | Fingerprinting policy |
| F8 | Extractor-args for bilibili if needed (version-dependent) | DownloadUtil | Bilibili | API fallbacks | Break on yt-dlp upgrades |
| F9 | Humanize error message for TransportError / errno 103 | DownloadUtil / UI / external status | All | Actionable UX | i18n strings |
| F10 | External status: map download_failed with sanitized message | StatusReporter + PiliPlus panel | External callers | PiliPlus shows “网络中断/请重试/检查 Cookie” | Message length limits |
| F11 | Optional pref: “Info fetch retries / timeout” in troubleshooting | PreferenceUtil + UI | Power users | Configurability | UI complexity |
| F12 | Fragment retries for download stage if not already | downloadVideo | Media | Separate from metadata | — |

## Recommended package (full, not thin)

### Must ship (Seal)

1. **F1 + F2 + F3** — de-brittle info extraction globally (safe defaults).
2. **F9 + F10** — user-readable errors for metadata TransportError.
3. **F5** (soft) — if cookies.txt exists and host is bilibili.*, use cookies even if global COOKIES toggle is off **OR** show one-shot prompt; prefer not silently overriding user off-switch — better: when COOKIES off and bilibili fails with transport/403, error text tells user to enable cookies.

### Strongly couple with task 1

4. **F6** — PiliPlus cookie passthrough so Seal does not require separate WebView login for B站.

### Optional / later

5. F4 as troubleshooting default note + pref already exists (`FORCE_IPV4`).
6. F7/F8 after verifying against current yt-dlp bilibili extractor.
7. F11 only if defaults insufficient for edge users.

## Defaults proposal

| Option | Current (info) | Proposed |
|--------|----------------|----------|
| `-R` | 1 | **10** |
| `--socket-timeout` | 5 | **30** |
| `--retry-sleep` | none | `linear=1::2` or yt-dlp supported form |
| cookies | pref only | unchanged; improve error copy |
| force ipv4 | pref only | unchanged |

## Non-bilibili regression

- Higher retries/timeouts slightly slow permanent failures (YouTube private, dead links) — acceptable.
- Do **not** add bilibili-only hardcode that breaks other extractors without host checks.
- Prefer global friendlier defaults over site-specific brittle special cases, except cookie error hints.

## PiliPlus-side (without waiting for cookie task)

- Panel already shows Seal failure message — ensure native/Kotlin passes `error_message` through.
- Optional: detect bilibili URL and preflight toast “若失败请在 Seal 开启 Cookies 或使用账号透传”.
