# Fix baseline profile app launch crash in CI

## Goal

Restore Android baseline-profile generation in GitHub Actions after `:baselineprofile:connectedNonMinifiedReleaseAndroidTest` fails because package `com.chloemlla.piliplus` does not stay running after launch on the emulator.

## What I already know

* Failure signature (after SDK install and emulator boot succeed):
  * `BaselineProfileGenerator > startup[emulator-5554 - 14] FAILED`
  * `java.lang.IllegalStateException: Target package ... failed to stay running after launch`
  * `visible=false processRunning=false`
  * `last=Unable to confirm activity launch completion [] ... dumpsys gfxinfo ... framestats`
  * Emulator logs also show `Failed to find ColorBuffer`
* Prior CI sequence:
  * API 35 `google_apis` -> boot timeout
  * API 34 `aosp_atd` -> boots, but first-frame/framestats confirmation was flaky
  * API 34 invalid `aosp` -> SDK install fails (~17s)
  * API 34 `default` (current) -> emulator boots, instrumented test runs, then app process dies / never becomes visible
* Generator already retries launch and falls back from `startActivityAndWait` to `am start`, but still requires **both** package UI visibility **and** process alive.
* On ATD images, UI Automator package-depth visibility can fail even when the process is healthy enough for macrobenchmark tracing.
* App package id is `com.chloemlla.piliplus` for nonMinifiedRelease (no suffix). Generator package matches.
* Impeller is already disabled in the manifest.
* `LumenCrash.install` in `PiliPlusApplication.attachBaseContext` is not try/caught; an install failure aborts process start with no Flutter logcat.
* `lib/main.dart` calls `exit(0)` on `GStorage.init` failure, which also yields `processRunning=false` without `AndroidRuntime` crash frames.

## Assumptions

* Primary CI cause is the combination of:
  1. plain AOSP/`default` + SwiftShader graphics instability (`ColorBuffer`) causing first-frame / process loss
  2. generator success criteria that are too strict for ATD/headless-ish environments
* Reverting the emulator target to valid `aosp_atd` and treating a stable post-launch process as success is the smallest reliable fix.
* App-side defensive install around lumen-crash reduces chance of hard process death during Application attach.

## Requirements

* Make baseline-profile generation succeed on GHA for API 34 x86_64 without local Flutter/Gradle runs.
* Keep generator cold-start intent (kill + relaunch inside collect block).
* Accept launch success when the target process remains running after a settle window, even if framestats/UI depth visibility fails.
* Keep/restore a real emulator system image package id (`aosp_atd` recommended).
* Improve failure diagnostics (clear + broader logcat) so the next regression is actionable.
* Harden `LumenCrash.install` so install exceptions do not kill Application attach.

## Acceptance Criteria

* [ ] `.github/workflows/build.yml` uses a valid emulator target (prefer `aosp_atd` for boot reliability).
* [ ] `BaselineProfileGenerator` no longer fails solely because UI package depth visibility is false when the process stays running.
* [ ] Failure path dumps broader logcat/tombstone-ish evidence than the current narrow filter.
* [ ] `PiliPlusApplication` catches lumen-crash install failures and continues startup.
* [ ] Spec `.trellis/spec/frontend/android-baseline-profile.md` documents ATD/process-alive launch contract.
* [ ] Changes committed and pushed.

## Definition of Done

* Code + workflow + baseline-profile spec updated.
* Commit + push completed.
* No local Flutter/Gradle execution.
* No unrelated files modified.

## Out of Scope

* Redesigning crash history / MMKV storage.
* Changing baseline profile iteration counts beyond what is needed for launch success.
* Replacing media_kit or graphics stack.

## Technical Approach

1. Workflow: set `target: aosp_atd` and document why (valid package, boots reliably; framestats/UI may be incomplete).
2. Generator:
   * Clear logcat before attempts.
   * After launch, success if process remains running across a settle period (and prefer UI visibility when available).
   * Keep existing intent construction/retry.
   * On hard failure, dump broader logcat (`AndroidRuntime`, `DEBUG`, `libc`, `flutter`, `ActivityManager`, `WindowManager`).
3. Application: wrap `LumenCrash.install` in `runCatching` / try-catch.
4. Update baseline-profile Trellis spec for the new contracts.

## Decision (ADR-lite)

**Context**: After fixing the invalid `aosp` target, generation still fails because the app never becomes confirmed-visible and the process is not running; ATD is more boot-stable but weaker on framestats/UI checks.
**Decision**: Use `aosp_atd` + process-alive launch success + defensive lumen-crash install.
**Consequences**: Baseline collection may proceed without perfect UI Automator visibility; if a true native crash remains, broader logcat will surface it on the next CI run.

## Research References

* [`research/launch-failure-analysis.md`](research/launch-failure-analysis.md)

## Technical Notes

* Files: `.github/workflows/build.yml`, `android/baselineprofile/.../BaselineProfileGenerator.kt`, `android/app/.../PiliPlusApplication.kt`, `.trellis/spec/frontend/android-baseline-profile.md`
* Related commits: `f91bbbaf2`, `209efdd41`, `8e2d8aa94`, `6c179a79b`
* Do not run Flutter/Gradle locally per AGENTS.md.
