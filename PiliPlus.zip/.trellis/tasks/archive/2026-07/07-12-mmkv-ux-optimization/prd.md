# 优化 MMKV 使用体验与合理利用

## Goal

在现有 Android MMKV 接入基础上，优化用户可感知体验（启动、设置切换、播放进度/缓存读写），并强化 MMKV 的合理使用：热路径更快、大 box 读写更稳、失败行为更可预期；保持非 Android 与账号安全边界不变。

## Requirements (MVP)

### A. 启动加载优化
* Android 二次打开已迁移 box 时，提供高效 load 路径，避免「整库 JSON 字符串 + Dart 二次 jsonDecode」成为唯一路径。
* 保持迁移标记 `migrated:<box>:v1` 语义；已迁移但解码失败仍禁止静默回退旧 Hive。
* 大 box（`watchProgress` / `reply`）打开成本显著降低。

### B. 热路径批量写
* Native 增加批量 put / 批量 remove。
* `AndroidMmkvBackedBox.putAll` / `deleteAll` 优先走批量接口，不再整库 `replaceBox`。
* `replaceBox` 保留给全量替换/回滚场景。
* 批量写失败时不得半更新内存 `_cache`。

### C. 大 box 治理（固定条数 + 近似 LRU）
* `watchProgress` 默认上限 **2000** 条；超限淘汰最旧写入条目。
* `reply` 默认上限 **500** 条；超限淘汰最旧写入条目。
* 用独立 meta（或等价结构）记录 last-write 顺序/时间，实现近似 LRU（按最近写入）。
* 日常 `put` 不强制 `sync()`；`flush` / `close` / 需要强一致时再 sync。
* 治理对调用方透明（经 `WatchProgressStore` / `ReplyCacheStore` 或 box 层）。

### D. 不变契约
* 非 Android / MMKV 不可用 → Hive。
* `Accounts.account` 不迁 MMKV。
* 设置导入导出行为保持可回滚语义。

## Acceptance Criteria

* [ ] 已迁移 box 有高效 load 路径（非唯一依赖整库 JSON 双解析）
* [ ] `putAll` / `deleteAll` 走 native 批量接口；失败不破坏 cache
* [ ] `watchProgress` > 2000 时自动淘汰最旧写入项
* [ ] `reply` > 500 时自动淘汰最旧写入项
* [ ] 日常 put 不 `sync()`；flush/close 可落盘
* [ ] 非 Android / 账号边界不变
* [ ] 更新 `android-mmkv-storage.md`
* [ ] 不本地跑 Flutter/Gradle；完成后 commit + push

## Definition of Done

* 三支柱代码落地 + 内存 backend 单测
* Spec 与实现一致
* commit + push

## Technical Approach

1. **Load**: Java 增加高效 entries 导出（如 keys + values 批量，或避免 Dart 端整包二次 parse 的瓶颈）；`tryLoadFromMmkv` 使用新 API。
2. **Batch**: Java `putAllStrings` + `removeValues`；Dart `putAll`/`deleteAll` 改用；失败不改 `_cache`。
3. **LRU meta**: 独立 meta box（如 `pili_plus_meta` 已有 migration 标记）记录各 box 的 write-order / lastWrite map；`WatchProgressStore`/`ReplyCacheStore` put 时 touch + evict。
4. **Sync**: put/putAll/delete 异步 mmap 即可；flush/close/clear/replace 再 sync。

## Decision (ADR-lite)

**Context**: 用户选择启动优化 + 批量写 + 大 box 治理；容量策略选固定上限 + 近似 LRU。  
**Decision**:
* progress max 2000、reply max 500
* 淘汰按最近写入（近似 LRU）
* bridge 扩展 batch + 高效 load  
**Consequences**: Java/Dart API 面扩大；需 meta 维护写入顺序；导入设置受益于 batch。

## Out of Scope

* 账号存储迁 MMKV
* 本地 Flutter/Gradle
* 新增用户可见存储清理设置页
* MULTI_PROCESS MMKV

## Technical Notes

* `android/.../AndroidMmkv.java`
* `lib/utils/android/android_mmkv_box.dart`
* `lib/utils/storage/watch_progress_store.dart`
* `lib/utils/storage/reply_cache_store.dart`
* `lib/utils/storage.dart`
* `test/utils/android_mmkv_box_test.dart`
* `.trellis/spec/frontend/android-mmkv-storage.md`
* 相关：`07-07-android-mmkv-integration`
* 热路径：`VideoDetailController.cacheLocalProgress`；下载 `deleteAll`；设置 `importAllJsonSettings` clear+putAll
