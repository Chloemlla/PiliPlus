# Danmaku Keyword Highlighting

## Goal

Let users define keyword rules to highlight matching danmaku in the video player — making it easy to spot important messages, the streamer's name, specific topics, or any custom pattern without filtering them out entirely.

## Requirements

### Keyword rule management
- Entry: "弹幕高亮" in settings or player toolbar
- Create rule:
  - Keyword (plain text or regex pattern)
  - Highlight color: red, orange, yellow, green, blue, purple, pink, white (color chips)
  - Priority (higher priority rules override lower ones)
  - Enable/disable toggle
- List all rules with status
- Rules are global (apply to all videos)
- Maximum 50 rules

### Highlighting behavior
- When danmaku is rendered, check against active rules
- Matching danmaku: text color changes to the rule's highlight color
- If danmaku already has an existing color (user color), apply highlight as a glow/border effect instead
- Case-insensitive plain text matching; regex rules use Dart `RegExp`
- If multiple rules match, highest priority wins

### Player integration
- Highlighting is purely client-side rendering; does not affect what is sent to the danmaku server
- Works with both real-time danmaku and cached danmaku
- No performance impact on high-frequency streams (O(n*m) with n=danmaku, m=rules; cap rules at 50)

### Quick rules
- Pre-built quick rules accessible as chips:
  - "主播" (streamer)
  - "谢谢"
  - "厉害"
  - "注意"
- Tap chip to add as a rule with default yellow color

### Data
- Store in `setting` Hive box: `danmakuHighlightRules`
- Schema: `{ id, keyword, isRegex, color, priority, enabled, createdAt }`

## Technical Approach

### Implementation
- `DanmakuHighlightService` in `lib/services/`
- Hook into danmaku rendering pipeline in `CanvasDanmaku` or `media_kit` danmaku overlay
- Each danmaku goes through `DanmakuHighlightService.resolveStyle(text:, displayedColor:)` → returns per-item fill and nullable stroke colors
- Apply `lib/scripts/canvas_danmaku_stroke_color.patch` to the exact pinned Git checkout after dependency resolution
- Build with `--no-pub` after the patch so the Pub-cache build input remains stable

### Color mapping
```dart
enum HighlightColor {
  red(Color(0xFFFF4444)),
  orange(Color(0xFFFF8800)),
  yellow(Color(0xFFFFFF00)),
  green(Color(0xFF44FF44)),
  blue(Color(0xFF4488FF)),
  purple(Color(0xFFAA44FF)),
  pink(Color(0xFFFF44AA)),
  white(Color(0xFFFFFFFF)),
}
```

### Performance
- Compile keyword patterns on rule change, not on every danmaku
- Use `Map<String, HighlightRule>` index by keyword for O(1) lookup on exact matches
- Regex rules in a separate list, matched sequentially

### UI
- `DanmakuHighlightPage`: rule list with add/edit/delete
- `DanmakuHighlightEditor`: dialog for rule creation/editing
- Quick rule chips row at the top of the page

## Acceptance Criteria

- [x] Create keyword rule with custom color
- [x] Enable/disable individual rules
- [x] Edit and delete rules
- [x] Highlighting applied correctly in player
- [x] Multiple rules with priority respected
- [x] Quick rule chips work
- [x] Rules persist across restarts
- [x] No per-frame regex compilation; active rules are precompiled and capped at 50
- [x] Shared startup registration and platform patch workflows are wired; CI remains the build/test authority

## Out of Scope

- Highlighting user-specific danmaku (gold/silver user color vs keyword highlight)
- Server-side keyword filtering (this is highlighting only, not blocking)
- Per-video custom rules (global rules only for MVP)
- Export/import rules

## Technical Notes

- Check `lib/pages/video/danmaku/` for existing danmaku rendering code
- Check `canvas_danmaku` for rendering API (already a dependency)
- Review existing `setting` Hive box patterns
- No new dependencies needed

## Implementation Review (2026-07-31)

- Normal white danmaku use the rule color as fill; existing colored fills keep their color and use the rule color as a per-item outline.
- Special danmaku use the same fill/stroke resolution without changing their default rendering when no custom stroke is supplied.
- Cached and network video danmaku share the same rendering path.
- Quick rules use the required default yellow color.
- Focused style and service tests cover matching, priority, persistence operations, duplicates, and the 50-rule cap.
- Integration review: `await registerFeatureServices()` runs after `GStorage.init()` on the shared startup path, and `WhatsNewData.pages` describes the color-preserving outline behavior. No additional main-thread API wiring is required; CI verification remains.
