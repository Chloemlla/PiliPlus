# Video Bookmarks and Timestamps

## Goal

Allow users to save named bookmarks at specific timestamps within a video, so they can remember important moments, mark "知识点在 XX:XX", or create personal annotations without requiring any server-side support.

## Requirements

### Create bookmark
- During video playback, tap the bookmark icon (or long-press on the progress bar)
- Enter bookmark name (optional; defaults to "标记 @ HH:MM:SS")
- Bookmark captures: bvid, title, timestamp (seconds), name, note (optional free text), createdAt
- Maximum 200 bookmarks per video

### Bookmark list
- View all bookmarks for the current video (entry from video player toolbar)
- Tap a bookmark → seek to that timestamp
- Edit bookmark name/note
- Delete bookmark

### All bookmarks view
- Dedicated page: "我的视频标记" listing all bookmarks across all videos
- Filter by: this video / all / by creator
- Sort by: most recent / video name / timestamp
- Search bookmarks by name or note text
- Tap → open video and seek to timestamp

### Data
- Store in Hive/MMKV: `videoBookmarks` box
- Schema: `{ id, bvid, videoTitle, authorMid, timestampSeconds, name, note, createdAt }`
- Export all bookmarks as JSON
- Clear all bookmarks with confirmation

## Technical Approach

### Storage
- Hive box: `videoBookmarks` — list of `VideoBookmark` objects
- Index by bvid for fast per-video lookup
- Keep all in memory for the all-bookmarks view (with lazy load for >500 entries)

### Implementation
- `VideoBookmarkService` / `VideoBookmarkController` in `lib/services/`
- `VideoBookmarkSheet`: bottom sheet shown from player toolbar
- `VideoBookmarkListPage`: dedicated page for all bookmarks
- Hook into player: bookmark icon in `PlayerToolbar` or on long-press of `ProgressBar`
- Seek via `PlayerService.seekTo(Duration(seconds: timestamp))`

### Player integration
- Add bookmark icon to existing player control overlay
- On long-press of progress bar: pre-fill timestamp, open bookmark dialog

## Acceptance Criteria

- [x] Create bookmark during playback with timestamp captured
- [x] View all bookmarks for current video
- [x] Tap bookmark to seek to timestamp
- [x] Edit and delete bookmarks
- [x] All bookmarks view with search/filter/sort
- [x] Bookmarks persist across app restarts
- [x] Export all bookmarks as JSON
- [x] Works on Android, iOS, and desktop

Static implementation review is complete; GitHub Workflow verification remains pending.

## Out of Scope

- Server-side sync / cross-device sync
- Share bookmarks with other users
- Collaborative bookmarks
- Video chapter auto-detection (manual only)
- Audio-only bookmark mode (bookmark without video context)

## Technical Notes

- Check `lib/pages/video/` for player toolbar structure
- Check `lib/services/player_service.dart` for seek API
- Review existing Hive box patterns in the app
- No new dependencies needed
