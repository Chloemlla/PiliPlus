# Live Stream Keyword Subscription Alerts

## Goal

Let users set keyword rules for live stream notifications from followed UP masters. When a UP goes live, if the stream title or area matches one of the user's keywords, fire a local notification — even if BiliBili's official notification is off or missed.

## Requirements

### Keyword rule management
- Entry: "直播提醒设置" in settings or a dedicated panel in the "我的" tab
- Create rule:
  - UP master selection (from followed list or manual mid/bvid input)
  - Keyword (free text, e.g., "演唱会", "杂谈", "游戏通关")
  - Match target: stream title only / area name only / both
  - Enable/disable toggle
- List all rules with status (active/paused)
- Edit and delete rules

### Notification
- Trigger: when the app detects (via polling or live status API check) that a followed UP is streaming
- Check stream title and area against active keyword rules
- If matched: fire `flutter_local_notifications` local push
- Notification content: "[UP名称] 正在直播: {标题}" with keyword highlighted
- Tap notification: deep link to live room

### Polling strategy
- Poll live status for followed UPs when app is in foreground
- On app launch and every 15 minutes while foregrounded
- No background polling (battery concern); foreground-only is sufficient
- Use BiliBili `x/relation/followings` + `x/web-interface/room?mid={mid}` or equivalent live status API

### Multi-account
- Each account has its own keyword rules

## Technical Approach

### Storage
- Hive box: `liveKeywordRules` — list of `LiveKeywordRule` objects
- Schema: `{ id, mid, upName, keyword, matchTarget, enabled, createdAt }`

### Notification
- `flutter_local_notifications` (already a dependency in upstream)
- `LiveAlertNotificationService` channel

### Polling
- `LiveAlertService` / `LiveAlertController` in `lib/services/`
- `AppLifecycleObserver` to start/stop polling on foreground/background
- Rate-limit: at most 1 notification per UP per 4 hours (even if they restart the stream)

### API integration
- `DynamicAPI.getFollowingList()` for followed UPs
- `RoomAPI.getRoomInfo(mid)` for live status and stream title
- Respect API rate limits

## Acceptance Criteria

- [ ] Create keyword rule with UP selection and keyword text
- [ ] Enable/disable individual rules
- [ ] Edit and delete rules
- [ ] Live stream triggers local notification when keyword matches
- [ ] Notification tappable → deep link to live room
- [ ] Notification respects 4-hour per-UP rate limit
- [ ] Rules work per-account (multi-account aware)
- [ ] Polling active while app is foregrounded

## Out of Scope

- Background push notifications (FCM / persistent connection)
- UP auto-follow from keyword match
- Sound/vibration customization per rule
- Notification scheduling ahead of time

## Technical Notes

- Check `lib/services/` for existing service patterns
- Check `lib/utils/api/` for existing API call patterns
- `flutter_local_notifications` — verify if already in pubspec.yaml or needs adding
- Review existing notification patterns in the app
- No new dependencies beyond potential `flutter_local_notifications` if absent
